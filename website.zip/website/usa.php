<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
    
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the Right Career</h2>
                                <!-- <h2>faqs</h2> -->
                                <h1>USA</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- why study -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span> United States of America</span></h2>
                    <p>The United States of America has been an attractive study destination for overseas
students for many decades. This could be attributed to the high standards of education,
technologically advanced infrastructure and an enlightened learning environment that
is prevalent in American universities. Furthermore, American higher education offers
students a flexible curriculum providing a wide variety of elective modules to choose
from. Here are a few reasons that make the USA a great study destination for you.
                </div>

            <!-- image -->
              <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="usa">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">                         
                            <ul class="menu">
                                <li><i class="fas fa-check"></i>Studying in the USA is affordable given the wide spectrum of universities, tuition fees, accommodation options and financial aid such as loans and waivers available to international students.</li>
                                <li><i class="fas fa-check"></i> The American higher education system ranks among the topmost in the world. Studying in the USA offers students the opportunity to gain globally recognized degrees. </li>
                                <li><i class="fas fa-check"></i> Modern education practices, a multicultural environment and globally recognized universities can give your career a flying start.</li>
                                <li><i class="fas fa-check"></i> Universities in the USA have the best research resources and some of the best research programs in medicine, technology and engineering.</li>
                                <li><i class="fas fa-check"></i> Universities in the United States provide opportunities beyond academic excellence by encouraging holistic development of students through active participation in extracurricular activities, sports and community service. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
            <!-- image -->

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of<span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='usa'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>" target="_blank">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                    <!--<div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">TEXAS WESLIYAN UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>Please contact us for more information on the Universitie and Colleges we represent in USA.</p>
                                                <a href="https://txwes.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">UNIVERSITY BRIDGE</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>Please contact us for more information on the Universitie and Colleges we represent in USA.</p>
                                                <a href="http://www.ubridge.org/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">AUBURN UNIVERSITY AT MONTGOMERY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                            <div class="card-body">
                                                
                                               <a href="http://aum.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">BAY STATE COLLEGE</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.baystate.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFive">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">FINLANDIA UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.finlandia.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSix">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">MANHATTAN INSTITUTE OF MANANGEMENT</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.mimusa.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSeven">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">OHLONE COLLEGE</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.finlandia.edu/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>-->
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                    <!-- <p>Business Studies & Management–</p> -->
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/avi.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$29.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>Business Studies & Management</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Business Studies & Management Courses</a></h5>
                                    <p>Courses in business studies include subjects such as economics, management, administration, marketing and operations. Students are given real-time case studies to study problems of the real world in national and multinational businesses.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>Free</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                        <h6>Biology, Life Sciences & Nature Studies </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Biology, Life Sciences & Nature Studies  Courses</a></h5>
                                    <p>  These domains include a study of the evolution of cells, organisms, ecosystems including developing an understanding of the structure, functioning and behaviour of living organisms. On a larger level, these courses also include an objective study of the working of the planet earth and the universe.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/life.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$59.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>Law</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Law</a></h5>
                                    <p>A degree from a law school in the USA is recognized around the world. Law schools help you develop skills for research, interpretation, analytical thinking and devising a simple explanation of complicated subjects.</p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i>  Marketing </li>
                                        <li><i class="fas fa-check"></i>  Finance</li>
                                        <li><i class="fas fa-check"></i>  Human Resources</li>
                                        <li><i class="fas fa-check"></i>  Operations Management</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$49.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                        <h6>Engineering & Technology</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering & Technology</a></h5>
                                    <p> The USA has always been at the helm of technological innovation and advancement. The country is also home to some of the most prestigious engineering schools. Apart from the conventional branches of engineering such as mechanical, civil, computer science, you can also study newer branches such as biotechnical, energy, aeronautics, mining and hydraulics.</p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i> Statistics </li>
                                        <li><i class="fas fa-check"></i> Specialized Mathematics</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img5.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$69.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                        <h6>Humanities & Liberal Studies</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Humanities & Liberal Studies</a></h5>
                                    <p> Universities in the USA offer many courses that focus on social sciences, humanities, arts and liberal studies at undergraduate and postgraduate levels.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/agr.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>Free</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
                                        <h6>Fashion</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Fashion Courses</a></h5>
                                    <p>Fashion courses in America encompass multiple disciplines. Students learn about
production, marketing, the technology of textiles and fashion designing. America is at
the fore front of the ready-to-wear market while New York is the fashion capital of the
world.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

             <!-- add new  -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting a <span>United States Visa</span></h2>
                    <p>Getting a study visa for the United States of America is an important part of the process for students aspiring to study in the USA. The US visa is interview-based.  A study visa for overseas students is classified as the F1 visa. Before obtaining the F1
visa, you are required to submit a form called the I-20 form which states the expiration
date of your course provided by your college or university.  The visa application process is run by the US Embassy. <br/>Fee payment and appointment scheduling may be done through their official website called <a href="www.ustraveldocs.com/in">www.ustraveldocs.com/in</a></p>
                </div>
                <div class="container">
                <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                <div class="about-img">
                <img src="assets/images/help/about-img.jpg" alt="About">
                </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                <div class="about-text">
                    <p>The following is an account of the visa procedure followed for US visa.</p>
                    <ul class="menu">
                        <li><i class="fas fa-check"></i> Obtain I-20 form from your University or College.</li>
                        <li><i class="fas fa-check"></i> Obtain SEVIS FEE receipt. (Fees paid to the Student & Exchange Visitor Program)</li>
                        <li><i class="fas fa-check"></i> Complete DS-160 Form.</li>
                        <li><i class="fas fa-check"></i> Pay the visa Application Fees.</li>
                        <li><i class="fas fa-check"></i> Schedule an Interview Appointment.</li>
                        <li><i class="fas fa-check"></i> Appear for Interview.</li>
                        <li><i class="fas fa-check"></i> Passport Collection after visa is granted.</li>
                    </ul>
                </div>
                </div>
                </div>
                </div>
                </div>
            </div>
            <!-- end of new -->

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>In the United States of America, almost 15% of the students at the undergraduate level are international students. At the postgraduate level, this percentage is higher. In the US, your cost of education will vary based on the type of course and the university you choose to join. As a general rule, private educational institutions are more expensive compared to public universities. Here is are the approximate figures of the tuition fees you can expect to pay in the US.</p>
                </div>
                <div class="container">
                  <table class="table table-dark table-hover">
                    <thead>
                      <tr>
                       <!--  <th>Expense</th> -->
                        <th style="text-align: center;">TUITION FEES CHARGED BY PUBLIC UNIVERSITIES PER YEAR (USD)</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Undergraduate Courses</td>
                        <td>13500 to 19000</td>
                      </tr>
                      <tr>
                        <td>Postgraduate Courses</td>
                        <td>19000 to 24000</td>
                      </tr>
                      <tr>
                      
                        <th style="text-align: center;">TUITION FEES CHARGED BY PRIVATE UNIVERSITIES PER YEAR (USD)</th>
                      </tr>
                      <tr>
                        <td>Undergraduate Courses</td>
                        <td>19000 to 28000</td>
                      </tr>
                      <tr>
                        <td>Postgraduate Courses</td>
                        <td>19000 to 34000</td>
                      </tr>
                      
                    </tbody>
                  </table>
                </div>
            </div>

            <div class="section-title">
                <h2>Cost of  <span> Living in the United States </span></h2>
                <p>Living in a metropolitan city such as New York, San Francisco, Las Vegas, or Los Angeles can make your living expenses higher as compared to other places. Usually, students spend up to USD 13500 to 17500 per year on living expenses in the USA. A lot of students choose to live in suburban areas to avoid high rental expenses. This could mean a long commute between your college or university and your residence. In some cases, universities can provide a travel pass for students that saves travel expenses.  </p><br/>
                  <p>Halls of residence or on-campus hostels are usually provided by all universities in the USA. But staying in an off-campus accommodation such as in a homestay, apartment or flat is usually more economical. It is advisable to live on-campus at the beginning of your course when you’re still getting accustomed to your new life, later on, you can move to a more economical residential option. </p>
            </div>

            <div class="section-title">
                <h2>Health <span> Insurance </span></h2>
                <p>Health insurance policy is compulsory for all students travelling to the USA for higher studies. Insurance could cost you approximately 2000 USD per year. Getting medical insurance from an  Insurance Company is the best idea, but check to confirm what it covers. A good health insurance policy is cashless for students and covers medical expenses, personal accidents, dental treatment, passport loss and study interruption etc.</p>
            </div>

            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    