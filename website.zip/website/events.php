<!doctype html>
<html lang="en">
  <head><?php include('inc/meta_css.php'); ?>
    <?php
        $sql="SELECT * FROM `counter` WHERE `page`='events' AND `date`='".date('Y-m-d')."'";
        $result=$mysqli->query($sql);
        $row=$result->fetch_array(MYSQLI_ASSOC);
        if(count($row)>0)
        {
            $update = "UPDATE `counter` SET `count`=".($row['count']+1)." WHERE `page`='events'";
            $mysqli->query($update);
        }
        else
        {
            $insert = "INSERT INTO `counter` (`count`,`page`,`date`) VALUES (1,'events','".date('Y-m-d')."')";
            $mysqli->query($insert);
        }
    ?>
      <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>  
     <script src="https://apps.elfsight.com/p/platform.js" defer></script>
  </head>
<!--   <style type="text/css">
    .brands {
        width: 100%;
        padding-top: 90px;
        padding-bottom: 90px
      }
    .brands_slider_container {
        padding: 30px;
        height: 300px;
        border: solid 1px #e8e8e8;
        box-shadow: 0px 1px 5px rgba(0, 0, 0, 0.1);
        padding-left: 60px;
        padding-right: 60px;
        background: #fff
    }
    .brands_slider {
        height: 100%;
       margin-top: -31px;
    }
    /*.brands_item {
        height: 100%
    }
    */
    .brands_item img {
        max-width: 100%
    }
    .brands_nav {
        position: absolute;
        top: 50%;
        -webkit-transform: translateY(-50%);
        -moz-transform: translateY(-50%);
        -ms-transform: translateY(-50%);
        -o-transform: translateY(-50%);
        transform: translateY(-50%);
        padding: 5px;
        cursor: pointer
    }
    .brands_nav i {
        color: #000000;
        -webkit-transition: all 200ms ease;
        -moz-transition: all 200ms ease;
        -ms-transition: all 200ms ease;
        -o-transition: all 200ms ease;
        transition: all 200ms ease
    }
    .brands_nav:hover i {
        color: #ee5957;
    }
    .brands_prev {
        left: 40px
    }
    .brands_next {
        right: 40px
    }
  </style> -->
  <body>
    <div class="main-container">
      <?php include('inc/header.php'); ?>
        <div class="banner-container">
            <div class="main-banner">
                <div class="slide transparent-background slide-one">
                    <div class="slide-text container">
                        <h2>India’s Top <span>Visa Consultancy</span> </h2>
                        <p>Get best-in-class consultancy and guidance - from the experts in overseas education.</p>
                        <a href="about.php" class="btn btn-primary btn-padding btn-animated">About Us</a>
                        <a href="contact.php" class="btn btn-secondary btn-padding btn-dark-animated">Contact Us</a>
                    </div>
                </div>
                <div class="slide transparent-background slide-two">
                  <div class="slide-text container">
                    <h2>Consult. Prepare<span> Apply.Travel</span></h2>
                    <p>The one-stop solution to all your overseas education needs. Check out our services page to know more.</p>
                    <a href="service.php" class="btn btn-primary btn-padding">Our Services</a>
                    <a href="contact.php" class="btn btn-secondary btn-padding">Contact Us</a>
                  </div>
                </div>
            </div>
        </div>
        <!-- start of instafeed -->
        <div class="container">
          <h4 align="center">Feed From Instagram</h4>
          <div id="instafeed">
          </div>
        </div>
        <!-- end of insta -->
        <!-- university logo -->
        <div class="container">
            <div class="section-title">
                <h2>Universities</h2>
            </div>
            <section class="customer-logos slider">

              <div class="slide"><img src="assets/images/uni/logo1.jpg"></div>
              <div class="slide"><img src="assets/images/uni/logo2.jpg"></div>
              <div class="slide"><img src="assets/images/uni/logo3.jpg"></div>
              <div class="slide"><img src="assets/images/uni/logo4.jpg"></div>
                <!-- aus -->
              <div class="slide"><img src="assets/images/logo/aus/a1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/aus/a7.jpg"></div>
              <!-- canada -->
              <div class="slide"><img src="assets/images/logo/canada/c1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c7.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c8.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c9.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c10.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c11.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c12.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c13.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c14.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c15.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c16.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c17.jpg"></div>
              <div class="slide"><img src="assets/images/logo/canada/c18.jpg"></div> 
              <!-- europe logo -->
              <div class="slide"><img src="assets/images/logo/europe/e1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e7.jpg"></div>
              <div class="slide"><img src="assets/images/logo/europe/e8.jpg"></div>
              <!-- ireland -->
              <div class="slide"><img src="assets/images/logo/ireland/i1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/ireland/i2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/ireland/i3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/ireland/i4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/ireland/i5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/ireland/i6.jpg"></div>
              <!-- newzeland -->
              <div class="slide"><img src="assets/images/logo/nz/n1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n7.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n8.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n9.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n10.jpg"></div>
              <div class="slide"><img src="assets/images/logo/nz/n11.jpg"></div>
              <!-- uk -->
              <div class="slide"><img src="assets/images/logo/uk/u1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u7.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u8.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u9.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u10.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u11.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u12.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u13.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u14.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u15.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u16.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u17.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u18.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u19.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u20.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u21.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u22.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u23.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u24.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u25.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u26.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u27.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u28.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u29.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u30.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u31.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u32.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u33.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u34.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u35.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u36.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u37.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u38.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u39.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u40.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u41.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u42.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u43.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u44.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u45.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u46.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u47.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u48.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u49.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u50.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u51.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u52.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u53.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u54.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u55.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u56.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u57.jpg"></div>
              <div class="slide"><img src="assets/images/logo/uk/u58.jpg"></div>
              <!-- usa -->
              <div class="slide"><img src="assets/images/logo/usa/usa1.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa2.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa3.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa4.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa5.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa6.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa7.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa8.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa9.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa10.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa11.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa12.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa13.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa14.png"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa15.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa16.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa17.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa18.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa19.jpg"></div>
              <div class="slide"><img src="assets/images/logo/usa/usa20.jpg"></div>
           </section>
        </div>

        <div class="brands">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <div class="brands_slider_container">
                            <div class="owl-carousel owl-theme brands_slider">
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo2.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo3.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo4.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                               <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                 <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                 <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div>
                                <div class="owl-item">
                                    <div class="brands_item d-flex flex-column justify-content-center"><img src="assets/images/uni/logo1.jpg"></div>
                                </div> 
                            </div> <!-- Brands Slider Navigation -->
                            <div class="brands_nav brands_prev"><i class="fas fa-chevron-left"></i></div>
                            <div class="brands_nav brands_next"><i class="fas fa-chevron-right"></i></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- end of logo -->
        <style type="text/css">
          #instafeed {
          max-width:1080px;
          width: 100%;
          margin: auto;
          display: flex;
          flex-wrap: wrap;

           a {
            display: flex;
            align-items: center;
            position: relative;
            width: 50%;
            background: white;
            
            @media only screen and (min-width: $lg) {
              width: 20%;
            }
            
            img {
              display: block;
              width: 100%;
            }
          }
        }
        </style>

      <div class="elfsight-app-b83a44a5-263d-4c0c-8c26-0c014ba45d37"></div>   
<!--       <script src="https://apps.elfsight.com/p/platform.js" defer></script>
      <div class="elfsight-app-30e94b4a-a372-4d81-bdb3-3826207d077a"></div> -->
      <script src="https://apps.elfsight.com/p/platform.js" defer></script>
<div class="elfsight-app-d4258c2f-15d2-4fc5-9ab4-46a08cdd6ac8"></div>
        <?php include('inc/footer.php'); ?>
    </div>
    <?php include('inc/js.php'); ?> 
  </body>
  </html>
  <script type="text/javascript">
  $(document).ready(function(){
    if($('.brands_slider').length)
    {
    var brandsSlider = $('.brands_slider');
    brandsSlider.owlCarousel(
    {
    loop:true,
    autoplay:true,
    autoplayTimeout:5000,
    autoplay: true,
    autoplaySpeed: 700,
    nav:false,
    dots:true,
    autoWidth:true,
    items:14,
    margin:42
    });

    if($('.brands_prev').length)
    {
    var prev = $('.brands_prev');
    prev.on('click', function()
    {
    brandsSlider.trigger('prev.owl.carousel');
    });
    }

    if($('.brands_next').length)
    {
    var next = $('.brands_next');
    next.on('click', function()
    {
    brandsSlider.trigger('next.owl.carousel');
    });
    }}
  });
  </script>
<!--   <script type="text/javascript">
    var userFeed = new Instafeed({
    get: 'user',
    userId: 'oecindia',
    // clientId: '924f677fa3854436947ab4372ffa688d',
    accessToken: 'IGQVJXZA3NlRWVwVTFLNW5PSmU3eXh3NHMxTXplQWRrV0xrZAEVGeWRVcE40dkp6UWVnYmR1N2hXalYyZAjB6bUExa01GakZAhRUdrQlRIZAnA5cUJGV3Q4WkxlOE9RTEFkS2lZAdU82U2ZAJLXdwNkF6RFJQSgZDZD',
    target:'instafeed',
    resolution: 'standard_resolution',
    // template: '<a href="{{link}}" target="_blank" id="{{id}}"><img src="{{image}}" /></a>',
    // sortBy: 'most-recent',
    limit: 15,
    links: false
  });
  userFeed.run();
  </script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('.customer-logos').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 700,
      arrows: false,
      dots: false,
      pauseOnHover: false,
      responsive: [{
        breakpoint: 768,
        settings: {
          slidesToShow: 4
        }
      }]
    });
  });
  </script> -->
   <script type="text/javascript">
    $(document).ready(function(){
      $('.customer-logos').slick({
      slidesToShow: 4,
      slidesToScroll: 1,
      autoplay: true,
      autoplaySpeed: 700,
      arrows: false,
      dots: false,
      pauseOnHover: false,
      responsive: [{
          breakpoint: 768,
          settings: {
              slidesToShow: 4
          }
      }, {
          breakpoint: 520,
          settings: {
              slidesToShow: 3
          }
      }]
    });
  });
  </script>