<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
  
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the Right Career</h2>
                                <h1>New Zealand</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span> New Zealand ?</span></h2>
                    <p>New Zealand is committed to investing in innovation and cutting-edge research
providing an excellent standard of higher education recognized across the globe. A
multicultural society, this beautiful island country welcomes diversity and cultural
heterogeneity. Studying in New Zealand includes a wide range of opportunities for
international students. Here are some important reasons why you should consider
applying to universities in New Zealand.</p><br/>
                </div>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="new-zealand">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">                         
                            <ul class="menu">
                                <li><i class="fas fa-check"></i>All eight of New Zealand’s universities rank in the top 3% in the world.</li>
                                <li><i class="fas fa-check"></i>Undergraduate and postgraduate universities in New Zealand are reputed for their modern up-to-date learning content and practical teaching style that makes students job-ready.</li>
                                <li><i class="fas fa-check"></i>Laws in New Zealand offer international students the opportunity to work as they study to help them understand the New Zealand work culture and gain financial support.</li>
                                <li><i class="fas fa-check"></i> New Zealand’s peaceful culture offers a great learning environment.</li>
                                <li><i class="fas fa-check"></i> New Zealand also offers many opportunities to learn life skills.</li>
                                <li><i class="fas fa-check"></i>All courses are delivered in English, making it easy for international students educated in English medium. </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    
                                    <?php
                                    $where="county='new_zealand'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

             <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$29.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>Engineering </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering  Courses</a></h5>
                                    <p> Choose from branches like Computer Science, Information Technology and Geotechnical engineering to expand your horizons in technical fields.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>Free</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                        <h6>MBA</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">MBA Courses</a></h5>
                                    <p> A master of business administration is an internationally recognized degree that provides in-depth theory and practical understanding of business management.</p>
                                   <!--  <ul class="menu">
                                        <li><i class="fas fa-check"></i>Information systems </li>
                                        <li><i class="fas fa-check"></i>Software development</li>
                                        <li><i class="fas fa-check"></i> Networking </li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/edu.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Hotel Management</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Hotel Management</a></h5>
                                    <p> Learn Hotel Management and Tourism Management with a unique strategic approach that gives you hands-on exposure to the challenges of the hospitality industry.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$49.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                        <h6>Culinary Sciences </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Culinary Sciences </a></h5>
                                    <p>Develop advanced cookery skills such as patisserie and gastronomy,  administrative skills and learn about kitchen management. </p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i> Statistics </li>
                                        <li><i class="fas fa-check"></i> Specialized Mathematics</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/tour.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$69.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                        <h6>Other </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Other </a></h5>
                                    <p> Disaster Management, Engineering Management, Food Processing, Applied Finance.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education will vary according to the university you apply to and the course you are planning to pursue. In general, New Zealand offers high-quality education at a relatively lower cost compared to European study destinations. Here is an approximate amount of tuition fees you may be required to pay per year in New Zealand.</p>
                    <br/><br/>
                    <ul style="list-style-type: none;">
                        <li><i class="fas fa-check"></i>Undergraduate Courses: 19000 to 30000 NZD</li>
                        <li><i class="fas fa-check"></i>Postgraduate Courses:  24000 to 38000 NZD</li>
                    </ul>
                </div>

                <div class="section-title">
                    <h2>Cost of <span> Living in New Zealand </span></h2>
                    <p>Living costs in New Zealand may vary according to the city you live in. Every educational institution in New Zealand offers various options for accommodation to students which you can choose Based on your convenience and affordability, you may choose from a variety of options
for student accommodation offered by all New Zealand universities. Including food, transportation, entertainment and accommodation, you can expect to spend up to 18000 NZD per annum on living expenses. You are also expected to show New Zealand visa authorities an amount of 15000 NZD as a provision for living expenses.</p>
                    <br/>
                    <p>Educational institutions in New Zealand offer the option of halls of residence, dormitories, homestay, private apartments and flats for accommodation.</p>
                </div>

                <div class="section-title">
                    <h2>Health <span> Insurance </span></h2>
                    <p>As international students are not entitled to public health services in New Zealand, you need to take medical insurance cover for the duration of your stay before arriving in New Zealand. Usually, health insurance can cost up to 600 NZD <!-- or 32000 INR -->.</p>
                </div>
            </div>

            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    