<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the Right Career</h2>
                                <h1>Australia </h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span>Australia?</span></h2>
                    <p>Australia is a rich multicultural society that welcomes people of all ethnicities and backgrounds. Offering a world class education set in a land of natural wonders, Australia provides a rich and rewarding personal experience. Here’s a look at some aspects that make Australia a great education destination for international students.</p><br/>
                </div>
            </div>
            <!-- Add new Code -->
         	<!--<section class="campus-visit-area"> -->
            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                            	<div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                            		<div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                		<img src="assets/images/aus.jpg" alt="australia">
                                	</div>
                            		<!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                		<img src="assets/images/aus.jpg" alt="">
                            		</div> -->
                            	</div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">
                            <!-- <h2 class="campus-title">Why Study in Australia?</h2> -->                            
                            <ul class="menu">
                                <li><i class="fas fa-check"></i><strong>Affordability –</strong> Australian higher educational programmes consist of shorter more intensive courses. This makes the whole degree more affordable for students.</li>
                                <li><i class="fas fa-check"></i><strong>CRICOS Courses –</strong>  Students can opt for prestigious and globally recognized CRICOS courses by Australian Universities.</li>
                                <li><i class="fas fa-check"></i> <strong>Study the Latest in Technology & Trends  –</strong> The Australian education system is reputed for curriculums that incorporate the latest in science & technology as well as utilising research on modern trends in marketing & management.</li>

                                <li><i class="fas fa-check"></i> <strong>No Bridge Course Required –</strong> Australia accepts the Indian Graduation Standard of 12+3 unlike European and American education systems which require 12+4</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <!-- </section> -->
            <!-- end of new code -->
            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <!-- new code -->
                                
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='australia'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                    
                                    
                                    <!-- <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingNine">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">UNIVERSAL INSTITUTE OF TECHNOLOGY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="https://www.uit.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div> -->
                                </div>
                                <!-- end of new code -->
                                <!-- <div class="accordion" id="accordionExample">
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">ATMC</button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                            <div class="card-body">
                                               
                                                <a href="https://www.atmc.edu.au/">Visit Website</a>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">AUSTRALIAN CENTRE OF FURTHER EDUCATION</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://acfe.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">CAMBRIDGE INTERNATIONAL COLLEGE PVT LTD</button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>Melbourne & Perth Campus</p>
                                                <a href="https://www.cambridgecollege.com.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">EDUCATION ACCESS AUSTRALIA</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="https://www.eaa.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFive">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">OCEANIA COLLEGE OF TECHNOLOGY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="https://oct.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSix">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">OCEANIA POLYTECHNIC INSTITUTE OF EDUCATION</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="https://opie.vic.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                     <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSeven">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">THE IMPERIAL COLLEGE OF AUSTRALIA</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="http://www.imperial.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingEight">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">THE UNIVERSITY OF NOTRE DAME AUSTRALIA</button>
                                            </h2>
                                        </div>
                                        <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="http://www.imperial.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingNine">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">UNIVERSAL INSTITUTE OF TECHNOLOGY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
                                            <div class="card-body">
                                                  <a href="https://www.uit.edu.au/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                </div> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
	            <div class="section-title">
	            	<h2>Popular <span>Courses</span></h2>
	                <p>The Australian education system offers a wide array of courses covering various fields of study. Choose a full-time or part-time course, in a domain of your interest at the graduate or postgraduate level. Listed below are some popular areas of study for international students. <!-- opt for – --></p>
	            </div><!-- Section Title /-->
	            <div class="container">
	            	<div class="row">
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/our-courses-img1.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>$29.00</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
	                                    <h6>Engineering</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Engineering Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Chemical </li>
	                                    <li><i class="fas fa-check"></i> Electronics </li>
	                                    <li><i class="fas fa-check"></i> Mechanical </li>
	                                    <li><i class="fas fa-check"></i> Aeronautics </li>
	                                    <li><i class="fas fa-check"></i> Telecommunications </li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                    
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
	                                    <h6>Information Technology</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Information Technology Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i>Information systems </li>
	                                    <li><i class="fas fa-check"></i>Software development</li>
	                                    <li><i class="fas fa-check"></i> Networking </li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                    
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>$59.00</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
	                                    <h6>Management </h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Management Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i>  Marketing </li>
	                                    <li><i class="fas fa-check"></i>  Finance</li>
	                                    <li><i class="fas fa-check"></i>  Human Resources</li>
	                                    <li><i class="fas fa-check"></i>  Operations Management</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                    
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/our-courses-img4.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>$49.00</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
	                                    <h6>Mathematics / Statistics</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Mathematics / Statistics Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Statistics </li>
	                                    <li><i class="fas fa-check"></i> Specialized Mathematics</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                    
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/our-courses-img5.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>$69.00</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
	                                    <h6>Health Sciences</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Health Sciences Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Nursing</li>
	                                    <li><i class="fas fa-check"></i> Nutrition</li>
	                                    <li><i class="fas fa-check"></i> Family Healthcare </li>
	                                    <li><i class="fas fa-check"></i> Pharmaceutical Science</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                    
	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                    	<div class="course-warp">
	                        	<div class="course-img">
	                                <img src="assets/images/help/our-courses/agr.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Agriculture</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                            	<h5><a href="#">Agriculture Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Agricultural Sciences</li>
	                                    <li><i class="fas fa-check"></i>  Horticulture</li>
	                                    <li><i class="fas fa-check"></i>  Forestry</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/compu.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Science & Computing</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Science & Computing Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i>  Computer Science</li>
	                                    <li><i class="fas fa-check"></i> Chemistry</li>
	                                    <li><i class="fas fa-check"></i> Biotechnology</li>

	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/comm.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Communications </h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Communications Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Mass communication</li>
	                                    <li><i class="fas fa-check"></i> Journalism</li>
	                                    <li><i class="fas fa-check"></i> PR</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/tour.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Hospitality & Tourism</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Hospitality & Tourism</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Hotel Management</li>
	                                    <li><i class="fas fa-check"></i> Tourism Management</li>
	                                    <li><i class="fas fa-check"></i> Culinary Sciences</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/lw.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Administration & Law</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Administration & Law</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Accountancy</li>
	                                    <li><i class="fas fa-check"></i> Commerce</li>
	                                    <li><i class="fas fa-check"></i> Administration</li>
	                                    <li><i class="fas fa-check"></i> Finance</li>
	                                    <li><i class="fas fa-check"></i> Economics</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/edu.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Education</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Education Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Teaching</li>
	                                    <li><i class="fas fa-check"></i> Early Childhood Education</li>
	                                    <li><i class="fas fa-check"></i> Special Education</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/huminities.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Humanities</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Humanities </a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i>  English</li>
	                                    <li><i class="fas fa-check"></i>  History</li>
	                                    <li><i class="fas fa-check"></i>  Psychology</li>
	                                    <li><i class="fas fa-check"></i>  Liberal Studies</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/fasion.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Visual & Performing Arts</h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Visual & Performing aria-controls</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i>  Arts</li>
	                                    <li><i class="fas fa-check"></i>  Graphic Design</li>
	                                    <li><i class="fas fa-check"></i>  Fashion Design</li>
	                                    <li><i class="fas fa-check"></i>  Performing Arts</li>
	                                    <li><i class="fas fa-check"></i>  Music</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>

	                    <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
	                        <div class="course-warp">
	                            <div class="course-img">
	                                <img src="assets/images/help/our-courses/ge.jpg" alt="Our Courses">
	                                <!-- <div class="course-price">
	                                    <h6>Free</h6>
	                                </div> -->
	                                <div class="course-teacher">
	                                    <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
	                                    <h6>Social Studies </h6>
	                                </div>
	                            </div>
	                            <div class="course-text">
	                                <h5><a href="#">Social Studies Courses</a></h5>
	                                <!-- <p>There are many variations of passages of Lorem Ipsum available.</p> -->
	                                <ul class="menu">
	                                    <li><i class="fas fa-check"></i> Geography</li>
	                                    <li><i class="fas fa-check"></i> Behavioral Studies</li>
	                                    <li><i class="fas fa-check"></i> Sociology</li>
	                                </ul>
	                                <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
	                            </div>
	                        </div>
	                    </div>
	                </div><!-- Row /-->
	            </div><!-- Container -->
       		</div>

       		<div class="module">
                <div class="section-title">
                    <h2>Getting an <span> Australian Visa </span></h2>
                    <p>You can apply for an Australian Student visa after you have been accepted to study full-time at an Australian University. If you are under 18 years of age, you also need to make welfare arrangements for the duration of your course.<br/> The stepwise process is outlined below. </p>
                </div>
	       
	        	<ul class="progressbar">
				    <li class="step"><p>Collect the requisite documents</p></li>
				    <li class="step"><p>Preparing the paperwork</p></li>
				    <li class="step"><p>Payments</p></li>
				    <li class="step"><p> Applying for the  Student visa</p></li>
				    <li class="step"><p>Providing the additional documents</p></li>
				    <li class="step"><p>Track & Manage your application online</p></li>
				    <li class="step"><p> Get the visa decision</p></li>
				</ul>
				<div class="our-courses grey-bg grey-bg-color module">
					<div class="section-title">
	                    <h2>Cost of <span> Education </span></h2>
	                    <p>The cost of education in any overseas destination will vary according to the course and university you choose. Most universities expect students to pay the tuition fees up-front. If you choose to study in Australia the average fees for an undergraduate course will be AUD 19000 per year and for doctoral programs, it is around AUD 28000 per year. Post-Graduation courses are approximately AUD 25000 per year. These figures are approximations to guide students and provide a ball-park estimate. </p>
	                </div>

	                 <div class="section-title">
	                    <h2>Cost of <span> Living in Australia </span></h2>
	                    <p>International students living in Australia spend up to AUD 19000 per year on accommodation, food and other living expenses. This could vary depending on the individual circumstances and the city you live in. </p>
	                </div>

	                 <div class="section-title">
	                    <h2>Health <span> Insurance </span></h2>
	                    <p>When living in Australia as a student, it is compulsory to have a health insurance policy. Also known as the overseas Student Health Cover (OSHC) – it costs approximately AUD 650 to AUD 700 per annum and it is also mandatory for any dependents who may be living with you for the duration of your studies. </p>
	                </div>
            	</div>
			</div>
        </div>
            <!-- end of courses List -->
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>

        <?php include('inc/js.php'); ?>
    </body>
</html>    

<!-- popular courses -->

<!-- end -->