self.addEventListener('fetch',function(event){});
self.addEventListener('install',function(event){});
self.addEventListener('activate',function(event){});
