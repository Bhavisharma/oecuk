<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
   <!-- <?php
        //$sql="SELECT * FROM `counter` WHERE `page`='privacy-policy' AND `date`='".date('Y-m-d')."' ";
                // $result = mysqli_query($conn,$sql);
      //  $result =$mysqli->query($conn,$sql);
         //$result = mysqli_query($conn,$sql);
        // $result = $mysqli ->query($sql,$conn);

        //$result = $mysqli->query($result,$conn);

        //if($result === TRUE)
        {
           // echo "suucess";
        }
        //else
        {
                   //echo "error";
        }

       // var_dump($result);

       // $row=$result->fetch_array(MYSQLI_ASSOC);
       // if(count($row)>0)
        {
       //     $update = "UPDATE `counter` SET `count`=".($row['count']+1)." WHERE `page`='privacy-policy'";
           // $mysqli->query($update);
        }
       // else
        {
         //   $insert = "INSERT INTO `counter` (`count`,`page`,`date`) VALUES (1,'privacy-policy','".date('Y-m-d')."')";
         //   $mysqli->query($insert);
        }
    ?>-->
    <body>
        <div class="main-container about-us-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h1>Privacy Policy</h1>
                            </div>
                        </div>  
                    </div>
                </div>
            </div>
            <div class="why-chose-us module">
                <div class="section-title">
                    <h2>Privacy Policy  & <span> GDPR POLICY</span></h2>                
                    <p class="privacy" style="font-style: normal;">At OEC we understand that your privacy is important to you. We are committed to meeting your expectations and will comply with all applicable privacy and data protection legislation in relation to your personal information and sensitive information. <br/> At OEC we stress the importance of privacy and are committed to earning the trust of our participants, partners, employees, volunteers and suppliersby adopting high standards for the protection of personal information. Below we will outline the type of information normally collected in each of these circumstances, the reasons for doing so, how we will use it and store it. The rest of this policy provides you with more detail of our privacy and personal information handling practices.<br/> 
                    OEC is an organisation that assists individuals to study abroad. This requires us to collect personal information from you. Our policy outlines the type of personal information we collect and receive, the circumstances in which we collect or receive personal information, the policies and procedures we have established outlining its use and storage, and for sharing certain types of personal information in certain limited circumstances.<br/> 
                    In this policy, personal information means information about anyone that is personally identifiable like a name, address, e-mail address or phone number, and that is not otherwise publicly available. We collect information on our users through registration and use of the website, through cookies, where you choose to disclose data in postings, and when you register for our email newsletter.<br/> 
                    Certain services that we provide may involve the collection of additional information, such as your geographic location from time to time, to enable our services to be provided as designed. In particular, this pertains to the use of geolocation to suggest the most appropriate local version of our website. The minimum information we need to register a user to our email newsletter is an email address. We will ask further questions for different services. When you register with OEC, we ask for your First
                    Name, Last Name, City, Email Id, Mobile No. and Tel. No. Once you register with OEC and sign in to our
                    services, you are not anonymous to us.<br/> 
                    Following registration to our email newsletter or counselling service, you may be sent regular emails from OEC. Also, during registration, you will be requested to register your mobile phone and email id to receive text messages, notifications, and other services to your wireless device. By registration you
                    authorize us to send sms/email alerts to you for your login details and alerts on requests or some advertising messages/emails from us. You will be able to unsubscribe from these at any time.<br/> 
                    We do our utmost to protect the privacy of our users through the appropriate use of secure technologies. This means: We ensure that we have appropriate physical and technological security measures to protect your information. We ensure that when we outsource any processes that the service provider employs appropriate security measures.<br/> 
                    We will respect your privacy. You will receive marketing emails from OEC only if you are voluntarily registered for our email newsletter. We will never share your email address with any third parties without your permission. We will collect and use individual user details only where we have legitimate business reasons and are
                    legally entitled to do so. We will be transparent in our dealings with you as to what information about you we will collect and how we will use your information. We will use personal data only for the purpose(s) for which they were originally collected and we will ensure personal data are securely disposed of. Upon request by the User OEC will erase the User’s Personally Identifiable Information from OEC’s database (Right to erasure under Article 17 of the
                    GDPR).<br/> 
                    OEC determines the purpose and means of processing of information including the User’s Personally identifiable Information and is the controller with respect to the information collected through the Website in terms of Article 4 (7) of GDPR. OEC shall be responsible for processing of all information
                    collected through the Website. OEC reserves the right to amend the Privacy Policy from time to time to reflect changes in the
                    applicable law, OEC’s data collection, processing and usage practices, the features of the Website or
                    advances in technology. The provisions of GDPR will be applicable to the extent of processing of Personally Identifiable
                    Information of the Users.<br/> 
                    Use of cookies : We use cookies for various reasons:
                    1. For statistical purposes to track how many individual unique users come to our sites and how often
                    they visit. We collect data listing which pages are most frequently visited and by which users and from
                    which countries.<br/> 
                    2. OEC may use cookies to suggest and deliver content which we believe may be of interest to you,
                    based on your geographic location.
                    By using our sites, you are agreeing to the use of cookies as described.
                    Updating your Personal Information
                    If you would like to update or remove some or all of your personal information from our system,
                    please email us at admin@oecindia.com and we will be happy to comply with your request.
                    For Overseas Education Centre</p>
                </div> 
            </div>
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    