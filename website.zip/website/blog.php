<?php
include('db.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?> 
    </head>
    <body>
        
        <div class="main-container about-us-page">
              <?php include('inc/header.php'); ?>            
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                            	<h1>Blog</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/5.3.45/css/materialdesignicons.css" integrity="sha256-NAxhqDvtY0l4xn+YVa6WjAcmd94NNfttjNsDmNatFVc=" crossorigin="anonymous" />

<div class="container mt-100 mt-60">
    <div class="row">
        <div class="col-12 text-center">
            <div class="section-title mb-4 pb-2">
                <h4 class="title mb-4">Latest Blog &amp; News</h4>
                <p class="text-muted para-desc mx-auto mb-0">Build responsive, mobile-first projects on the web with the world's most popular front-end component library.</p>
            </div>
        </div><!--end col-->
    </div><!--end row-->

<?php
global $conn;
$sql = "SELECT * FROM blogs";
$result = $conn->query($sql);
?>

    <div class="row">
        <?php
        if ($result->num_rows > 0) {
          // output data of each row
          while($row = $result->fetch_assoc()) {
              ?>
              <div class="col-lg-4 col-md-6 mt-4 pt-2">
                    <div class="blog-post rounded border">
                        <div class="blog-img d-block overflow-hidden position-relative">
                            <img src="backend\images\events\<?=$row['image'];?>" class="img-fluid rounded-top" alt="">
                            <div class="overlay rounded-top bg-dark"></div>
                        </div>
                        <div class="content p-3">
                            <small class="text-muted p float-right">19th Oct, 19</small>
                            <small><a href="blog-details.php" class="text-primary"></a></small>
                            <h4 class="mt-2"><a href="blog-details.php?name=<?=$row['slug'];?>" class="text-dark title"><?=$row['title'];?></a></h4>
                            
                            
                        </div>
                    </div><!--end blog post-->
                </div><!--end col-->
              <?php
          }
        } else {
          echo "0 results";
        }
        ?>
    
    </div><!--end row-->
</div>
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        <?php include('inc/js.php'); ?>
     </body>
     </html>
        
        
    