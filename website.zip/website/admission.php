<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <!-- h2>Admission Page</h2> -->
                                <h1>Contact For Admission</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- <div class="appointment grey-bg grey-bg-color">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-8 col-lg-8 offset-lg-2 offset-md-2 col-padding-y">
                            <div class="section-title">
                                <h2>Admission<span> Process</span></h2>
                            </div>
                            <p>There are several formalities to follow, in order to complete admission process. Deadlines of the department concerned. Deadlines of the Graduate School/University/College. Pre-requisite Tests information and requirements (TOEFL, GRE, GMAT, IELTS etc.)</p>
                            <p>Application fees and payment formalities. List of documents required for admission. Various locations to where the application material has to be sent. Different approaches to know the admission status. Contact methods to know about the Offer Letter /I-20 dispatch status.</p>
                            <p>Further steps to confirm the admission with your chosen university OEC’s expertise and regular interaction with the admission offices of most universities/colleges helps us in keeping track with all the above aspects and give you unsurpassed service while completing the admission formalities on your behalf. Please refer to list of Documents Required for each Country for Admission.</p>
                        </div>
                    
                    </div>
                </div>
            </div> -->

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>Admission<span> Process</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">STEP 1: COUNSELLING</button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>We offer free counselling by our expert personal counselors.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our counsellors have extensive knowledge about a wide range of courses offered at reputable universities around the world.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>We also offer customized packages to suit your requirements and to assist with your overseas education.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Your profile consists of details like your academic background, your interests, your expectations from your overseas education, and the destination of your choice, if any.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>The objective of our counsellors is to ensure that you get an admission in the course most suited to your profile.</li> 
                                                </ul>
                                                <!-- <a href="https://www.amity.ac.uk/">Visit Website</a> -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">STEP 2: IDENTIFYING THE COURSE, COUNTRY & UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>For getting the most out of your overseas education, identifying the right course is of prime importance. Our counsellors select the best opportunities for you after considering all the factors. They invest time and efforts to understand your preferences, your academic inclination, financial parameters, and most importantly, your career plan. </li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our counsellors conduct this exercise with the utmost professionalism and don’t recommend anything unless they are sure about it.The counsellor then prepares a shortlist of courses and universities that suit your profile. This shortlist includes options of universities which may or may not be represented by OEC. But irrespective of that, our counsellors will make their best efforts to facilitate your admissions process. Our biggest priority at this stage, is to help the student in making an informed decision. Usually, once our counsellors provide the student with a shortlist, the student spends some time thinking over the choices and consulting family members & friends.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>We realize that choosing an overseas education option is a decision that will affect your entire career and therefore, the team at OEC does everything they can to ensure that you make the right choice.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our counsellors have detailed knowledge about the different universities and courses available to students. They can also help you connect with someone at the university of your choice, if needed.</li>
                                                </ul>
                                                <!-- <a href="https://aru.ac.uk/">Visit Website</a> -->
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">STEP 3: DETERMINING THE TESTS & REQUIRED TEST PREP</button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                            <div class="card-body">
                                               <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Applications to overseas universities have many important aspects. You will need to write essays, statement of purpose and other details. The grammar, tone, structure content and recommendation letters - everything needs to be perfect for an application to be well-compiled.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Ensuring an error-free application for all our students is important for us. At OEC, we leave no stone unturned to make sure that all your applications have the right documentation, and there are no errors. Every university has its own requirements and criteria for application assessment. We help you compile all the required documents. </li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our counsellors help you determine the sections of your application that need to be highlighted to boost your chances of admission. All the applications are reviewed multiple times to rectify errors and to ensure the best presentation possible.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Once the application is sent, our counsellors also help you keep track of the status of the application.</li>
                                                </ul>
                                              <!--  <a href="https://www.bangor.ac.uk/">Visit Website</a> -->
                                            </div>
                                        </div>
                                    </div>
                                    <!-- <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingfour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">STEP 4: COMPILING DOCUMENTS & COMPLETING THE APPLICATION</button>
                                            </h2>
                                        </div> -->
                                       <!--  <div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordionExample">
                                            <div class="card-body">
                                               <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our goal is to provide clear and accurate information to students and universities. We provide free consultation and guidance to students, for helping them choose the right university and courses.</li> -->
                                                    <!-- <li><i class="fas fa-check"></i>Ensuring an error-free application for all our students is important for us. At OEC, we leave no stone unturned to make sure that all your applications have the right documentation, and there are no errors. Every university has its own requirements and criteria for application assessment. We help you compile all the required documents. </li>
                                                    <li><i class="fas fa-check"></i>OOur counsellors help you determine the sections of your application that need to be highlighted to boost your chances of admission. All the applications are reviewed multiple times to rectify errors and to ensure the best presentation possible.</li>
                                                    <li><i class="fas fa-check"></i>Once the application is sent, our counsellors also help you keep track of the status of the application.</li> -->
                                                <!-- </ul>
                                              <  <a href="https://www.bangor.ac.uk/">Visit Website</a> -->
                                            <!-- </div>
                                        </div>
                                    </div> -->
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingfive">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">STEP 4: INTERVIEW PREPARATION</button>
                                            </h2>
                                        </div>
                                        <div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordionExample">
                                            <div class="card-body">
                                              <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>OEC offers a specialized preparation module for helping students get ready for interviews at different universities. Our experts are familiar with the kind of questions usually asked by interviewers during university admissions.</li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Not only that, we have representatives from various universities visiting our center to meet the applicants. During these visits they often conduct spot assessments, make spot offers and also give application fee waivers. Bright students with worthy profiles can also use this opportunity to avail good scholarships.</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingsix">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsesix" aria-expanded="false" aria-controls="collapsesix">STEP 5: VISA</button>
                                            </h2>
                                        </div>
                                        <div id="collapsesix" class="collapse" aria-labelledby="headingsix" data-parent="#accordionExample">
                                            <div class="card-body">
                                               <ul class="menu">
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>OEC holds a 99% success rate in visa application approvals. We make efforts to ensure that students are informed about all the latest rules and regulations about visa application. If there are any changes in the visa procedures or immigration laws of the country you are applying to, our counsellors inform you beforehand. </li>
                                                    <li><i class="fas fa-check" style=" margin-right: 15px;"></i>Our experts work with you to compile the required documents including financial statements and other documents to avoid inadvertent delays or rejections. Another special service offered by OEC is preparation for the visa interviews. Wherever needed, we also conduct mock interviews to help students understand the dos and don’ts that they need to follow to succeed in the visa interview. </li>
                                                </ul>
                                               <!--  <a href="https://www.bcu.ac.uk/">Visit Website</a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    

<!-- old code -->
<!-- <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">AMITY UNIVERSITY LONDON</button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.amity.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">ANGLIA RUSKIN UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://aru.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">BANGOR UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>BANGOR & LONDON CAMPUS</p>
                                               <a href="https://www.bangor.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">BATH SPA UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.bathspa.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingFive">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">BIRMINGHAM CITY UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.bcu.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSix">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">BIRMINGHAM CITY UNIVERSITY INTERNATIONAL COLLEGE (BCUIC)</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.bcuic.navitas.com/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingSeven">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">BUCKS NEW UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://bucks.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingEight">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">CAMBRIDGE RUSKIN INTERNATIONAL COLLEGE (CRIC)</button>
                                            </h2>
                                        </div>
                                        <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.cric.navitas.com/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingNine">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">CAMBRIDGE SCHOOL OF VISUAL & PERFORMING ARTS</button>
                                            </h2>
                                        </div>
                                        <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.csvpa.com/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                        <div class="card-header" id="headingTen">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">CANTERBURY CHRISTH CHURCH UNIVERSITY</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">
                                            <div class="card-body">
                                                <a href="https://www.canterbury.ac.uk/">Visit Website</a>
                                            </div>
                                        </div>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
</div> -->
<!-- end  -->