<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
   
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the right Career</h2>
                                <h1>Dubai</h1>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="about-us module">
                <div class="section-title">
                    <h2>Study in <span>dubai</span></h2>
                    <p>Often called the “Pearl of the Arabian Gulf”, Dubai is a prosperous nation replete with skyscrapers, flourishing businesses and a world class education system. Providing diverse cultural experiences and a perfect balance between East and West, Dubai is a safe and welcoming destination for students from all around the world. International universities have opened campuses or created partnerships in the UAE, offering students the opportunity to obtain UK, Canadian and American accredited degrees.Here are some more reasons to choose Dubai as your study destination.</p><br/>
                </div>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="dubai">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">
                            <!-- <h2 class="campus-title">Why Study in Australia?</h2> -->                            
                            <ul class="menu">
                                <li><i class="fas fa-check"></i><strong>Tuition Fees –</strong> Dubai offers many courses in the undergraduate and postgraduate levels with affordable tuition fees.</li>
                                <li><i class="fas fa-check"></i><strong> Scholarships –</strong> Universities in Dubai offer various opportunities for students to avail scholarships to reduce tuition fees.</li>
                                <li><i class="fas fa-check"></i> <strong>Job Opportunities –</strong> Dubai’s growing economy and flourishing businesses offer great employment opportunities for students fresh out of college. </li>
                                <li><i class="fas fa-check"></i> <strong>Work-Permit for Students –</strong>  Labor regulations in Dubai allow students to work for up to 20 hours in a week. You can also avail a work-permit to work as an intern in the industry of your choice.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                    
                </div>
                <div class="container">
                    <div class="row">
                        
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                            <!--    <h3>List Of Universities</h3> -->
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='dubai'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                  <!--   <p>The Australian education system offers a wide array of courses covering various fields of study. Choose a full-time or part-time course, in a domain of your interest at the graduate or postgraduate level. Listed below are some popular areas of study that students in India opt for –</p> -->
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$29.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>Architecture </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Architecture  Courses</a></h5>
                                    <p>Dubai is home to some of the best architecture in the world.  A professional course in architecture can help you understand the science of building design and urban planning.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>Free</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                        <h6>Engineering</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering Courses</a></h5>
                                    <p> Engineering is a coveted field of study for students in Dubai, due to the advanced course curriculum and the demand for competent engineers in the Dubai employment market.</p>
                                   <!--  <ul class="menu">
                                        <li><i class="fas fa-check"></i>Information systems </li>
                                        <li><i class="fas fa-check"></i>Software development</li>
                                        <li><i class="fas fa-check"></i> Networking </li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/edu.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$59.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>MBA</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">MBA</a></h5>
                                    <p>A master of business administration is an internationally recognized degree that covers electives like accountancy, economics, marketing and operations.</p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i>  Marketing </li>
                                        <li><i class="fas fa-check"></i>  Finance</li>
                                        <li><i class="fas fa-check"></i>  Human Resources</li>
                                        <li><i class="fas fa-check"></i>  Operations Management</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$49.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                        <h6>Accounts & Finance</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Accounts & Finance</a></h5>
                                    <p>Many universities offer courses in accounting and finance which helps you get a better understanding of financial instruments, investments and transactions.</p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i> Statistics </li>
                                        <li><i class="fas fa-check"></i> Specialized Mathematics</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/tour.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$69.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                        <h6>Tourism & Travel </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Tourism & Travel </a></h5>
                                    <p>Universities in Dubai offer courses that can help you develop the management skills needed for a successful career in travel, tourism and hospitality industry.</p>
                                   <!--  <ul class="menu">
                                        <li><i class="fas fa-check"></i> Nursing</li>
                                        <li><i class="fas fa-check"></i> Nutrition</li>
                                        <li><i class="fas fa-check"></i> Family Healthcare </li>
                                        <li><i class="fas fa-check"></i> Pharmaceutical Science</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

            <!-- add new  -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting a <span> Dubai Visa</span></h2>
                    <p>Once you have successfully applied to the university of your choice and provided the
necessary documentation, it is the university that will apply for the Dubai student visa,
on your behalf. Here are the important things to know about Dubai’s visa application
process.</p>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-img">
                                <img src="assets/images/help/about-img.jpg" alt="About">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-text">
                            <ul class="menu">
                                <li><i class="fas fa-check"></i>  The minimum English ability requirement is evaluated through IELTS.</li>
                                <li><i class="fas fa-check"></i> Visa Fees: 3000 AED.</li>

                                <li><i class="fas fa-check"></i> Required documents include academic mark sheets, notarized and attested transcripts, IELTS test results, and bank statements.</li>
                                <li><i class="fas fa-check"></i> You will also be required to submit a receipt of payment of your tuition fees for the first year.</li>
                                <li><i class="fas fa-check"></i> Visa approval or renewal needs at least twenty to twenty-five working days.</li>
                                <li><i class="fas fa-check"></i> You will need to apply at least sixty days before your course starting date.</li>

                            </ul>
                        </div>
                    </div>
                </div>
                </div>
                </div>
            </div>

            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education will vary according to the university you apply to and the course you are planning to pursue. However, as a general idea, the tuition fees for studying in Dubai are.</p>

                    <ul style="list-style-type: none;">
                        <li><i class="fas fa-check"></i>Undergraduate Courses: 30000 to 35000 AED</li>
                        <li><i class="fas fa-check"></i>Postgraduate Courses: 40000 to 65000 AED</li>
                    </ul>
                </div>

                <div class="section-title">
                    <h2>Cost of <span> Living in Dubai </span></h2>
                    <p>Living costs in Dubai depend on the lifestyle the student wants to lead. Universities
may offer accommodation packages inclusive of 24-hours security, utilities and free
shuttle service between campuses. Alternately, students may decide to independently
rent and live off campus in which case the following costs may apply.</p>
                </div>

                <!-- table -->
                <div class="container">
                  <table class="table table-dark table-hover">
                    <thead>
                      <tr>
                        <th>Expense</th>
                        <th>Amount (AED) per month</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Accommodation</td>
                        <td>2500 to 5000</td>
                      </tr>
                      <tr>
                        <td>Water & Electricity</td>
                        <td>Up to 500</td>
                      </tr>
                      <tr>
                        <td>Transportation</td>
                        <td>Up to 300</td>
                      </tr>
                      <tr>
                        <td>Internet / Telephone</td>
                        <td>Up to 120</td>
                      </tr>
                      <tr>
                        <td>Food</td>
                        <td>Up to 500</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <!-- end of table -->

                <div class="section-title">
                    <h2>Health <span> Insurance </span></h2>
                    <p>Dubai laws make it mandatory for all overseas students to have health insurance for the duration of their visa. OEC will clarify and present a variety of medical insurance options for students applying to the UAE.</p>
                </div>
            </div>
            <!-- end of new -->
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    