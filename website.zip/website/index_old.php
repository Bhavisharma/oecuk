<!doctype html>
<html amp lang="en">
<head>
    <script type="application/ld+json">
    {
        "@context": "http://schema.org",
        "@type": "Website",
        "name": "oecdubai",
        "description": "Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available.",
        "distribution": {
            "@type": "DataDownload",
            "contentUrl": "https://www.oecdubai.com/"
        }
    }
    </script>
    <meta charset="utf-8" name="description"
        content="Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available.">
    <meta property="og:title" content="OEC Dubai">
    <meta property="og:site_name" content="oecdubai">
    <meta property="og:url" content="https://www.oecdubai.com/">
    <meta property="og:description"
        content="Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available..">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://www.oecdubai.com/assets/images/finalpic.png">
    <meta name="twitter:card" content="summary_large_image">
    </meta>

    <script async src="https://cdn.ampproject.org/v0.js"></script>
    <title>Free counselling | Free admissions | Free visa application assistance - OEC Dubai</title>
    <link rel="canonical" href="https://www.oecdubai.com/">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script type="application/ld+json">
    {
        "@context": "http://schema.org",
        "@type": "Website",
        "headline": "WELCOME TO OEC",
        "datePublished": "2015-10-07T12:02:41Z",
        "image": [
            "logo.jpg"
        ]
    }
    </script>
    <style amp-boilerplate>
    body {
        -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        animation: -amp-start 8s steps(1, end) 0s 1 normal both
    }
    @-webkit-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }
    @-moz-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @-ms-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @-o-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }
    </style><noscript>
        <style amp-boilerplate>
        body {
            -webkit-animation: none;
            -moz-animation: none;
            -ms-animation: none;
            animation: none
        }
        </style>
    </noscript>
    <?php include('inc/meta_css.php'); ?>
    <?php
        $sql="SELECT * FROM `counter` WHERE `page`='index' AND `date`='".date('Y-m-d')."'";
        $result=$mysqli->query($sql);
        $row=$result->fetch_array(MYSQLI_ASSOC);
        if(count($row)>0)
        {
            $update = "UPDATE `counter` SET `count`=".($row['count']+1)." WHERE `page`='index'";
            $mysqli->query($update);
        }
        else
        {
            $insert = "INSERT INTO `counter` (`count`,`page`,`date`) VALUES (1,'index','".date('Y-m-d')."')";
            $mysqli->query($insert);
        }
    ?>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="assets/js/platform.js" defer></script>
</head>
<!--  -->
<style type="text/css">
.eapps-link {
    background: none !important;
}
<?php
/*.dark-bg {
    position: relative;
    margin-top: -55px;
    overflow: visible;
    z-index: 99999;*/
    ?>
</style>

<body>
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-YTVLCLCDJL"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-YTVLCLCDJL');
    </script>
    <div class="main-container">
        <?php include('inc/header.php'); ?>
        <div class="banner-container">
            <div class="main-banner">
                <div class="slide transparent-background slide-one">
                    <div class="slide-text container">
                        <h2><span>Visa Consultancy</span> </h2>
                        <p>Get best-in-class consultancy and guidance - from the experts in overseas education.</p>
                        <a href="https://www.oecdubai.com/about-us.php"
                            class="btn btn-primary btn-padding btn-animated">About Us</a>
                        <a href="https://www.oecdubai.com/contactus.php"
                            class="btn btn-secondary btn-padding btn-dark-animated">Contact Us</a>
                    </div>
                </div>
                <div class="slide transparent-background slide-two">
                    <div class="slide-text container">
                        <h2>Consult, Prepare,<span> Apply, Travel</span></h2>
                        <p>The one-stop solution to all your overseas education needs. Check out our services page to
                            know more.</p>
                        <a href="https://www.oecdubai.com/service.php" class="btn btn-primary btn-padding">Our
                            Services</a>
                        <a href="https://www.oecdubai.com/contactus.php" class="btn btn-secondary btn-padding">Contact
                            Us</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            /*
                <div class="information-boxes grey-bg grey-bg-color module">
                    <div class="container">
                        <div class="row">
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="featured-box">
                                    <div class="featured-img">
                                        <img src="assets/images/help/information-boxes/information-img-1.jpg" alt="Information-Img">
                                    </div>
                                    <div class="featured-text">
                                        <h5><a href="about-us.php">Best Qualified Faculty</a></h5>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour don't look .</p>
                                        <a href="about-us.php">Read More →</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="featured-box">
                                    <div class="featured-img">
                                        <img src="assets/images/help/information-boxes/information-img-2.jpg" alt="Information-Img">
                                    </div>
                                    <div class="featured-text">
                                        <h5><a href="about-us.php">Amazing Campus Life</a></h5>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour don't look .</p>
                                        <a href="about-us.php">Read More →</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="events-block">
                                    <div class="events-head">
                                        <h5>Recent Events</h5>
                                        <h5><a href="all-events.php">All Events →</a></h5>
                                    </div>
                                    <div class="events">
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>15 March 2019</h6>
                                            <a href="all-events.php">There are many variations of passages of Lore Ipsum available, but the.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>12 February 2019</h6>
                                            <a href="all-events.php">There are many variations of passages of Lore Ipsum majority have suffered.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>17 January 2019</h6>
                                            <a href="all-events.php">Variations of passages of Lore Ipsum, but the majority have suffered.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>10 December 2018</h6>
                                            <a href="all-events.php">Many variations of passages of Lore Ipsum available, but the majority.</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            */
            ?>
        <div class="about-us module">
            <div class="section-title">
                <h2>Welcome to <span>OEC</span></h2>
                <p>Our goal is to provide free counselling, free admissions (wherever possible), and free visa
                    application assistance, to help you achieve your dream of studying abroad, and choosing the right
                    career path.</p><br />
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                        <div class="about-img">
                            <img src="assets/images/help/about-img.jpg" alt="About">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                        <div class="about-text">
                            <p>Since its establishment in 2003, OEC has emerged as the leading visa consultancy for
                                overseas education in India. We offer a comprehensive solution for all your overseas
                                education needs. Our experienced counsellors help students find the best education
                                opportunities worldwide. We offer guidance throughout the visa application, funding, and
                                pre-departure process.</p>
                            <p>
                                Our founder Mr Jagat Patel has spent more than fifteen years working with the education
                                industry and now along with his team of senior experts guides students for overseas
                                education at OEC. Our strong network of partner universities in countries like the UK,
                                USA, Australia, New Zealand, and Canada has been created with years of hard work and has
                                helped us place many students in the top universities abroad.
                            </p>
                            <a href="about-us.php" class="btn btn-primary btn-padding btn-animated">About Us</a>
                            <a href="service.php" class="btn btn-secondary btn-padding btn-dark-animated">Why Choose
                                Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonials-wrap grey-bg dark-bg module">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                        <div class="testimonials">
                            <div class="testimonial-slid">
                                <div class="testimonial-text">
                                    <p>" I'm Darshini Rathod. I'm a student of university of Portsmouth in United
                                        Kingdom. It was my dream to do my master's in the UK. I have done my every
                                        process for my Master's from Overseas education center they are very cooperative
                                        & they give real, true guidance. They have good knowledge & experience about the
                                        admission process and visa process as well. OEC is working like a team they make
                                        your course according to your interest. I recommended OEC to my all friends &
                                        relatives who wants to go abroad for their study. " </p>
                                </div>
                                <div class="testimonial-img">
                                    <img src="assets/images/t2.jpeg" alt="testimonial">
                                    <h6>Darshini Rathod</h6>
                                    <p>Portsmouth University, United Kingdom</p>
                                </div>
                            </div>
                            <div class="testimonial-slid">
                                <div class="testimonial-text">
                                    <p>" I am so grateful that I came across this team/agency who have helped me and
                                        guide me through my visa process as well in every step of my admission process.
                                        Thank you very much for your support. "</p>
                                </div>
                                <div class="testimonial-img">
                                    <img src="assets/images/t1.jpeg " alt="testimonial">
                                    <h6>Nausheen Khan</h6>
                                    <p>University East London</p>
                                    <p>2019</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="why-chose-us module">
            <div class="section-title">
                <h2>Why Choose <span>OEC</span></h2>
                <p>At OEC, we believe that education plays an important role in shaping our lives. A good education can
                    help a person build a better life for themselves and their loved ones. This is why at OEC we have
                    dedicated our efforts to help students to achieve admission into their dream universities to get the
                    best education they need to fulfil their dreams.</p>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6 col-padding-y">
                        <div class="faq-wrap">
                            <div class="accordion" id="accordionExample">
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link" type="button" data-toggle="collapse"
                                                data-target="#collapseOne" aria-expanded="false"
                                                aria-controls="collapseOne">Our Experience</button>
                                        </h2>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>The OEC team has been in the education industry for 15 years. We started
                                                in 2004 and
                                                since then we have placed more than 10,000 students at foreign
                                                universities across the
                                                world. With OEC’s guidance students have been accepted in universities
                                                in the United
                                                Kingdom, Australia, USA, Canada and New Zealand.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingTwo">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseTwo" aria-expanded="false"
                                                aria-controls="collapseTwo">Our Team</button>
                                        </h2>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>We take pride in our admissions team and counsellors who have been
                                                trained to provide students with the right guidance for overseas
                                                education. With thorough research, good etiquette and
                                                an ability to understand a student’s aspirations; our counsellors help
                                                you choose the
                                                right course and the best university in the country most suitable.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingThree">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseThree" aria-expanded="true"
                                                aria-controls="collapseThree">Our Staff</button>
                                        </h2>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>We believe in a growth mindset, making sure that our admissions teams,
                                                counsellors and staff are well-trained and knowledgeable. Many of our
                                                senior staff
                                                members have trained abroad with our partner universities, with the aim
                                                of providing
                                                comprehensive guidance to students.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingFour">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseFour" aria-expanded="false"
                                                aria-controls="collapseFour">Our Aim </button>
                                        </h2>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                        data-parent="#accordionExample">
                                        <div class="card-body">Our goal is to provide free counselling, free admissions
                                            (wherever possible) and free visa application assistance. We aim to help you
                                            achieve your dream of studying abroad and choosing the right career path.
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingFive">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseFive" aria-expanded="false"
                                                aria-controls="collapseFive">Ethical Practices & Transparency </button>
                                        </h2>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                        data-parent="#accordionExample">
                                        <div class="card-body">Our goal is to provide clear and accurate
                                            information to students and universities. We provide free consultation and
                                            guidance to
                                            students; helping them choose the right university and courses.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=" col-sm-12 col-md-12 col-lg-6 col-padding-y">
                        <div class="video-preview-one">
                            <!-- <a class="video-preview" href="../../../www.youtube.com/watch1ed0.php?v=lVXPCXRjXhg"> -->
                            <!--<div class="video-icon">
                                        <div class="play-icon">
                                            <i class="fas fa-play"></i>
                                        </div>
                                    </div> -->
                            <img src="assets/images/help/video-one.jpg" alt="video">
                            <!-- </a> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php
        /*
        <div class="call-to-action">
                <img class="call-to-action-img" src="assets/images/help/background-effect-2.jpg" alt="">
                <div class="container">
                    <div class="row no-gutters">
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/book-icon.png" alt="book Icon">
                                <h3><a href="#">City & Date</a></h3>
                                <p>City : VADODARA on Tuesday, February 25, 2020</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/light-bulb.png" alt="Light Bulb">
                                <h3><a href="#">UK EDUCATION FAIR 2020</a></h3>
                                <p>For Free Registration: UK Education Fair, Contact Us</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/hat-college.png" alt="Hat College">
                                <h3><a href="#">Time & Venue</a></h3>
                                <p>11:00AM TO 5:00PM at HOTEL EXPRESS TOWERS , ALKAPURI</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div> 
         <div class="blog-post grey-bg grey-bg-color">
                <div class="section-title">
                        <h2>Featured <span>News</span></h2>
                        <p>We have some great teachers and trainers in our staff who have professional experience along high education. Which gives you peace of mind.</p> 
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-4 col-padding-y">
                            <div class="blog-box">
                                <div class="blog-img">
                                    <img src="assets/images/help/blog/blog-img1.jpg" alt="Blog Img">
                                </div>
                                <div class="blog-text">
                                    <h5><a href="blog.php">Learn Basic Computer Skills</a></h5>
                                    <div class="meta-tags">
                                        <i class="far fa-user"> <span>By:</span><a href="single-post-page.php">Ateeq</a></i>
                                        <i class="far fa-comment"> <a href="single-post-page.php">3 Comments</a></i>
                                    </div>
                                    <p>Our best computer skills always available to make you better in your computer classes ...</p>
                                    <a href="#" class="btn btn-light btn-dark-animated">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        university logo
        */
        ?>
        <div class="container">
            <div class="section-title">
                <h2>Universities</h2>
            </div>
            <section class="customer-logos slider">
                <div class="slide"><img src="assets/images/uni/logo1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/uni/logo2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/uni/logo3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/uni/logo4.jpg" alt="university"></div>
                <!-- aus -->
                <div class="slide"><img src="assets/images/logo/aus/a1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/aus/a7.jpg" alt="university"></div>
                <!-- canada -->
                <div class="slide"><img src="assets/images/logo/canada/c1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c7.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c8.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c9.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c10.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c11.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c12.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c13.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c14.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c15.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c16.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c17.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/canada/c18.jpg" alt="university"></div>
                <!-- europe logo -->
                <div class="slide"><img src="assets/images/logo/europe/e1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e7.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/europe/e8.jpg" alt="university"></div>
                <!-- ireland -->
                <div class="slide"><img src="assets/images/logo/ireland/i1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/ireland/i2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/ireland/i3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/ireland/i4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/ireland/i5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/ireland/i6.jpg" alt="university"></div>
                <!-- newzeland -->
                <div class="slide"><img src="assets/images/logo/nz/n1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n7.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n8.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n9.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n10.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/nz/n11.jpg" alt="university"></div>
                <!-- uk -->
                <div class="slide"><img src="assets/images/logo/uk/u1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u7.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u8.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u9.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u10.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u11.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u12.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u13.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u14.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u15.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u16.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u17.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u18.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u19.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u20.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u21.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u22.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u23.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u24.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u25.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u26.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u27.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u28.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u29.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u30.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u31.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u32.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u33.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u34.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u35.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u36.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u37.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u38.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u39.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u40.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u41.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u42.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u43.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u44.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u45.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u46.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u47.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u48.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u49.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u50.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u51.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u52.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u53.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u54.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u55.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u56.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u57.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/uk/u58.jpg" alt="university"></div>
                <!-- usa -->
                <div class="slide"><img src="assets/images/logo/usa/usa1.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa2.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa3.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa4.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa5.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa6.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa7.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa8.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa9.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa10.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa11.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa12.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa13.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa14.png" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa15.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa16.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa17.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa18.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa19.jpg" alt="university"></div>
                <div class="slide"><img src="assets/images/logo/usa/usa20.jpg" alt="university"></div>
            </section>
            <!-- <section class="customer-logos slider">
                    <div class="row">
                        <div class="slides">
                            <img src="assets/images/uni/logo1.png">
                        </div>
                        <div class="slides">
                            <img src="assets/images/uni/logo2.png">
                        </div>
                        <div class="slides">
                            <img src="assets/images/uni/logo3.png">
                        </div>
                        <div class="slides">
                          <img src="assets/images/uni/logo4.png"></div>
                        </div>  
                        <div class="slides">
                            <img src="assets/images/uni/logo1.png">
                        </div>
                    </div>
               </section> -->
        </div>
        <!-- end of logo -->
        <!-- instafeed -->
        <!--  <div class="elfsight-app-d4258c2f-15d2-4fc5-9ab4-46a08cdd6ac8"></div> -->
        <div class="container">
            <div class="section-title bhavu">
            </div>
        </div>
        <?php include('inc/footer.php'); ?>
    </div>
    <?php include('inc/js.php'); ?>
</body>
</html>