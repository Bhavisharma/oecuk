<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
   
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the Right Career</h2>
                                <h1>Singapore</h1>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span> Singapore?</span></h2>
                    <p>In the past decade, Singapore has emerged as the education hub of Southeast Asia.
More than sixteen leading universities from around the world have established their
centres for excellence and research in Singapore. Studying in Singapore can be an
opportunity for overseas students to benefit from a rich education system, made richer
through its collaboration with renowned international universities. Furthermore,
Singapore is a business hub that offers lucrative employment opportunities for students
once they have completed their course. Here are some reasons why you should consider
studying in Singapore.</p><br/>
                </div>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="singapore">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">                         
                            <ul class="menu">
                                <li><i class="fas fa-check"></i> Singapore has a developed infrastructure, peaceful culture and a high standard of living.</li>
                                <li><i class="fas fa-check"></i> Singapore offers a cosmopolitan culture that welcomes people from all ethnicities and races.</li>
                                <li><i class="fas fa-check"></i> The cost of living in Singapore is lower than other study destinations around the world.</li>
                                <li><i class="fas fa-check"></i> Tuition fees in universities in Singapore are affordable compared to other destinations.</li>
                                <li><i class="fas fa-check"></i> Singapore also has distinguished private educational institutions that offer high-quality education.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                         <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='singapore'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                    
                                    
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Computer Science </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Computer Science  Courses</a></h5>
                                    <p>  Cyber security and ethical hacking are some of the dynamic computer science courses offered by universities at both undergraduate and postgraduate level. You can also opt for computer science as a branch of engineering.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                        <h6>Information Technology</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Information Technology Courses</a></h5>
                                    <p> Many universities in Singapore conduct undergraduate and postgraduate courses to study information and communication technology. The course content is relevant to the industry and up-to-date with technological changes.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/lw.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Law</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Law</a></h5>
                                    <p> Many overseas students go to Singapore to study law due to the lucrative job opportunities around the world, available to well-qualified lawyers from Singapore. Law firms from Malaysia, Canada, Australia, UK and USA recruit fresh graduates from Singapore. One of the most prestigious courses in law in Singapore is offered by the National University of Singapore Faculty of Law.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                        <h6>Engineering </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering </a></h5>
                                    <p>As a technologically advanced country, Singapore offers a wide variety of engineering
                                        courses to international students. Some of the most popular branches include: electrical
                                        engineering, civil engineering, mechanical engineering and bioengineering.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                        <h6>Finance & Banking </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Finance & Banking </a></h5>
                                    <p> As a commercial hub in Southeast Asia, Singapore also offers a plethora of banking &amp; finance courses at the undergraduate and postgraduate level.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

             <!-- add new  -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting a <span>Singapore Visa</span></h2>
                    <p>In Singapore, the term ‘Visa’ is referred to as ‘Pass’. Therefore, you need a Singapore Student Pass to study in Singapore. The Singapore Government has an online visa application system for students called the Student’s Pass Online Application & Registration (SOLAR) system. The processing time for a Singapore Student Pass is one month, and students are required to apply well in advance. You need to provide.</p>

                    <ul class="menu">
                        <li><i class="fas fa-check"></i>   Proof of enrollment in an academic programme in a Singaporean educational institution</li>
                        <li><i class="fas fa-check"></i> Evidence of financial capability to pay the course fee</li>
                    </ul>
                </div>
            </div>
            <!-- end of new -->

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education will vary according to the university you apply to and the course you are planning to pursue. In general, Singapore has a lower cost of education as compared to study destinations in Europe or the Americas. Here is an approximate annual fee for studying in Singapore.</p>
                    <br/><br/>
                    <ul style="list-style-type: none;">
                        <li><i class="fas fa-check"></i>Undergraduate Courses: 24000 to 38000 SGD per year </li>
                        <li><i class="fas fa-check"></i>Postgraduate Courses:  16000 to 35000 SGD per year </li>
                    </ul>
                </div>

                <div class="section-title">
                    <h2>Cost of <span> Living in Singapore </span></h2>
                    <p>Singapore is popular for its high standard of living but at affordable costs. Including accommodation, travelling expenses, food, utilities, clothing, telecommunications, books, medical and other expenses, you will spend approximately 2000 SGD per month on living expenses in Singapore.</p>
                    <br/>
                    <p>Singaporean Universities offer residence halls, private hostels, home-stays, public and private apartments for students to live in. Before arriving in Singapore, you can contact the international students department
who will help you find suitable temporary accommodation. </p>
                </div>

                <div class="section-title">
                    <h2>Health <span> Insurance </span></h2>
                    <p>Some universities in Singapore such as the National University of Singapore offer health insurance to students to cover for emergency and non-emergency medical expenses. For other universities, it is advisable to take medical insurance before travelling to Singapore to help avoid excessive expenditure in case of an unforeseen medical problem. </p>
                </div>
            </div>
        </div>

            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    
<!-- <li><i class="fas fa-check"></i> Proof of enrollment in an academic programme in a Singaporean educational institution</li>
<li><i class="fas fa-check"></i>Evidence of financial capability to pay the course fee</li>
<li><i class="fas fa-check"></i> Evidence of financial support for paying the tuition fees.</li> -->