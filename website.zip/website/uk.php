<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
    
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                            <h2>Choose the Right Career</h2>
                                <h1>UK</h1>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- why study -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span> United Kingdom?</span></h2>
                    <p>Study with the world’s leading academicians and experts in the United Kingdom. Home
to some of the best universities in the world, the United Kingdom has always been an
attractive study destination for overseas students. Strict government regulations
maintain excellence in higher education making it the vanguard of research and
knowledge. An incredibly diverse and multicultural environment makes international
students feel at home, providing a robust and all-encompassing educational experience.
Here are some reasons why you should think about studying in the United Kingdom.</p><br/>
                </div>
            </div>

            <!-- image -->
              <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">                         
                            <ul class="menu">
                                <li><i class="fas fa-check"></i> Course duration in the United Kingdom is shorter than other study destinations around the world. Undergraduate courses are 3 years and postgraduate courses are 1 year. </li>
                                <li><i class="fas fa-check"></i> A shorter course duration helps lower the cost of education and living for students.</li>
                                <li><i class="fas fa-check"></i> Degrees from UK universities are recognized around the world.</li>
                                <li><i class="fas fa-check"></i> UK Universities offer innumerable scholarships and grants to overseas students.</li>
                                <li><i class="fas fa-check"></i> The pedagogy in the United Kingdom encourages creativity and innovation in all fields.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
            <!-- image -->

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List Of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='uk'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingOne">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">Bath Spa University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bathspa.ac.uk//">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingTwo">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">University of Bedfordshire UBIC</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.beds.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingThree">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">University Of The West Of England</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                   <a href="https://www.uwe.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingFour">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">University Of East London </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.uel.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingFive">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">University of Worcester</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.worcester.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingSix">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSix" aria-expanded="false" aria-controls="collapseSix">Bangor University </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseSix" class="collapse" aria-labelledby="headingSix" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bangor.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingSeven">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseSeven" aria-expanded="false" aria-controls="collapseSeven">University of Bolton</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bolton.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingEight">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseEight" aria-expanded="false" aria-controls="collapseEight">Teeside University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseEight" class="collapse" aria-labelledby="headingEight" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.tees.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingNine">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseNine" aria-expanded="false" aria-controls="collapseNine">Northumbria University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseNine" class="collapse" aria-labelledby="headingNine" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.northumbria.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingTen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTen" aria-expanded="false" aria-controls="collapseTen">Middlesex University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseTen" class="collapse" aria-labelledby="headingTen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.mdx.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingeleven">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseeleven" aria-expanded="false" aria-controls="collapseeleven">Plymouth University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseeleven" class="collapse" aria-labelledby="headingeleven" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.plymouth.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                         <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingTwelve">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwelve" aria-expanded="false" aria-controls="collapseTwelve">Birmingham City University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseTwelve" class="collapse" aria-labelledby="headingTwelve" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bcu.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThirteen" aria-expanded="false" aria-controls="collapseThirteen">Swansea University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseThirteen" class="collapse" aria-labelledby="headingthirteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.swansea.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourteen" aria-expanded="false" aria-controls="collapsefourteen">De Montfort University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourteen" class="collapse" aria-labelledby="headingfourteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.dmu.ac.uk/home.aspx">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfifteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefifteen" aria-expanded="false" aria-controls="collapsefifteen">London South Bank University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefifteen" class="collapse" aria-labelledby="headingfifteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.lsbu.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingsixteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsesixteen" aria-expanded="false" aria-controls="collapsesixteen">Solent University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsesixteen" class="collapse" aria-labelledby="headingsixteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.solent.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingseventeen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseseventeen" aria-expanded="false" aria-controls="collapseseventeen">University Of Chester</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseseventeen" class="collapse" aria-labelledby="headingseventeen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www1.chester.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingeighteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseeighteen" aria-expanded="false" aria-controls="collapseeighteen">University of West London</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseeighteen" class="collapse" aria-labelledby="headingeighteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.uwl.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingninteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseninteen" aria-expanded="false" aria-controls="collapseninteen">University Of Central Lancashire</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapseninteen" class="collapse" aria-labelledby="headingninteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.uclan.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwenty">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwenty" aria-expanded="false" aria-controls="collapsetwenty">BPP University College</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwenty" class="collapse" aria-labelledby="headingtwenty" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bpp.com/about-bpp/bpp-university">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentyone">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentyone" aria-expanded="false" aria-controls="collapsetwentyone">Coventry University (Coventry & London Campus)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentyone" class="collapse" aria-labelledby="headingtwentyone" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.coventry.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingninteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsentwentytwo" aria-expanded="false" aria-controls="collapsentwentytwo">Liverpool John Moores University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsentwentytwo" class="collapse" aria-labelledby="headingntwentytwo" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.ljmu.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentythree">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentythree" aria-expanded="false" aria-controls="collapsetwentythree">University Of Portsmouth</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentythree" class="collapse" aria-labelledby="headingtwentythree" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.port.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentyfour">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentyfour" aria-expanded="false" aria-controls="collapsetwentyfour">Royal Agriculture University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentyfour" class="collapse" aria-labelledby="headingtwentyfour" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.uclan.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentyfive">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentyfive" aria-expanded="false" aria-controls="collapsetwentyfive">Oxford Brookes University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentyfive" class="collapse" aria-labelledby="headingtwentyfive" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.brookes.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentysix">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentysix" aria-expanded="false" aria-controls="collapsetwentysix">Queen's University Belfast</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentysix" class="collapse" aria-labelledby="headingtwentysix" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.qub.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentyseven">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentyseven" aria-expanded="false" aria-controls="collapsetwentyseven">University of Bradford</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentyseven" class="collapse" aria-labelledby="headingtwentyseven" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bradford.ac.uk/external/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentyeighteen">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentyeighteen" aria-expanded="false" aria-controls="collapsetwentyeighteen">University of Buckingham</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentyeighteen" class="collapse" aria-labelledby="headingtwentyeighteen" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.buckingham.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingtwentynine">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsetwentynine" aria-expanded="false" aria-controls="collapsetwentynine">University of Dundee</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsetwentynine" class="collapse" aria-labelledby="headingtwentynine" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.dundee.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirty">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirty" aria-expanded="false" aria-controls="collapsethirty">University Of Hull</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirty" class="collapse" aria-labelledby="headingthirty" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.hull.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtyone">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtyone" aria-expanded="false" aria-controls="collapsethirtyone">University of Derby</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtyone" class="collapse" aria-labelledby="headingthirtyone" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.derby.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtytwo">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtytwo" aria-expanded="false" aria-controls="collapsethirtytwo">Cranfield University</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtytwo" class="collapse" aria-labelledby="headingthirtytwo" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.cranfield.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtythree">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtythree" aria-expanded="false" aria-controls="collapsethirtythree">University of Essex</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtythree" class="collapse" aria-labelledby="headingthirtythree" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.essex.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtyfour">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtyfour" aria-expanded="false" aria-controls="collapsethirtyfour">University of Greenwich</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtyfour" class="collapse" aria-labelledby="headingthirtyfour" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.gre.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtyfive">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtyfive" aria-expanded="false" aria-controls="collapsethirtyfive">University Of Reading</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtyfive" class="collapse" aria-labelledby="headingthirtyfive" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="http://www.reading.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtysix">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtysix" aria-expanded="false" aria-controls="collapsethirtysix">University Of Salford</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtysix" class="collapse" aria-labelledby="headingthirtysix" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.salford.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtyeight">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtyeight" aria-expanded="false" aria-controls="collapsethirtyeight">University Of South Wales</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtyeight" class="collapse" aria-labelledby="headingthirtyeight" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.southwales.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingthirtynine">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsethirtynine" aria-expanded="false" aria-controls="collapsethirtynine">York St John University (York & London Campus)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsethirtynine" class="collapse" aria-labelledby="headingthirtynine" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.yorksj.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourty">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourty" aria-expanded="false" aria-controls="collapsefourty">QA Higher Education Group Northumbria University </button>-->
                                                
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourty" class="collapse" aria-labelledby="headingfourty" data-parent="#accordionExample">-->
            <!--                                <div class="card-body"><p>Northumbria University - London Campus , University Of Ulster - Brmingham & London Campus, University Of Roehampton - London campus</p>-->
            <!--                                    <a href="https://qahighereducation.com/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtyone">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtyone" aria-expanded="false" aria-controls="collapsefourtyone">Oxford International Group De Montfort University </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtyone" class="collapse" aria-labelledby="headingfourtyone" data-parent="#accordionExample">-->
            <!--                                <div class="card-body"><p>University of Dundee ,Bangor University ,University of Greenwich</p>-->
            <!--                                    <a href="https://www.oxfordinternational.com/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtytwo">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtytwo" aria-expanded="false" aria-controls="collapsefourtytwo">Glion Institute of Higher Education (London)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtytwo" class="collapse" aria-labelledby="headingfourtytwo" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.glion.edu/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtythree">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtythree" aria-expanded="false" aria-controls="collapsefourtythree">St Mary’s University London International College (SMULIC)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtythree" class="collapse" aria-labelledby="headingfourtythree" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.stmarys.ac.uk/smulic/home.aspx">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtyfour">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtyfour" aria-expanded="false" aria-controls="collapsefourtyfour">University for the Creative Arts International College (UCAIC)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtyfour" class="collapse" aria-labelledby="headingfourtyfour" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.uca.ac.uk/ucaic/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtyfive">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtyfive" aria-expanded="false" aria-controls="collapsefourtyfive">University of Worcester International College (UWIC)</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtyfive" class="collapse" aria-labelledby="headingfourtyfive" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.worcester.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtysix">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtysix" aria-expanded="false" aria-controls="collapsefourtysix">University of Birmingham </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtysix" class="collapse" aria-labelledby="headingfourtysix" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.birmingham.ac.uk/index.aspx">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtyseven">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtyseven" aria-expanded="false" aria-controls="collapsefourtyseven">Study Group Partner Institute Bellerbys College</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtyseven" class="collapse" aria-labelledby="headingfourtyseven" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://www.bellerbys.com/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div><div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtyeight">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtyeight" aria-expanded="false" aria-controls="collapsefourtyeight">Study Group Partner Institutes <br/>International Study Centres / Colleges </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtyeight" class="collapse" aria-labelledby="headingfourtyeight" data-parent="#accordionExample">-->
            <!--                                <div class="card-body"><a href="https://www.aberdeen-isc.ac.uk/">University of Aberdeen </a><br/>-->
												<!--<a href="https://www.isc.cardiff.ac.uk">Cardiff University </a><br/>-->
												<!--<a href="https://www.coventryisc.com">Coventrey University London</a><br/>-->
												<!--<a href="https://www.durhamisc.com">Durham University </a><br/>-->
												<!--<a href="https://www.huddersfieldisc.com">niversity of Huddersfield (Huddersfield & London Campus) </a><br/>-->
												<!--<a href="https://www.keeleisc.com">Keele University </a><br/>-->
												<!--<a href="https://www.kingstonisc.com">Kingston University </a><br/>-->
												<!--<a href="https://www.lancasterisc.com">Lancaster University </a><br/>-->
												<!--<a href="https://www.leedsisc.com">University of Leeds </a><br/>-->
												<!--<a href="https://www.isc.leedsbeckett.ac.uk">Leeds Beckett University </a><br/>-->
												<!--<a href="https://www.lincolnisc.com">Universtiy of Lincoln </a><br/>-->
												<!--<a href="https://www.ljmu.ac.uk/">Liverpool John Moores University</a><br/>-->
												<!--<a href="https://www.rhulisc.com">Royal Holloway University of London </a><br/>-->
												<!--<a href="https://www.usic.sheffield.ac.uk">Universtiy of Sheffield </a><br/>-->
												<!--<a href="https://www.isc.strath.ac.uk">Universtiy of Strathclyde </a><br/>-->
												<!--<a href="https://www.isc.surrey.ac.uk">University of Surrey </a><br/>-->
												<!--<a href="https://www.isc.sussex.ac.uk">University of Sussex </a><br/>-->
            <!--                                    <a href="https://www.southwales.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfourtynine">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefourtynine" aria-expanded="false" aria-controls="collapsefourtynine">Kaplan Group</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefourtynine" class="collapse" aria-labelledby="headingfourtynine" data-parent="#accordionExample">-->
            <!--                                <div class="card-body"><p>Nottingham Trent Iternational College<br/>-->
												<!--Glasgow International College<br/>-->
												<!--University of Liverpool International College<br/>-->
												<!--Kaplan International College (KIC) London <br/>-->
												<!--Bournemouth University International College<br/>-->
												<!--University of Brighton's International College<br/>-->
												<!--UWE Bristol's International College<br/>-->
												<!--University of York International Pathway College<br/>-->
												<!--University of Essex International College<br/>-->
												<!--University of Notttingham International College<br/>-->
												<!--University of Bristol International Foundation Program<br/></p>-->
            <!--                                    <a href="http://www.kaplanpathways.com/colleges/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->

            <!--                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfifty">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefifty" aria-expanded="false" aria-controls="collapsefifty">Cambridge Education Group </button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefifty" class="collapse" aria-labelledby="headingfifty" data-parent="#accordionExample">-->
            <!--                                <div class="card-body"><p>On Campus Coventry<br/>-->
												<!--On Campus Sunderland<br/>-->
												<!--On Campus LSBU <br/>-->
												<!--On Campus Reading <br/>-->
												<!--On Campus Hull<br/>-->
												<!--On Campus North (UCLAN)<br/>-->
												<!--On Campus London (Birkbeck University of London, Royal Holloway University of London, Queen Mary University of London, Goldsmith University of London, Royal Veterinary College)<br/></p>-->
            <!--                                    <a href="https://www.cambridgeeducationgroup.com/home.htm">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div><div class="card animated" data-animation="slideInUp" data-animation-delay="500">-->
            <!--                            <div class="card-header" id="headingfiftyone">-->
            <!--                                <h2 class="mb-0">-->
            <!--                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefiftyone" aria-expanded="false" aria-controls="collapsefiftyone">Writtle Universtiy College</button>-->
            <!--                                </h2>-->
            <!--                            </div>-->
            <!--                            <div id="collapsefiftyone" class="collapse" aria-labelledby="headingfiftyone" data-parent="#accordionExample">-->
            <!--                                <div class="card-body">-->
            <!--                                    <a href="https://writtle.ac.uk/">Visit Website</a>-->
            <!--                                </div>-->
            <!--                            </div>-->
            <!--                        </div>-->
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$29.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                        <h6>Architecture </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Architecture  Courses</a></h5>
                                    <p>Architectural courses teach the art and science of designing and engineering large
structures and buildings and are popular among overseas students studying in the UK.
These courses encourage creativity and scientific application of knowledge.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>Free</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                        <h6>Law</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Law Courses</a></h5>
                                    <p>  A law degree from the United Kingdom is recognized the world over. Students learn
essential skills that gives them the ability to understand legal theory, interpret the law
and cultivate analytical thinking. These courses also include the development of
negotiation skills, oral communication skills, and the skills needed for drafting legal
documents.</p>
                                   <!--  <ul class="menu">
                                        <li><i class="fas fa-check"></i>Information systems </li>
                                        <li><i class="fas fa-check"></i>Software development</li>
                                        <li><i class="fas fa-check"></i> Networking </li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/edu.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6> Business Management</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Business Management</a></h5>
                                    <p>  Studying Business Management is a popular option at undergraduate and postgraduate levels. MBA programs in UK Universities offer practical exposure and a professional learning experience.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$49.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                        <h6>Engineering & Science </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering & Science</a></h5>
                                    <p>Courses on mathematics, science, computers and technology are included in engineering and science. Studying engineering in the UK also teaches you professionalism, teamwork and management. </p>
                                    <!-- <ul class="menu">
                                        <li><i class="fas fa-check"></i> Statistics </li>
                                        <li><i class="fas fa-check"></i> Specialized Mathematics</li>
                                    </ul> -->
                                    <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/tour.jpg" alt="Our Courses">
                                    <!-- <div class="course-price">
                                        <h6>$69.00</h6>
                                    </div> -->
                                    <div class="course-teacher">
                                        <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                        <h6>Arts </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Arts </a></h5>
                                    <p> Creative Arts such as designing, and performing arts like acting and dance are also among the coveted courses in the United Kingdom.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

                        <!-- add new  -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting a <span>United Kingdom Visa</span></h2>
                    <p>The United Kingdom follows a points-based immigration system. Under this system, students need to obtain a minimum of seventy points to get a student visa. Here are the prerequisites.</p>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-img">
                                <img src="assets/images/help/about-img.jpg" alt="About">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-text">
                                <ul class="menu">
                                    <li><i class="fas fa-check"></i> An offer letter from an approved educational institution in the United Kingdom.</li>
                                    <li><i class="fas fa-check"></i> Proof of financial capability to support themselves in the UK during their stay.</li>

                                    <li><i class="fas fa-check"></i> English Language Proficiency.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                </div>
            </div>
            <!-- end of new -->

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education will vary according to the university you apply to and the course you are planning to pursue. The biggest advantage for students in terms of education costs in the UK stems from the shorter duration of the courses. The approximate cost of education for students planning to study in the United Kingdom ranges from 10000 to 25000 GBP per year.</p>
                    <br/><br/>
                    <ul style="list-style-type: none;">
                        <li><i class="fas fa-check"></i>Undergraduate Courses: 10,000 to 15,000 GBP</li>

                        <li><i class="fas fa-check"></i>Postgraduate Courses:  13,000 to 20,000 GBP</li>
                    </ul>
                </div>

                <div class="section-title">
                    <h2>Cost of <span> Living in United Kingdom </span></h2>
                    <p>If you choose to live in a big city such as London, Liverpool or Sheffield you can expect to spend up to 12000 GBP per year on living costs. If you live outside of London or in smaller cities you can expect an expenditure of 8500 GBP. This cost includes living, food, clothing, travelling, entertainment, utilities, books and other expenses.</p>
                    <br/>
                    <p>International students in the United Kingdom can choose from on-campus hostels, off-campus rented accommodations or a homestay with host families living close to the campus.</p>
                </div>

                <div class="section-title">
                    <h2>Health <span> Insurance </span></h2>
                    <p>International students who are required to live in the United Kingdom for six months or more for their studies are eligible for health care facilities provided by the UK government. You will have to pay a nominal charge at the time of visa application.</p>
                </div>
            </div>

            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    