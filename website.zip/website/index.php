<?php


include('db.php');

?>
<!doctype html>
<html amp lang="en">
<head>
        <!-- Google Tag Manager -->

        <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0], j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','GTM-W95D7TR');</script>

    <!-- End Google Tag Manager -->

    <script type="application/ld+json">
    {
        "@context": "http://schema.org",
        "@type": "Website",
        "name": "oecdubai",
        "description": "Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available.",
        "distribution": {
            "@type": "DataDownload",
            "contentUrl": "https://www.oecdubai.com/"
        }
    }
    </script>
    <meta name="facebook-domain-verification" content="7js92yktbrnwchua0s47fuwil24imx" />
    <meta charset="utf-8" name="description"
        content="Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available.">
    <meta property="og:title" content="OEC Dubai">
    <meta property="og:site_name" content="oecdubai">
    <meta property="og:url" content="https://www.oecdubai.com/">
    <meta property="og:description"
        content="Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available..">
    <meta property="og:type" content="website">
    <meta property="og:image" content="https://www.oecdubai.com/assets/images/finalpic.png">
    <meta name="twitter:card" content="summary_large_image">
    </meta>

    <script async src="https://cdn.ampproject.org/v0.js"></script>
    <title>Free counselling | Free admissions | Free visa application assistance - OEC Dubai</title>
    <link rel="canonical" href="https://www.oecdubai.com/">
    <meta name="viewport" content="width=device-width, initial-scale=1">


    <script type="application/ld+json">
    {
        "@context": "http://schema.org",
        "@type": "Website",
        "headline": "WELCOME TO OEC",
        "datePublished": "2015-10-07T12:02:41Z",
        "image": [
            "logo.jpg"
        ]
    }
    </script>
    <style amp-boilerplate>
    body {
        -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
        animation: -amp-start 8s steps(1, end) 0s 1 normal both
    }
    @-webkit-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }
    @-moz-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @-ms-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @-o-keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }

    @keyframes -amp-start {
        from {
            visibility: hidden
        }

        to {
            visibility: visible
        }
    }
    </style><noscript>
        <style amp-boilerplate>
        body {
            -webkit-animation: none;
            -moz-animation: none;
            -ms-animation: none;
            animation: none
        }
        </style>
    </noscript>
    <?php include('inc/meta_css.php'); ?>
    <script src="https://code.jquery.com/jquery-2.2.0.min.js" type="text/javascript"></script>
    <script src="assets/js/platform.js" defer></script>
</head>
<!--  -->
<style type="text/css">
.eapps-link {
    background: none !important;
}
<?php
/*.dark-bg {
    position: relative;
    margin-top: -55px;
    overflow: visible;
    z-index: 99999;*/
    ?>
</style>

<body>
            <!-- Google Tag Manager (noscript) -->
                <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-W95D7TR" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
        <!-- End Google Tag Manager (noscript) -->


    <!-- end of google tag manager -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-YTVLCLCDJL"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-YTVLCLCDJL');
    </script>
    <div class="main-container">
        <?php include('inc/header.php'); ?>
        <div class="banner-container">
            <div class="main-banner">
                <div class="slide transparent-background slide-one">
                    <div class="slide-text container">
                        <h2><span>Visa Consultancy</span> </h2>
                        <p>Get best-in-class consultancy and guidance - from the experts in overseas education.</p>
                        <a href="https://www.oecdubai.com/about-us.php"
                            class="btn btn-primary btn-padding btn-animated">About Us</a>
                        <a href="https://www.oecdubai.com/contactus.php"
                            class="btn btn-secondary btn-padding btn-dark-animated">Contact Us</a>
                    </div>
                </div>
                <div class="slide transparent-background slide-two">
                    <div class="slide-text container">
                        <h2>Consult, Prepare,<span> Apply, Travel</span></h2>
                        <p>The one-stop solution to all your overseas education needs. Check out our services page to
                            know more.</p>
                        <a href="https://www.oecdubai.com/service.php" class="btn btn-primary btn-padding">Our
                            Services</a>
                        <a href="https://www.oecdubai.com/contactus.php" class="btn btn-secondary btn-padding">Contact
                            Us</a>
                    </div>
                </div>
            </div>
        </div>
        <?php
            /*
                <div class="information-boxes grey-bg grey-bg-color module">
                    <div class="container">
                        <div class="row">
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="featured-box">
                                    <div class="featured-img">
                                        <img src="assets/images/help/information-boxes/information-img-1.jpg" alt="Information-Img">
                                    </div>
                                    <div class="featured-text">
                                        <h5><a href="about-us.php">Best Qualified Faculty</a></h5>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour don't look .</p>
                                        <a href="about-us.php">Read More →</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="featured-box">
                                    <div class="featured-img">
                                        <img src="assets/images/help/information-boxes/information-img-2.jpg" alt="Information-Img">
                                    </div>
                                    <div class="featured-text">
                                        <h5><a href="about-us.php">Amazing Campus Life</a></h5>
                                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour don't look .</p>
                                        <a href="about-us.php">Read More →</a>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-4 col-lg-4 col-padding-y">
                                <div class="events-block">
                                    <div class="events-head">
                                        <h5>Recent Events</h5>
                                        <h5><a href="all-events.php">All Events →</a></h5>
                                    </div>
                                    <div class="events">
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>15 March 2019</h6>
                                            <a href="all-events.php">There are many variations of passages of Lore Ipsum available, but the.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>12 February 2019</h6>
                                            <a href="all-events.php">There are many variations of passages of Lore Ipsum majority have suffered.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>17 January 2019</h6>
                                            <a href="all-events.php">Variations of passages of Lore Ipsum, but the majority have suffered.</a>
                                        </div>
                                        <div class="events-date">
                                            <h6><i class="far fa-calendar-check"></i>10 December 2018</h6>
                                            <a href="all-events.php">Many variations of passages of Lore Ipsum available, but the majority.</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            */
            ?>
        <div class="about-us module">
            <div class="section-title">
                <h2>Welcome to <span>OEC</span></h2>
                <p>Our goal is to provide free counselling, free admissions (wherever possible), and free visa
                    application assistance, to help you achieve your dream of studying abroad, and choosing the right
                    career path.</p><br />
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                        <div class="about-img">
                            <img src="assets/images/help/about-img.jpg" alt="About">
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                        <div class="about-text">
                            <p>Since its establishment in 2003, OEC has emerged as the leading visa consultancy for
                                overseas education in India. We offer a comprehensive solution for all your overseas
                                education needs. Our experienced counsellors help students find the best education
                                opportunities worldwide. We offer guidance throughout the visa application, funding, and
                                pre-departure process.</p>
                            <p>
                                Our founder Mr Jagat Patel has spent more than fifteen years working with the education
                                industry and now along with his team of senior experts guides students for overseas
                                education at OEC. Our strong network of partner universities in countries like the UK,
                                USA, Australia, New Zealand, and Canada has been created with years of hard work and has
                                helped us place many students in the top universities abroad.
                            </p>
                            <a href="about-us.php" class="btn btn-primary btn-padding btn-animated">About Us</a>
                            <a href="service.php" class="btn btn-secondary btn-padding btn-dark-animated">Why Choose
                                Us</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonials-wrap grey-bg dark-bg module">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                        <div class="testimonials">
                            <?php
                                global $conn;
                                
                                $sql = "SELECT * FROM testimonials";
                                
                                $testimonial = $conn->query($sql);
                                
                                if ($testimonial->num_rows > 0) {
                                    while($row = $testimonial->fetch_assoc()) {
                                        ?>
                                        <div class="testimonial-slid">
                                            <div class="testimonial-text">
                                                <p><?=$row['description'];?></p>
                                            </div>
                                            <div class="testimonial-img">
                                                <img src="backend/images/testimonial/<?=$row['student_img'];?>" alt="testimonial">
                                                <h6><?=$row['student_name'];?></h6>
                                                <p student_img><?=$row['university_detail'];?> </p>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                } 
                                else 
                                {
                                    echo "results";
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="why-chose-us module">
            <div class="section-title">
                <h2>Why Choose <span>OEC</span></h2>
                <p>At OEC, we believe that education plays an important role in shaping our lives. A good education can
                    help a person build a better life for themselves and their loved ones. This is why at OEC we have
                    dedicated our efforts to help students to achieve admission into their dream universities to get the
                    best education they need to fulfil their dreams.</p>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-6 col-padding-y">
                        <div class="faq-wrap">
                            <div class="accordion" id="accordionExample">
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingOne">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link" type="button" data-toggle="collapse"
                                                data-target="#collapseOne" aria-expanded="false"
                                                aria-controls="collapseOne">Our Experience</button>
                                        </h2>
                                    </div>
                                    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>The OEC team has been in the education industry for 15 years. We started
                                                in 2004 and
                                                since then we have placed more than 10,000 students at foreign
                                                universities across the
                                                world. With OEC’s guidance students have been accepted in universities
                                                in the United
                                                Kingdom, Australia, USA, Canada and New Zealand.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingTwo">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseTwo" aria-expanded="false"
                                                aria-controls="collapseTwo">Our Team</button>
                                        </h2>
                                    </div>
                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>We take pride in our admissions team and counsellors who have been
                                                trained to provide students with the right guidance for overseas
                                                education. With thorough research, good etiquette and
                                                an ability to understand a student’s aspirations; our counsellors help
                                                you choose the
                                                right course and the best university in the country most suitable.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingThree">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseThree" aria-expanded="true"
                                                aria-controls="collapseThree">Our Staff</button>
                                        </h2>
                                    </div>
                                    <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                        data-parent="#accordionExample">
                                        <div class="card-body">
                                            <p>We believe in a growth mindset, making sure that our admissions teams,
                                                counsellors and staff are well-trained and knowledgeable. Many of our
                                                senior staff
                                                members have trained abroad with our partner universities, with the aim
                                                of providing
                                                comprehensive guidance to students.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingFour">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseFour" aria-expanded="false"
                                                aria-controls="collapseFour">Our Aim </button>
                                        </h2>
                                    </div>
                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                        data-parent="#accordionExample">
                                        <div class="card-body">Our goal is to provide free counselling, free admissions
                                            (wherever possible) and free visa application assistance. We aim to help you
                                            achieve your dream of studying abroad and choosing the right career path.
                                        </div>
                                    </div>
                                </div>
                                <div class="card animated" data-animation="slideInUp">
                                    <div class="card-header" id="headingFive">
                                        <h2 class="mb-0">
                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                                data-target="#collapseFive" aria-expanded="false"
                                                aria-controls="collapseFive">Ethical Practices & Transparency </button>
                                        </h2>
                                    </div>
                                    <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                        data-parent="#accordionExample">
                                        <div class="card-body">Our goal is to provide clear and accurate
                                            information to students and universities. We provide free consultation and
                                            guidance to
                                            students; helping them choose the right university and courses.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class=" col-sm-12 col-md-12 col-lg-6 col-padding-y">
                        <div class="video-preview-one">
                            <!-- <a class="video-preview" href="../../../www.youtube.com/watch1ed0.php?v=lVXPCXRjXhg"> -->
                            <!--<div class="video-icon">
                                        <div class="play-icon">
                                            <i class="fas fa-play"></i>
                                        </div>
                                    </div> -->
                            <img src="assets/images/help/video-one.jpg" alt="video">
                            <!-- </a> -->
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <?php
        /*
        <div class="call-to-action">
                <img class="call-to-action-img" src="assets/images/help/background-effect-2.jpg" alt="">
                <div class="container">
                    <div class="row no-gutters">
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/book-icon.png" alt="book Icon">
                                <h3><a href="#">City & Date</a></h3>
                                <p>City : VADODARA on Tuesday, February 25, 2020</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/light-bulb.png" alt="Light Bulb">
                                <h3><a href="#">UK EDUCATION FAIR 2020</a></h3>
                                <p>For Free Registration: UK Education Fair, Contact Us</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/hat-college.png" alt="Hat College">
                                <h3><a href="#">Time & Venue</a></h3>
                                <p>11:00AM TO 5:00PM at HOTEL EXPRESS TOWERS , ALKAPURI</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div> 
         <div class="blog-post grey-bg grey-bg-color">
                <div class="section-title">
                        <h2>Featured <span>News</span></h2>
                        <p>We have some great teachers and trainers in our staff who have professional experience along high education. Which gives you peace of mind.</p> 
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-4 col-padding-y">
                            <div class="blog-box">
                                <div class="blog-img">
                                    <img src="assets/images/help/blog/blog-img1.jpg" alt="Blog Img">
                                </div>
                                <div class="blog-text">
                                    <h5><a href="blog.php">Learn Basic Computer Skills</a></h5>
                                    <div class="meta-tags">
                                        <i class="far fa-user"> <span>By:</span><a href="single-post-page.php">Ateeq</a></i>
                                        <i class="far fa-comment"> <a href="single-post-page.php">3 Comments</a></i>
                                    </div>
                                    <p>Our best computer skills always available to make you better in your computer classes ...</p>
                                    <a href="#" class="btn btn-light btn-dark-animated">Read More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> 
        university logo
        */
        ?>
        <div class="container">
            <div class="section-title">
                <h2>Universities</h2>
            </div>
            <section class="customer-logos slider">
                <?php
                    global $conn;
                    
                    $sql = "SELECT * FROM home_pages";
                    
                    $testimonial = $conn->query($sql);
                    
                    if ($testimonial->num_rows > 0) {
                        while($row = $testimonial->fetch_assoc()) {
                            ?>
                                <div class="slide"><img src="backend/images/home_page/<?=$row['entity_image'];?>" alt="<?=$row['entity_name'];?>"></div>
                            <?php
                        }
                    }
                ?>
            </section>
            <!-- <section class="customer-logos slider">
                    <div class="row">
                        <div class="slides">
                            <img src="assets/images/uni/logo1.png">
                        </div>
                        <div class="slides">
                            <img src="assets/images/uni/logo2.png">
                        </div>
                        <div class="slides">
                            <img src="assets/images/uni/logo3.png">
                        </div>
                        <div class="slides">
                          <img src="assets/images/uni/logo4.png"></div>
                        </div>  
                        <div class="slides">
                            <img src="assets/images/uni/logo1.png">
                        </div>
                    </div>
               </section> -->
        </div>
        <!-- end of logo -->
        <!-- instafeed -->
        <!--  <div class="elfsight-app-d4258c2f-15d2-4fc5-9ab4-46a08cdd6ac8"></div> -->
        <div class="container">
            <div class="section-title bhavu">
            </div>
        </div>
        <?php include('inc/footer.php'); ?>
    </div>
    <?php include('inc/js.php'); ?>
</body>
</html>