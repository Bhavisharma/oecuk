<!doctype html>
<?php
include('function.php');
?>
<html lang="en">
<head>



<?php include('inc/meta_css.php'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</head>
<body>
    <div class="main-container about-us-page">
        <?php include('inc/header.php'); ?>
        <div class="title-section dark-bg module grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-padding-y">
                        <div class="title-section-text">
                            <h1>Event-Details</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <link rel="stylesheet" href="code_oecdubai\assets\css\style.css">
        <link rel="stylesheet" href="code_oecdubai\assets\css\material-design-iconic-font.min">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css"
            integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />
        <div class="row">
            <div class="col-12 text-center">
                <div class="section-title mb-4 pb-2">
                    <h4 class="title mb-4">Event &amp; News</h4>
                    <p class="text-muted para-desc mx-auto mb-0">Build responsive, mobile-first projects on the web with
                        the world's most popular front-end component library.</p>
                </div>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css"
            integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />
        <div class="container">
                        <?php
                            $detail=get_row_detail("events","slug='".$_GET['event_name']."'");
                        ?>
            <div class="row">
                <div class="col-md-7">
                    <img src="<?=EVENT_PATH."/".$detail['image'];?>" alt="project-image" class="rounded">
                </div><!-- / column -->
                <div class="col-md-5">
                    <div class="project-info-box mt-0">
                        <h5>EVENTS DETAILS</h5>

                        <p class="mb-0">
                        <?=$detail['description'];?>
                        </p>
                    </div><!-- / project-info-box -->
                    <div class="project-info-box">
                        <p><b>Place:</b> <?=$detail['place'];?></p>
                        <p><b>Date:</b> <?=date('d.m.Y',strtotime($detail['date']));?></p>
                        <p><b>Time:</b> <?=date('h:s A',strtotime($detail['time']));?></p>
                    </div><!-- / project-info-box -->
                    <!-- <div class="project-info-box mt-0 mb-0">
                        <p class="mb-0">
                            <span class="fw-bold mr-10 va-middle hide-mobile">Share:</span>
                            <a href="#x" class="btn btn-xs btn-facebook btn-circle btn-icon mr-5 mb-0"><i
                                    class="fab fa-facebook-f"></i></a>
                            <a href="#x" class="btn btn-xs btn-twitter btn-circle btn-icon mr-5 mb-0"><i
                                    class="fab fa-twitter"></i></a>
                            <a href="#x" class="btn btn-xs btn-pinterest btn-circle btn-icon mr-5 mb-0"><i
                                    class="fab fa-pinterest"></i></a>
                            <a href="#x" class="btn btn-xs btn-linkedin btn-circle btn-icon mr-5 mb-0"><i
                                    class="fab fa-linkedin-in"></i></a>
                        </p>
                    </div> -->
                    <!-- / project-info-box -->
                </div><!-- / column -->
            </div>
        </div>
        <?php include('inc/request.php'); ?>
        <?php include('inc/footer.php'); ?>
        <?php include('inc/js.php'); ?>
</body>
</html>