<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>

    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the right Career</h2>
                                <h1>Ireland</h1>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
            <div class="about-us module">
                <div class="section-title">
                    <h2>Why Study in <span>Ireland ?</span></h2>
                    <p>Known as the home of the finest universities in Europe, Ireland is a coveted study
                        destination for international students. Many Irish universities prioritize world class
                        research offering students the opportunity to pursue research in their chosen fields.
                        These include sciences, technology, economics and the humanities. Here are some
                        reasons for studying in Ireland.</p><br/>
                </div>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="ireland">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">
                            <!-- <h2 class="campus-title">Why Study in Australia?</h2> -->                            
                            <ul class="menu">
                                <li><i class="fas fa-check"></i>Be a part of leading research projects driving innovation worldwide.</li>
                                <li><i class="fas fa-check"></i>Benefit from one of the best education systems in Europe.</li>
                                <li><i class="fas fa-check"></i> Ireland has a culture that is welcoming and friendly to foreign nationals.</li>
                                <li><i class="fas fa-check"></i> Great opportunities for employment with some of the biggest multinational companies including Google, Airbnb, Dell etc., as most of these companies have their European headquarters  in Ireland.</li>
                                <li><i class="fas fa-check"></i> One of the best destinations for technical education. </li>

                            </ul>
                        </div>
                    </div>
                </div>
            </div> 

            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                            <!--    <h3>List Of Universities</h3> -->
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='ireland'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <!-- courses List -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Popular <span>Courses</span></h2>
                    <p>Ireland offers some of the best opportunities for higher education in several fields. Here are some of the disciplines that international students usually opt for in Ireland.</p>
                </div><!-- Section Title /-->
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Commerce </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Commerce  Courses</a></h5>
                                    <p>Business Management, Accounting, Finance, Economics, Operations Management, Production Management.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Tourism & Hospitality Courses</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Tourism & Hospitality Courses</a></h5>
                                    <p> Hotel Management, Tourism Management, Tourism Marketing.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/edu.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Health Sciences</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Health Sciences</a></h5>
                                    <p> Medicine, Nursing, Food & Nutrition, Health Informatics, Pharmacy, Physiotherapy, Psychology Science, Veterinary Medicine.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Engineering & Technology</h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Engineering & Technology</a></h5>
                                    <p> Software Engineering, Computer Science, Information Technology, Product Design & Technology, Bio-Technology.</p>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-sm-6 col-md-4 col-lg-4 col-padding-y">
                            <div class="course-warp">
                                <div class="course-img">
                                    <img src="assets/images/help/our-courses/tour.jpg" alt="Our Courses">
                                    <div class="course-teacher">
                                        <h6>Other Fields </h6>
                                    </div>
                                </div>
                                <div class="course-text">
                                    <h5><a href="#">Other Fields </a></h5>
                                    <p>Agriculture Sciences, Design, Journalism, Mathematics, Statistics, Social Science, Sport & Performance.</p>
                                </div>
                            </div>
                        </div>
                    </div><!-- Row /-->
                </div><!-- Container -->
            </div>

            <!-- add new  Visa -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting An <span>Irish Visa</span></h2>
                    <p>As expert visa consultants, OEC helps students in understanding the nuances of visa application and formalities required to get a student visa for Ireland. Usually, Ireland grants a multi-entry visa for the duration of the course. Obtaining an Irish visa can take up to five weeks, therefore it is important to
apply well in advance. Here are the prerequisites.</p>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-img">
                                <img src="assets/images/help/about-img.jpg" alt="About">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-text">
                                <ul class="menu">
                                    <li><i class="fas fa-check"></i> A letter of acceptance from your university, stating your acceptance and enrollment in a full-time course.</li>
                                    <li><i class="fas fa-check"></i> A full-time course is defined as any course that requires 15 hours or more of organized study-time in a week.</li>
                                    <li><i class="fas fa-check"></i> Evidence of financial support for paying the tuition fees.</li>
                                    <li><i class="fas fa-check"></i> Evidence of financial strength amounting to €10000 or more for living expenses.</li>
                                    <li><i class="fas fa-check"></i> Evidence of comprehensive medical insurance.</li>
                                    <li><i class="fas fa-check"></i> Academic background information.</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end of new -->

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education will vary according to the university you apply to and the course you are planning to pursue. Here is a general idea of the tuition fees in Irish universities. <!-- You can also make an application for a scholarship with the help of the Indian Ministry of Education. --> International students can only apply for scholarships to Irish universities through their home country’s ministry of education. Scholarships are awarded by individual educational institutions based on their criteria for eligibility and discretion. </p>
                    <br/><br/>
                    <ul style="list-style-type: none;">
                        <li><i class="fas fa-check"></i>Undergraduate Courses: 9500 to 55000 Euro per annum </li>
                        <li><i class="fas fa-check"></i>Postgraduate Courses:  9000 to 35000 Euro per annum</li>
                    </ul>
                </div>

                <div class="section-title">
                    <h2>Cost of <span> Living in Ireland </span></h2>
                    <p>Living costs for international students in Ireland depend on the city they are living in and the lifestyle they choose to lead. You should expect an approximate expenditure of 8000 to 11000 Euro per annum as living expenses in Ireland.<br/>You can choose to live in on-campus student residences, rented student accommodations or living with a host family. Usually, self-catered rented student accommodation is considered the most economical option.</p>
                </div>

                <div class="section-title">
                    <h2>Health <span> Insurance </span></h2>
                    <p>It is advisable to make a provision for adequate medical insurance when planning to study in Ireland. Proof of health insurance is a prerequisite for an for an Irish visa, you are also required to show evidence of health insurance to register with the Garda National Immigration Bureau (GNIB).</p>
                </div>
            </div>
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>


        <?php include('inc/js.php'); ?>
    </body>
</html>    