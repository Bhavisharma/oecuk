<?php
define('BLOG_PATH','http://127.0.0.1:8000/images/events/');
define('EVENT_PATH','https://www.oecdubai.com/backend_setup/public/');
?>
<meta charset="utf-8" />
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Free counselling | Free admissions | Free visa application assistance - OEC Dubai</title>
        <meta name="author" content="Jasmin Shukal">
        <meta name="keywords" content="">
        <meta name="description" content="Want to Study Abroad? Contact OEC Dubai for UAE’s Leading Education Centre and Offering Various Abroad Study Options Globally. Free Counselling Available.">
        <meta name="google-site-verification" content="u9VneieufqpvW2BqCyrMNZEm0KKF7A2ux5upHiD-mnA" />
        <meta name="google-site-verification" content="eLESle0w-48uY-_emOl3gq2yDblQwOHAaVBy4jy0wMI" />
        <link rel="shortcut icon" type="image/x-icon" href="assets/images/m1.png">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" type="text/css" href="assets/css/style.css" media="all" />
        <link rel="stylesheet" type="text/css" href="./assets/css/plugins.min.css" media="all" />
        <link rel="stylesheet" type="text/css" href="assets/css/magnific-popup.css" media="all" />
       <!--  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/meyer-reset/2.0/reset.min.css"> -->
        <!-- <script type="application/ld+json"> { "@context" : "http://schema.org", "@type" : "Website", "name" : "Welcome to OEC India" } </script> -->