
        <div class="navigation sticky-navigation">
            <div class="container">
                <div class="row">
                        <div class=" col-sm-3">
                                <div class="logo">
                                    <a href="https://www.oecdubai.com/">
                                        <img src="https://www.oecdubai.com/assets/images/finalpic.png" alt="Logo">
                                    </a>
                                </div>
                            </div>
                        <div class="col-sm-9 col-md-9 col-lg-9">
                            <nav class="navbar navbar-expand-lg navbar-light">
                                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                    <span class="icon-bar"></span>
                                </button>
                                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                    <ul class="navbar-nav">
                                        <li class="nav-item">
                                            <a class="nav-link" href="https://www.oecdubai.com/">Home</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="about-us.php">About</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="service.php">Services</a>
                                        </li>
                                        <li class="nav-item dropdown">
                                            <a class="nav-link dropdown-toggle" href="country.php">country</a>
                                            <div class="dropdown-menu">
                                                <a class="dropdown-item" href="australia.php">Australia</a>
                                                <a class="dropdown-item" href="canada.php">Canada</a>
                                                <a class="dropdown-item" href="dubai.php">Dubai</a>
                                                <a class="dropdown-item" href="ireland.php">Ireland</a>
                                                <a class="dropdown-item" href="new-zealand.php">New Zealand</a>
                                                <a class="dropdown-item" href="singapore.php">Singapore</a>
                                                <a class="dropdown-item" href="uk.php">UK</a>
                                                <a class="dropdown-item" href="usa.php">USA</a>
                                            </div>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="gallery.php">Gallery</a> 
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="event.php">Events</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="blog.php">Blog</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="nav-link" href="admission.php">Admissions</a>
                                        </li>

                                        <li class="nav-item">
                                            <a class="nav-link" href="contactus.php">Contact</a>
                                        </li>
                                    </ul>
                                </div>
                            </nav><!-- Navbar /-->
                        </div><!-- columns/-->
                    
                </div>
          </div>
        </div>