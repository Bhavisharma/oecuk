        <a href="#" id="top" title="Go to Top">
        	<i class="far fa-caret-square-up"></i>
        </a>
        
        <div class="preloader">
            <div class="spinner animated infinite fadeIn">
                <div class="preloader-img"></div>
            </div>
    	</div>
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/jquery.appear.js"></script>
        <script src="assets/js/jquery.magnific-popup.min.js"></script>
        <script src="assets/js/template.js"></script>
        <script src='https://cdnjs.cloudflare.com/ajax/libs/vue/2.0.1/vue.min.js'></script>
        <script src="assets/js/script.js"></script>
        <script src="assets/js/slick.js"></script>
        <script src="assets/js/instafeed.min.js"></script>
        <script type="text/javascript">
            $(document).ready(function(){
                $('.customer-logos').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 700,
                arrows: false,
                dots: false,
                pauseOnHover: false,
                responsive: [{
                    breakpoint: 768,
                    settings: {
                        slidesToShow: 4
                    }
                }, {
                    breakpoint: 520,
                    settings: {
                        slidesToShow: 3
                    }
                }]
            });
        });
        </script> 
      