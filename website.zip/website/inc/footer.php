<div class="footer dark-bg grey-bg">
	<div class="footer-top">
    	<div class="container">
        	<div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <div class="footer-top-text footer-border">
                        <!-- <h2>Get In Touch</h2>
                        <p>Write us an email!</p> -->
                        <div class="row">
                         <!--    <div class="col-sm-12 col-md-8 col-lg-8"> -->
                               <!--  <div class="form-group">
                                     <form action="index.php" method="post" id="newsletter-form">
                                    <input type="email" name="email" class="form-control" id="exampleInputEmail2" placeholder="E-mail address" required="">
                                </form>
                                </div>
                            </div>
                            
                            <div class="col-sm-12 col-md-4 col-lg-4">
                                <div class="footer-top-btn">
                                     <form action="index.php" method="post" id="newsletter-form">
                                    <button type="submit" class="btn btn-light" name="subscribe" value="subscribe">Get Started</button>
                                </form> -->
                                <!-- <form action="index.php" method="post" id="newsletter-form">
                                <div class="col-sm-12 col-md-8 col-lg-8">
                                     <div class="form-group">
                                    <input type="email" name="email" class="form-control" id="exampleInputEmail2" placeholder="E-mail address" required="">
                                 </div>
                            </div>
                               <div class="col-sm-12 col-md-8 col-lg-8 bt">
                                <div class="footer-top-btn">
                                    <button type="submit" class="btn btn-light" name="subscribe" value="subscribe">Get Started</button>
                                
                            </div>
                            </div>
                            </ul>
                                <?php
                                        // Only process POST reqeusts.
                                        if ($_SERVER["REQUEST_METHOD"] == "POST") {
                                            // Get the form fields and remove whitespace.
                                            // $name = strip_tags(trim($_POST["name"]));
                                            $name = str_replace(array("\r","\n"),array(" "," "),$name);
                                            $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
                                          

                                            // Check that data was sent to the mailer.
                                            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                                // Set a 400 (bad request) response code and exit.
                                                http_response_code(400);
                                                echo "Please complete the form and try again.";
                                                exit;
                                            }
                                            // Set the recipient email address.
                                            // FIXME: Update this to your desired email address.
                                            $recipient = "oecdubai@outlook.com";
                                            //$addAddress = "himachetriya@gmail.com";
                                            //$addcc = "himachetriya@gmail.com";

                                            // Set the email subject.
                                            $subject = "newsletter-form";

                                             // Build the email content.
                                                $email_content = "Hello Admin,\n Congratulations !! A new subscriber has been registered at <a>OECDUBAI.COM</a>:";
                                                // $email_content .= "Email: $email\n\n";

                                            // Build the email content.
                                            $email_content .= "Email: $email\n\n";
                                           
                                            // Build the email headers.
                                            $email_headers = "From: $name<$email>";

                                            // Send the email.
                                            if (mail($recipient, $subject, $email_content, $email_headers)) {
                                                // Set a 200 (okay) response code.
                                                http_response_code(200);
                                                // echo "Thank You! successfully Send Message";
                                            } else {
                                                // Set a 500 (internal server error) response code.
                                                http_response_code(500);
                                                echo "Oops! Something went wrong and we couldn't send your message.";
                                            }

                                        } else {
                                            // Not a POST request, set a 403 (forbidden) response code.
                                            http_response_code(403);
                                            // echo "There was a problem with your submission, please try again.";
                                        }

                                    ?>
                                </form> -->
                            <!-- </div> -->
                        </div>
                    </div>
                </div>
        </div>
    </div>
    <div class="footer-bottom">
    	<div class="container">
        	<div class="row">
                <div class="col-lg-5 col-md-7 col-sm-12">
                    <div class="footer-box Courses">
                    	<ul class="links  col-padding-y">
                            <li><h6>Overseas Education Centre</h6></li>
                            <li><p class="whity">Floor 36, Cluster X2,</p></li>
                            <li><p class="whity">Jumeirah Lake Towers,</p></li>
                            <li><p class="whity">Dubai, UAE</p></li>
                            <!-- <li><p class="whity"></p></li> -->

                        </ul>
                    </div>
                </div>
                
                <div class="col-lg-3 col-md-5 col-sm-12 col-padding-y">
                    <div class="footer-box Privacy">
                        <h6>Locate Us</h6>
                        <div class="social-icons">
                            <ul class="menu" style="display:flex">
                               <!--  <li><a href="https://www.twitter.com/oec_india"><i class="fab fa-twitter"></i></a></li> -->
                                <li><a href="https://www.facebook.com/oecdubai/" target="_blank"><i class="fab fa-facebook"></i></a></li>
                                <li><a href="https://www.instagram.com/oecdubai/" target="_blank"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div>
                    	<!-- <ul class="links">
                            <li><h6>Privacy & Links</h6></li>
                            <li><a href="#">Q & A</a></li>
                            <li><a href="#">Privacy Politcy</a></li>
                            <li><a href="#">Terms & Condition</a></li>
                            <li><a href="#">Admission </a></li>
                        </ul> -->
                    </div>
                </div>
                
                <div class="col-lg-4 col-md-6 col-sm-12 col-padding-y">
                    <div class="footer-box follow-us">
                    	<!-- <h6>Locate Us</h6>
                        <div class="social-icons">
                            <ul class="menu">
                                <li><a href="https://www.twitter.com/oec_india"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="https://www.facebook.com/oecbaroda/"><i class="fab fa-facebook"></i></a></li>
                                <li><a href="https://www.instagram.com/oecindia/"><i class="fab fa-instagram"></i></a></li>
                            </ul>
                        </div> -->
                    	<div class="subscribe-us">
                            <div class="comment-form">
                          <h2 class="main-title" style="color: white;">Get In Touch</h2>
                          <p class="main-title"> </p>
                          <!-- end of message -->
                          <form class="needs-validation" method="POST" id="submit_contact" onsubmit="send();">
                                <div class="form-row">
                                    <div class="col-md-6 mb-3">
                                    <input type="text" class="form-control" placeholder="First name" required="" autocomplete="off" name="name"> 
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <input type="text" class="form-control" placeholder="email" required="" autocomplete="off" name="email">
                                        <!-- <div class="valid-tooltip">Looks good!</div> -->
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <input type="text" class="form-control" placeholder="Phone Number" required="" autocomplete="off" name="phone"> 
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <!-- <input type="text" class="form-control" placeholder="country" required="" autocomplete="off" name="country"> -->
                                        <select id="country" name="country" class="form-control" required="">
                                                                <option value="">Select country</option>
                                                                <option value="Australia">Australia</option>
                                                                <option value="Canada">Canada</option>
                                                                <option value="Dubai">Dubai</option>
                                                                <option value="Ireland">Ireland</option>
                                                                <option value="New Zeland">New Zeland</option>
                                                                <option value="Singapore">Singapore</option>
                                                                <option value="UK">UK</option>
                                                                <option value="USA">USA</option>
                                                            </select>
                                    </div>
                                    <div class="col-md-12 Textarea-btn">
                                    <textarea class="form-control mb-3" id="exampleFormControlTextarea1" rows="5" name="message" placeholder="Your Message..." required="" autocomplete="off" ></textarea>
                                    <button class="btn btn-secondary btn-padding btn-dark-animated" type="submit">Send Message</button>
                                    <!--<a class="btn btn-secondary btn-padding btn-dark-animated" onclick="send();">Send Message</a>-->
                                    </div>
                                </div>
                         
                        
                            <?php
                                if ($_SERVER["REQUEST_METHOD"] == "POST") 
                                {
                                    // Get the form fields and remove whitespace.
                                    $name = strip_tags(trim($_POST["name"]));
                                            $name = str_replace(array("\r","\n"),array(" "," "),$name);
                                    $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
                                    $phone = trim($_POST["phone"]);
                                    $country = trim($_POST["country"]);
                                    $message = trim($_POST["message"]);

                                    // Check that data was sent to the mailer.
                                    if ( empty($name) OR empty($country) OR empty($phone) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                        // Set a 400 (bad request) response code and exit.
                                        http_response_code(400);
                                        echo "Please complete the form and try again.";
                                        exit;
                                    }

                                    // Set the recipient email address.
                                    // FIXME: Update this to your desired email address.
                                    $recipient = "oecdubai@outlook.com";

                                    // Set the email subject.
                                    $subject = "OEC Inquiry Form";

                                    // Build the email content.
                                    $email_content .= "Hello OEC Team,\n\n$name contacts you from your OEC Website\n\nThe Candidate Details are mentioned below\nName : $name\n";
                                    $email_content .= "Email: $email\n";
                                    $email_content .= "Phone: $phone\n";
                                    $email_content .= "Country: $country\n";
                                    $email_content .= "Message: $message\n\n Regards,\nOVERSEAS EDUCATION CENTRE\n2nd Floor,Prestige Building,\nRace Course Circle,\nbeside Axis Bank,\nVadodara, Gujarat 390007";

                                    // Build the email headers.
                                    $email_headers = "From: $name <$email>";

                                    // Send the email.
                                    if (mail($recipient, $subject, $email_content, $email_headers)) {
                                        // Set a 200 (okay) response code.
                                        http_response_code(200);
                                        
                                        header('location:footer.php');
                                        echo "Thank you for contacting OEC.", "A counsellor will  reply to you shortly.";
                                    } else {
                                        // Set a 500 (internal server error) response code.
                                        http_response_code(500);
                                        
                                    }

                                } else {
                                    http_response_code(403);
                                    echo "";
                                }
                            ?>
                                </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="footer-Copyright">
    	<div class="container">
        	<div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                	<div class="copyrightinfo">All Rights Reserved © <?=date('Y')?>. OECDubai. <a href="privacy-policy.php" target="_blank"> Privacy Policy</a></div>
                </div>
            </div>
        </div>
    </div>
</div>