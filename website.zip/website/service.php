<!doctype html>
<html lang="en">
<head><?php include('inc/meta_css.php'); ?></head>
<body>
    <div class="main-container faqs-page">
        <?php include('inc/header.php'); ?>
        <div class="title-section dark-bg module grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-padding-y">
                        <div class="title-section-text">
                            <h1>Services</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--  <div class="why-chose-us grey-bg"> -->
        <div class="section-title">
            <h2>We <span>Provide</span></h2>
            <!-- <p>Services We Provide</p> -->
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                    <div class="faq-wrap">
                        <div class="accordion" id="accordionExample">
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingOne">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseOne" aria-expanded="false"
                                            aria-controls="collapseOne">Career Counselling</button>
                                    </h2>
                                </div>
                                <div id="collapseOne" class="collapse" aria-labelledby="headingOne"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>Charting out your career path is a key step in planning for your higher
                                            education. At OEC, we put great emphasis on finding the right career path
                                            before we begin to plan for your overseas education. Our experienced staff
                                            members provide professional counselling services to help you define your
                                            career goals and the education relevant to achieving them. This helps
                                            students make an informed decision about their higher education.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingTwo">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseTwo" aria-expanded="false"
                                            aria-controls="collapseTwo">Country Selection</button>
                                    </h2>
                                </div>
                                <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>Selecting the right education destination can be a daunting task. It may be
                                            difficult to choose
                                            from a vast array of international universities offering courses in your
                                            field of study. At OEC we take all factors such as academic needs, budget,
                                            and student preferences into consideration when we help you select the right
                                            destination for overseas education.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingThree">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseThree" aria-expanded="false"
                                            aria-controls="collapseThree">Course Selection</button>
                                    </h2>
                                </div>
                                <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>To select the course best suited to your aptitude and interests, it is
                                            important to have the right information. OEC has a wide network of education
                                            experts around the world and we keep our databases updated with the latest
                                            information on all available courses. Our counsellors analyze all the
                                            relevant information including your preference, academic background, and
                                            career goals, before recommending a course to you.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingFive">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseFive" aria-expanded="false"
                                            aria-controls="collapseFive">Pre-Departure Guidance</button>
                                    </h2>
                                </div>
                                <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>OEC organizes pre-departure orientation sessions for our students. These
                                            sessions offer an opportunity to meet other students who are also travelling
                                            abroad for studies. Interaction with other students going to the same
                                            country can help you sort out various aspects of moving abroad such as
                                            accommodation arrangement, local transportation, purchasing household items,
                                            getting a part-time job, etc.<br />
                                            Our pre-departure guidance also includes assistance for Forex, debit cards,
                                            and connecting our students with current students at the university you are
                                            going to study at.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingSix">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseSix" aria-expanded="false"
                                            aria-controls="collapseSix">Travel Assistance</button>
                                    </h2>
                                </div>
                                <div id="collapseSix" class="collapse" aria-labelledby="headingSix"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>We understand how important it is to be well-prepared when you are travelling
                                            abroad. This is why OEC offers end-to-end travel assistance and support to
                                            all students. We help you to make all your bookings on time and find the
                                            most economic air tickets, hotel accommodations, and local travel
                                            assistance.Our counsellors provide useful information regarding special
                                            student discounts and schemes offered by airlines.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingSeven">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseSeven" aria-expanded="false"
                                            aria-controls="collapseSeven">Visa Guidance</button>
                                    </h2>
                                </div>
                                <div id="collapseSeven" class="collapse" aria-labelledby="headingSeven"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>Applying for a visa to a foreign country involves several formalities and
                                            elaborate paperwork. All the information about the latest visa regulations
                                            and required documentation is available with OEC counsellors. We help
                                            students get their visa formalities completed with ease, by providing the
                                            right information and helping to compile all the requisite documents on
                                            time.</p>
                                    </div>
                                </div>
                            </div>
                            <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                <div class="card-header" id="headingEight">
                                    <h2 class="mb-0">
                                        <button class="btn btn-link collapsed" type="button" data-toggle="collapse"
                                            data-target="#collapseEight" aria-expanded="false"
                                            aria-controls="collapseEight">Visa Interview</button>
                                    </h2>
                                </div>
                                <div id="collapseEight" class="collapse" aria-labelledby="headingEight"
                                    data-parent="#accordionExample">
                                    <div class="card-body">
                                        <p>At OEC we offer extensive preparation for visa interviews for all education
                                            destinations. After all the paperwork is completed and submitted, we help
                                            students to be
                                            fully prepared to meet the demands of their visa interviews. We provide
                                            information
                                            about the most common interview questions and situations that students
                                            encounter
                                            during the visa interview process. In order to succeed in their visa
                                            interview, we
                                            encourage students to articulate their responses with confidence and honesty
                                            via
                                            appropriate preparation and strong presentation skills.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- </div> -->
        <?php include('inc/request.php'); ?>
        <?php include('inc/footer.php'); ?>
    </div>
    <?php include('inc/js.php'); ?>
</body>
</html>