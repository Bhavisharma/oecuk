<!doctype html>

<html lang="en">

    <head><?php include('inc/meta_css.php'); ?></head>
    <body>

        <div class="main-container faqs-page">

            <?php include('inc/header.php'); ?>

            <div class="our-courses grey-bg grey-bg-color">

            <div class="section-title">

                <h2>Our Featured <span>Countries</span></h2>

                <p>With awesome institute we have arranged some awesome courses for you from which this is list of some featured courses!</p>

            </div>

            <div class="container">

                <div class="row">

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img1.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">Australia</a></h5>

                                <a href="australia.php" class="btn btn-light btn-dark-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">Canada</a></h5>

                                <a href="canada.php" class="btn btn-dark btn-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img3.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">Dubai</a></h5>

                                <a href="dubai.php" class="btn btn-light btn-dark-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img4.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">Ireland</a></h5>

                                <a href="ireland.php" class="btn btn-dark btn-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img5.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">New Zealand</a></h5>

                                <a href="new-zealand.php" class="btn btn-dark btn-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                    <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img6.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">Singapore</a></h5>

                                <a href="singapore.php" class="btn btn-light btn-dark-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>



                     <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img6.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">UK</a></h5>

                                <a href="uk.php" class="btn btn-dark btn-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>



                     <div class="col-sm-12 col-md-6 col-lg-3 col-padding-y">

                        <div class="course-warp">

                            <div class="course-img">

                                <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">

                            </div>

                            <div class="course-text">

                                <h5><a href="#">USA</a></h5>

                                <a href="usa.php" class="btn btn-light btn-dark-animated">Apply Now</a>

                            </div>

                        </div>

                    </div>

                    

                

                </div>

            </div>

        </div>

            <?php include('inc/footer.php'); ?>

        </div>

        <?php include('inc/js.php'); ?>

    </body>

</html>    