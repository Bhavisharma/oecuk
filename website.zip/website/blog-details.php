<?php
include('db.php');

error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<!doctype html>
<html lang="en">
<head>
    <?php include('inc/meta_css.php'); ?>
</head>
<body>
    <div class="main-container about-us-page">
        <?php include('inc/header.php'); ?>
        <div class="title-section dark-bg module grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-padding-y">
                        <div class="title-section-text">
                            <h1>Blog-Details</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <link rel="stylesheet" href="oecdubai.com\assets\css\style.css">
        <link rel="stylesheet" href="oecdubai.com\assets\css\material-design-iconic-font.min">
        <?php
        $sql = "SELECT * FROM blogs where slug='".$_GET['name']."'";
        global $conn;
        $result = $conn->query($sql);
        $row=$result->fetch_assoc();
        ?>
        <div class="blog-single gray-bg">
            <div class="container">
                <div class="row align-items-start">
                    <div class="col-lg-8 m-15px-tb">
                        <article class="article">
                            <div class="article-img">
                                <img src="backend/images/events/<?=$row['image'];?>" title="" alt="">
                            </div>
                            <div class="article-title">
                                <br>
                                <h2><?=$row['title'];?></h2>
                                
                            </div>
                            <div class="article-content">
                                <?=$row['description'];?>
                            </div>
                        </article>
                    </div>
                    
                </div>
            </div>
        </div>
        <?php include('inc/request.php'); ?>
        <?php include('inc/footer.php'); ?>
        <?php include('inc/js.php'); ?>
</body>
</html>