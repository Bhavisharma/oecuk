<!doctype html>
<html lang="en">
    <head>
        <?php include('inc/meta_css.php'); ?>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.min.js" integrity="sha512-MqEDqB7me8klOYxXXQlB4LaNf9V9S0+sG1i8LtPOYmHqICuEZ9ZLbyV3qIfADg2UJcLyCm4fawNiFvnYbcBJ1w==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-sweetalert/1.0.1/sweetalert.css" integrity="sha512-f8gN/IhfI+0E9Fc/LKtjVq4ywfhYAVeMGKsECzDUHcFJ5teVwvKTqizm+5a84FINhfrgdvjX8hEJbem2io1iTA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    </head>
    
       <body>
        <div class="main-container faqs-page">
          <?php include('inc/header.php'); ?>
          <div class="title-section module grey-bg bhavi">
            
              <div class="container">
                  <div class="row">
                      <div class="col-sm-12 col-padding-y">
                          <div class="title-section-text">
                              <h2>We want to hear from you</h2>
                              <h1>Contact Us</h1>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <div class="contact-page module">
            <div class="container">
              <div class="row">
                <div class="col-sm-12 col-lg-12 col-md-12 col-padding-y">
                  <div class="contact-map">
                   <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3613.6460042945396!2d55.150453814303845!3d25.07998464260206!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6ca769ffa309%3A0xe8034632f3ac1f08!2sJLT%20Cluster%20X!5e0!3m2!1sen!2sin!4v1619169826172!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                  </div>
                </div>
              </div>
            </div>
            <style type="text/css">
            	    #thank-you-message {display: none;}
            	    #thank-you-message.show {display: block;}
                  .contact-us{
                      background: #003366;
                      padding: 35px;
                      color: #FFFFFF;
                  }
                  .contact-us .main-title{
                      color: #FFFFFF;
                      font-weight: 700;
                      font-size: 28px;
                  }
                  .bhavi{
                      background-image: url(../assets/images/help/ncontact.jpg);
                      background-position: center;
                  }
                  .address{
                      font-size: 15px;
                      font-weight: 400;
                      line-height: 1.7em;
                  }
                  .address i{
                      font-size: 24px;
                      color: #0fbbdd;
                      margin: 5px;
                  }
                  .address p{
                      color: #FFFFFF;
                  }
                  /*LOCATION*/
                  .bhcontainer {
                    padding: 40px 80px;
                    display: -webkit-box;
                    display: flex;
                    flex-wrap: wrap;
                    -webkit-box-pack: center;
                            justify-content: center;
                  }
                  .bhcard-wrap {
                    margin: 10px;
                    -webkit-transform: perspective(800px);
                            transform: perspective(800px);
                    -webkit-transform-style: preserve-3d;
                            transform-style: preserve-3d;
                    cursor: pointer;
                  }
                  .bhcard-wrap:hover .bhcard-info {
                    -webkit-transform: translateY(0);
                            transform: translateY(0);
                  }
                  .bhcard-wrap:hover .bhcard-info p {
                    opacity: 1;
                  }
                  .bhcard-wrap:hover .bhcard-info, .bhcard-wrap:hover .bhcard-info p {
                    -webkit-transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1);
                    transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1);
                  }
                  .bhcard-wrap:hover .bhcard-info:after {
                    -webkit-transition: 5s cubic-bezier(0.23, 1, 0.32, 1);
                    transition: 5s cubic-bezier(0.23, 1, 0.32, 1);
                    opacity: 1;
                    -webkit-transform: translateY(0);
                            transform: translateY(0);
                  }
                  .bhcard-wrap:hover .bhcard-bg {
                    -webkit-transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1), opacity 5s cubic-bezier(0.23, 1, 0.32, 1);
                    transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1), opacity 5s cubic-bezier(0.23, 1, 0.32, 1);
                    opacity: 0.8;
                  }
                  .bhcard-wrap:hover .bhcard {
                    -webkit-transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 2s cubic-bezier(0.23, 1, 0.32, 1);
                    transition: 0.6s cubic-bezier(0.23, 1, 0.32, 1), box-shadow 2s cubic-bezier(0.23, 1, 0.32, 1);
                    box-shadow: rgba(255, 255, 255, 0.2) 0 0 40px 5px, white 0 0 0 1px, rgba(0, 0, 0, 0.66) 0 30px 60px 0, inset #333 0 0 0 5px, inset white 0 0 0 6px;
                  }
                  .bhcard {
                    position: relative;
                    -webkit-box-flex: 0;
                     flex: 0 0 240px;
                    width: 240px;
                    height: 320px;
                   background-color: #000;
                   /* background-color: #333;*/
                    overflow: hidden;
                    border-radius: 10px;
                    box-shadow: rgba(0, 0, 0, 0.66) 0 30px 60px 0, inset #333 0 0 0 5px, inset rgba(255, 255, 255, 0.5) 0 0 0 6px;
                    -webkit-transition: 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                    transition: 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                  }
                  .bhcard-bg {
                    opacity: 0.7;
                    position: absolute;
                    top: 0px;
                    left: 0px;
                    width: 100%;
                    height: 100%;
                    padding: 20px;
                    background-repeat: no-repeat;
                    background-position: center;
                    background-size: cover;
                    -webkit-transition: 1s cubic-bezier(0.445, 0.05, 0.55, 0.95), opacity 5s 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                    transition: 1s cubic-bezier(0.445, 0.05, 0.55, 0.95), opacity 5s 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                    pointer-events: none;
                  }
                  .bhcard-info {
                      text-align: center;
                      top: 20px;
                      /*bottom: 100px;*/
                    padding: 20px;
                   position: absolute;
                    bottom: 0;
                    color: #fff;
                    -webkit-transform: translateY(40%);
                            transform: translateY(40%);
                    -webkit-transition: 0.6s 1.6s cubic-bezier(0.215, 0.61, 0.355, 1);
                    transition: 0.6s 1.6s cubic-bezier(0.215, 0.61, 0.355, 1);
                  }
                  .bhcard-info p {
                      color: #ffffff;
                    opacity: 0;
                    text-shadow: black 0 2px 3px;
                    -webkit-transition: 0.6s 1.6s cubic-bezier(0.215, 0.61, 0.355, 1);
                    transition: 0.6s 1.6s cubic-bezier(0.215, 0.61, 0.355, 1);
                  }
                  .bhcard-info * {
                    position: relative;
                    z-index: 1;
                  }
                  .bhcard-info:after {
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    z-index: 0;
                    width: 100%;
                    height: 100%;
                    background-image: -webkit-gradient(linear, left top, left bottom, from(transparent), to(rgba(0, 0, 0, 0.6)));
                    background-image: linear-gradient(to bottom, transparent 0%, rgba(0, 0, 0, 0.6) 100%);
                    background-blend-mode: overlay;
                    opacity: 0;
                    -webkit-transform: translateY(100%);
                            transform: translateY(100%);
                    -webkit-transition: 5s 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                    transition: 5s 1s cubic-bezier(0.445, 0.05, 0.55, 0.95);
                  }
                  .bhcard-info h1 {
                     color: #ffffff; 
                    font-size: 36px;
                    font-weight: 700;
                    text-shadow: rgba(0, 0, 0, 0.5) 0 10px 10px;
                  }

                  /*responsiveness of hover effect*/
                  @media only screen and (max-width: 425px){
                    .bhcard-info {
                            text-align: center;
                            top: -41px;
                            padding: 20px;
                            position: absolute;
                            }
                    .bhcard-info p{opacity: 1;}
                 }
                   /*end of new css*/
            </style>
            <div class="container">
              <div class="row contact-us">
              	<!-- start dubai  -->
              	<div class="col-md-6">
                  <h2 class="main-title">UAE</h2>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                    <p class="col-md-11"> Floor 36, Cluster X2,<br>Jumeirah Lake Towers,<br>Dubai, UAE</p>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-phone"></i></p>
                    <a href="tel:0552643566"><p class="col-md-11"> 0552643566</p></a>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                    <a href="mailto:Oecdubai@outlook.com"><p class="col-md-11"> Oecdubai@outlook.com</p></a>
                  </div>
                </div>
              	<!-- <div class="col-md-6">
                  <h2 class="main-title">Sri Lanka</h2>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                    <p class="col-md-11">Colombo : No 110 , Level 2, Elvitigala Mawatha,<br>Colombo 8, Sri Lanka</p>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-phone"></i></p>
                    <a href="tel:94775886880"><p class="col-md-11"> 94775886880</p></a>
                  </div>
                   <div class="address row">
                          <p class="col-md-1"><i class="fa fa-phone"></i></p>
                           <a href="tel:94771475555"><p class="col-md-11"> 94771475555</p></a>
                      </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                    <a href="mailto:oeccolombo@live.com"><p class="col-md-11"> oeccolombo@live.com</p></a>
                  </div>
                </div> -->
              	<!-- end dubai -->
                  
                  <!-- start -->
                  <div class="col-sm-12 col-lg-6 col-md-6 col-padding-y">
                    <?php
                    include('db.php');
                    global $conn;
                    $conn =$mysqli;
    // Only process POST reqeusts.
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get the form fields and remove whitespace.
        $name = strip_tags(trim($_POST["name"]));
                $name = str_replace(array("\r","\n"),array(" "," "),$name);
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        $phone = trim($_POST["phone"]);
        $country = trim($_POST["country"]);
        $message = trim($_POST["message"]);

        // Check that data was sent to the mailer.
        if ( empty($name) OR empty($country) OR empty($phone) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            http_response_code(400);
            echo "Please complete the form and try again.";
            exit;
        }

        // Set the recipient email address.
        // FIXME: Update this to your desired email address.
        $recipient = "oecdubai@outlook.com";

        // Set the email subject.
        $subject = "OEC Inquiry Form";

        // Build the email content.
        $email_content .= "Hello OEC Team,\n\n$name contacts you from your OEC Website\n\nThe Candidate Details are mentioned below\nName : $name\n";
        $email_content .= "Email: $email\n";
        $email_content .= "Phone: $phone\n";
        $email_content .= "Country: $country\n";
        $email_content .= "Message: $message\n\n Regards,\nOVERSEAS EDUCATION CENTRE\n2nd Floor,Prestige Building,\nRace Course Circle,\nbeside Axis Bank,\nVadodara, Gujarat 390007";

        // Build the email headers.
        $email_headers = "From: $name <$email>";

        // Send the email.
        if (mail($recipient, $subject, $email_content, $email_headers)) {
            // Set a 200 (okay) response code.
            http_response_code(200);
            
            // header('location:contactus.php');
        } else {
            // Set a 500 (internal server error) response code.
            http_response_code(500);
            
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        http_response_code(403);
        echo "";
    }

?>
                      <div class="comment-form">
                          <h2 class="main-title">Get In Touch</h2>
                          <p class="main-title"> </p>
                          <!-- end of message -->
                          <form class="needs-validation" method="POST" id="submit_contact" onsubmit="send();">
                              <div class="form-row">
                                <div class="col-md-6 mb-3">
                                  <input type="text" class="form-control" placeholder="First name" required="" autocomplete="off" name="name"> 
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="text" class="form-control" placeholder="email" required="" autocomplete="off" name="email">
                                    <!-- <div class="valid-tooltip">Looks good!</div> -->
                                </div>
                                <div class="col-md-6 mb-3">
                                    <input type="text" class="form-control" placeholder="Phone Number" required="" autocomplete="off" name="phone"> 
                                </div>
                                <div class="col-md-6 mb-3">
                                    <!-- <input type="text" class="form-control" placeholder="country" required="" autocomplete="off" name="country"> -->
                                    <select id="country" name="country" class="form-control" required="">
                											<option value="">Select country</option>
                											<option value="Australia">Australia</option>
                											<option value="Canada">Canada</option>
                											<option value="Dubai">Dubai</option>
                											<option value="Ireland">Ireland</option>
                											<option value="New Zeland">New Zeland</option>
                											<option value="Singapore">Singapore</option>
                											<option value="UK">UK</option>
                											<option value="USA">USA</option>
                										</select>
                                </div>
  	                            <div class="col-md-12 Textarea-btn">
                                  <textarea class="form-control mb-3" id="exampleFormControlTextarea1" rows="5" name="message" placeholder="Your Message..." required="" autocomplete="off" ></textarea>
                                  <button class="btn btn-secondary btn-padding btn-dark-animated" type="submit">Send Message</button>
                                  <!--<a class="btn btn-secondary btn-padding btn-dark-animated" onclick="send();">Send Message</a>-->
  	                            </div>
                              </div>
                          </form>
                          <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"> -->
                    
                      </div>
                  </div>
                  <!-- end -->
              </div>
            </div>
              <br/>
            <div class="container">
              <div class="row contact-us">
              	<!-- start vadodara -->
              	<div class="col-md-6">
                      <h2 class="main-title">Head-Office</h2>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                          <p class="col-md-11">2nd Floor, Prestige Building, <br>Beside Axis Bank,<br> Race Course Circle, <br>Vadodara - 390007 Gujarat</p>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-phone"></i></p>
                           <a href="tel:+91 9327581167"><p class="col-md-12">+91 9327581167</p></a>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-phone"></i></p>
                          <a href="tel:+91 8905570642"><p class="col-md-12">+91 8905570642</p></a>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                          <a href="mailto:uk@oecindia.com"><p class="col-md-11"> uk@oecindia.com</p></a>
                      </div>
                      <!--  <h2 class="main-title">Sri Lanka</h2>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                          <p class="col-md-11"> Colombo : No 110 , Level 2, Elvitigala Mawatha,<br>Colombo 8, Sri Lanka</p>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-phone"></i></p>
                          <a href="tel:94114545055"><p class="col-md-11"> +94114545055</p></a>
                          <a href="tel:94114545056"><p class="col-md-11"> +94114545056</p></a>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-phone"></i></p>
                          <a href="tel:94775886880"><p class="col-md-11"> +94775886880</p></a>
                          <a href="tel:94771475555"><p class="col-md-11"> ++94771475555</p></a>
                      </div>
                      <div class="address row">
                          <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                          <a href="mailto:Oecdubai@outlook.com"><p class="col-md-11"> oeccolombo@live.com</p></a>
                      </div>  --><!-- dubai -->
                      <!-- end of dubai -->
                  </div>
              	<!-- end vadodara -->
              	<div class="col-md-6">
                  <h2 class="main-title">Sri Lanka</h2>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                    <p class="col-md-11">Colombo : 36B, Gower Street,<br>Colombo 05, <br>Sri Lanka</p>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-phone"></i></p>
                    <a href="tel:94775886880"><p class="col-md-11"> 94775886880</p></a>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-phone"></i></p>
                    <a href="tel:94771475555"><p class="col-md-11"> 94771475555</p></a>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                    <a href="mailto:oeccolombo@live.com"><p class="col-md-11"> oeccolombo@live.com</p></a>
                  </div>
                </div>
                <!-- <div class="col-md-6">
                  <h2 class="main-title">UAE</h2>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-map-marker"></i></p>
                    <p class="col-md-11"> Floor 36, cluster X tower 2,<br> JLT, Dubai.</p>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-phone"></i></p>
                    <a href="tel:0552643566"><p class="col-md-11"> 0552643566</p></a>
                  </div>
                  <div class="address row">
                    <p class="col-md-1"><i class="fa fa-envelope"></i></p>
                    <a href="mailto:Oecdubai@outlook.com"><p class="col-md-11"> Oecdubai@outlook.com</p></a>
                  </div>
                </div> -->
              </div>
            </div>
              <!-- location -->
              <div id="app" class="bhcontainer">
                <a href="https://goo.gl/maps/6W1X33bkAWvS7YTk7">
                    <card data-image="https://www.oecindia.com/assets/images/places/hyd.jpg">
                  <h1 slot="header"> Hyderabad </h1>
                  <p slot="content">G2 / A 1-10-72/5, Chikoti Gardens, Begumpet, Hyderabad - 500016, <br/>Andhra Pradesh <br/>M: 9246115977 / 9246116077</p>
                </card></a>
                <a href="https://goo.gl/maps/3GYhF5UtroZejEA39">
                <card data-image="https://www.oecindia.com/assets/images/places/mumbai.jpg">
                  <h1 slot="header"> Mumbai </h1>
                  <p slot="content">101, A Block,1st Floor, Ranjeet Studio, Dadasaheb Phalke Road, Dadar East Mumbai,<br/> Maharashtra - 400014 <br/>M: 9029014822</p>
                </card></a>
                <a href="https://goo.gl/maps/VhZWtYRAJh9xswMA7">
                <card data-image="https://www.oecindia.com/assets/images/places/pune.jpg">
                  <h1 slot="header"> Pune </h1>
                  <p slot="content"> 5th Avenue, B5 Ground Floor, Ganpati Chowk,177 Dhole Patil Road, <br/>Pune, <br/>Maharashtra - 411001<br/> M: 9029014822</p>
                </card></a>
              </div>
              <!-- end of location -->
          </div>
          <!-- end of new code -->
          <?php include('inc/footer.php'); ?>
        </div>

        <?php include('inc/js.php'); ?>
        <!-- script -->
    
        <script type="text/javascript">
        $( document ).ready(function() {
        function send() {
            $.ajax({
                url: 'submit_contact.php',
                data: $("#submit_contact").serialize(),
                type: 'post',
                success: function (data) {
                   swal("Thank you for contacting OEC.", "A counsellor will  reply to you shortly.", "success");
                    console.log(data);
                    // $('#target').html(data.msg);
                },
                
            });
        }
        $("#submit_contact").submit(function(){
            send();
            return false;
        });
        });
        
        </script>
      <!--<script type="text/javascript">
			const form = document.querySelector('form');
			const thankYouMessage = document.querySelector('#thank-you-message');
			form.addEventListener('submit', (e) => {
			  e.preventDefault();
			  thankYouMessage.classList.add('show');
			  setTimeout(() => form.submit(), 2000);
			});
        </script> -->

        <!-- end of script -->

    </body>
    
</html>    