<?php
include('db.php');
include('function.php');
?>
<!doctype html>
<html lang="en">
    <head><?php include('inc/meta_css.php'); ?></head>
    <body>
        <div class="main-container faqs-page">
            <?php include('inc/header.php'); ?>
            
            <div class="title-section dark-bg module grey-bg">
                <div class="container">
                    <div class="row">
                        
                        <div class="col-sm-12 col-padding-y">
                            <div class="title-section-text">
                                <h2>Choose the right Career</h2>
                                <h1>Canada</h1>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>

            <div class="about-us module">
                <div class="section-title">
                    <h2>Study in <span>Canada</span></h2>
                    <p>Canada is a popular destination for overseas students. This is owing to the high-quality education system and relatively simple visa procedures. Degrees and diplomas from Canadian universities are recognized across the globe, and Canada is reputed for their welcoming culture towards foreign nationals. Here are some reasons why you should opt for Canada as your study destination.</p><br/>
                </div>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="canada">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">
                            <!-- <h2 class="campus-title">Why Study in Australia?</h2> -->                            
                            <ul class="menu">
                                <li><i class="fas fa-check"></i><strong>Tuition Fees –</strong>  Canadian institutions offer a concession on tuition fees overseas  students.</li>
                                <li><i class="fas fa-check"></i><strong>Flexible Work Permit –</strong> Students are eligible for working off-campus for up to 20 hours a week.</li>
                                <li><i class="fas fa-check"></i> <strong>Paid Co-op Term –</strong>Several professional courses in Canadian universities offer cooperative (Co-op) education programs wherein a structured job experience is integrated with your course. This helps you to get hands-on industry experience even as you are studying.</li>
                                <li><i class="fas fa-check"></i> <strong>Work-Visa –</strong>  After you finish your education, you are eligible for a work visa for up to 3 years in Canada.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div> 
            <div class="why-chose-us grey-bg">
                <div class="section-title">
                    <h2>List of <span>Universities</span></h2>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">
                            <div class="faq-wrap">
                                <!-- <h3>List Of University</h3> -->
                                <div class="accordion" id="accordionExample">
                                    <?php
                                    $where="county='canada'";
                                    foreach(get_list_with_whare('universities',$where) as $uni)
                                    {
                                        ?>
                                    
                                        <div class="card animated" data-animation="slideInUp" data-animation-delay="500">
                                            <div class="card-header" id="headingOne">
                                                <h2 class="mb-0">
                                                    <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne<?=$uni['id'];?>" aria-expanded="false" aria-controls="collapseOne<?=$uni['id'];?>"><?=$uni['name'];?></button>
                                                </h2>
                                            </div>
                                            <div id="collapseOne<?=$uni['id'];?>" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
                                                <div class="card-body">
                                                   <a href="<?=$uni['url'];?>">Visit Website</a>
                                                </div>
    
                                            </div>
                                        </div>
                                        <?
                                        
                                    }
                                    ?>
                                    
                                </div>
                            </div>
                        </div>
                  </div>
                </div>

                <!-- courses List -->
                <div class="our-courses grey-bg grey-bg-color module">
                    <div class="section-title">
                        <h2>Popular <span>Courses</span></h2>
                        <p>The Canadian education system offers a wide range of technical and non-technical courses for
international students. Universities in Canada are rich in infrastructure and offer curriculums that
are updated with the latest industry developments to give students a high-level of exposure. Some
of the courses popular among students.</p>
                    </div><!-- Section Title /-->
                    <div class="container">
                        <div class="row">
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/avi.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>$29.00</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                            <h6>Aviation</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Aviation Courses</a></h5>
                                        <p>Some of the most reputed commercial and defence pilots in the world have studied aviation in Canada. Courses in Canada focus on operational aspects of aircraft, aviation technologies and professional responsibilities of pilots.</p>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/our-courses-img2.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>Free</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-2.png" alt="teacher"> -->
                                            <h6>Engineering & Technology</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Engineering & Technology Courses</a></h5>
                                        <p> Some of the best technological courses, updated concepts and resources for learning are available for engineering students in Canadian Universities. For this reason, admission to engineering programs in Canada is also competitive.</p>
                                       <!--  <ul class="menu">
                                            <li><i class="fas fa-check"></i>Information systems </li>
                                            <li><i class="fas fa-check"></i>Software development</li>
                                            <li><i class="fas fa-check"></i> Networking </li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/life.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>$59.00</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-1.png" alt="teacher"> -->
                                            <h6>Life Sciences</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Life Sciences</a></h5>
                                        <p>Canada is a hub for the biotechnology industry, perhaps the biggest after the USA. Therefore the education system is also well-equipped to impart in-depth knowledge of life sciences in graduate and postgraduate levels. Choose from a wide variety of courses including biology, forensic sciences, and science writing.</p>
                                        <!-- <ul class="menu">
                                            <li><i class="fas fa-check"></i>  Marketing </li>
                                            <li><i class="fas fa-check"></i>  Finance</li>
                                            <li><i class="fas fa-check"></i>  Human Resources</li>
                                            <li><i class="fas fa-check"></i>  Operations Management</li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/business.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>$49.00</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-4.png" alt="teacher"> -->
                                            <h6>Business Management</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Business Management</a></h5>
                                        <p>Business management courses in Canada offer a plethora of opportunities for students to develop skills for analysis, leadership, and management. Studying Business Management from Canada is one of the most common preferences of students <!-- in India -->.</p>
                                        <!-- <ul class="menu">
                                            <li><i class="fas fa-check"></i> Statistics </li>
                                            <li><i class="fas fa-check"></i> Specialized Mathematics</li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/our-courses-img5.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>$69.00</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-5.png" alt="teacher"> -->
                                            <h6>Humanities</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Humanities</a></h5>
                                        <p>Under the different branches of humanities and social sciences, the subject of Psychology is increasingly gaining popularity among students in Canada. Apart from that, political science and sociology are also prominent courses in Canadian universities.</p>
                                       <!--  <ul class="menu">
                                            <li><i class="fas fa-check"></i> Nursing</li>
                                            <li><i class="fas fa-check"></i> Nutrition</li>
                                            <li><i class="fas fa-check"></i> Family Healthcare </li>
                                            <li><i class="fas fa-check"></i> Pharmaceutical Science</li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-light btn-dark-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>
                            
                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/agr.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>Free</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
                                            <h6>Tourism & Travel</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Tourism & Travel Courses</a></h5>
                                        <p>Courses focusing on hotel management, tourism management and logistics are offered by many universities in Canada.</p>
                                        <!-- <ul class="menu">
                                            <li><i class="fas fa-check"></i> Agricultural Sciences</li>
                                            <li><i class="fas fa-check"></i>  Horticulture</li>
                                            <li><i class="fas fa-check"></i>  Forestry</li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>

                            <div class="col-sm-6 col-md-3 col-lg-3 col-padding-y">
                                <div class="course-warp">
                                    <div class="course-img">
                                        <img src="assets/images/help/our-courses/sport.jpg" alt="Our Courses">
                                        <!-- <div class="course-price">
                                            <h6>Free</h6>
                                        </div> -->
                                        <div class="course-teacher">
                                            <!-- <img src="assets/images/help/our-courses/teacher-6.png" alt="teacher"> -->
                                            <h6>Sports</h6>
                                        </div>
                                    </div>
                                    <div class="course-text">
                                        <h5><a href="#">Sports</a></h5>
                                        <p>Students can study coaching, motivation, sports psychology and stress management in this domain.</p>
                                        <!-- <ul class="menu">
                                            <li><i class="fas fa-check"></i>  Computer Science</li>
                                            <li><i class="fas fa-check"></i> Chemistry</li>
                                            <li><i class="fas fa-check"></i> Biotechnology</li>
                                        </ul> -->
                                        <!-- <a href="#" class="btn btn-dark btn-animated">Apply Now</a> -->
                                    </div>
                                </div>
                            </div>

                        </div><!-- Row /-->
                    </div><!-- Container -->
                </div>
            </div>

            <!-- add new  -->
            <div class="about-us module">
                <div class="section-title">
                    <h2>Getting a <span>Canadian Visa</span></h2>
                    <p>The Canadian High Commission conducts a smooth, transparent and standardized application procedure for overseas students. They also offer several opportunities such as the Student Direct Stream (SDS) for a fast-tracked processing of student visa. <br/>Here are the steps to follow when applying for a Canadian student visa </p>
                </div>
                <div class="container">
                <div class="row">
                <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                <div class="about-img">
                <img src="assets/images/help/about-img.jpg" alt="About">
                </div>
                </div>
                <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                <div class="about-text">
               
                <ul class="menu">
                    <li><i class="fas fa-check"></i>   Get an unconditional acceptance letter from an educational institution in Canada.</li>
                    <li><i class="fas fa-check"></i> Pay tuition fees for the first year as requested by the university or college. Obtain a letter demonstrating the purchase of a guaranteed  investment certificate from a Canadian financial institution to cover the living expenses for the first year.</li>

                    <li><i class="fas fa-check"></i>  Pass the medical examination by one of the panel physicians in Dubai.</li>
                    <li><i class="fas fa-check"></i> Submitting the requisite documents to your nearest Canadian Visa Application Center (CVAC) operated by VFS Global Services Pvt. Ltd.</li>
                </ul>
                </div>
                </div>
                </div>
                </div>
                </div></div>
            </div>
            <!-- end of new -->

            <!-- cost -->
            <div class="our-courses grey-bg grey-bg-color module">
                <div class="section-title">
                    <h2>Cost of <span> Education </span></h2>
                    <p>The cost of education in Canada will vary according to the university you choose and the course you want to pursue. Tuition fees for overseas students are less as compared to the fees paid by students of other nationalities in Canada. Generally, for a diploma or certificate program, the fees are approximately 11000 to 15000 CAD per year. Similarly, for a Bachelor’s degree, the tuition fees lie in the range of 11000 to 16000 CAD per year. And for a Masters program, you can expect to spend between 16000 to 25000 CAD per year. </p>
                </div>
            </div>

            <div class="section-title">
                <h2>Cost of <span> Living in Canada </span></h2>
                <p>Living in Canada is also not as expensive as it could be in other study destinations. But again, this is dependent on the university you opt for and the city you live in. There are different types of on and off-campus accommodations that students can explore when studying in Canada. The most popular are. </p>
            </div>

            <div class="container">
                <div class="campus-visit-wrapper">
                    <div class="campus-image-col">
                        <div class="campus-image slick-initialized slick-slider">
                            <div class="slick-list draggable">
                                <div class="slick-track" style="opacity: 1; width: 1545px; transform: translate3d(0px, 0px, 0px);">
                                    <div class="single-campus slick-slide slick-current slick-active" data-slick-index="0" aria-hidden="false" tabindex="0" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="canada">
                                    </div>
                                    <!--<div class="single-campus slick-slide" data-slick-index="1" aria-hidden="true" tabindex="-1" style="width: 515px;">
                                        <img src="assets/images/aus.jpg" alt="">
                                    </div> -->
                                </div>
                            </div>
                      </div>
                    </div>
                    <div class="campus-content-col">
                        <div class="campus-content">
                            <!-- <h2 class="campus-title">Why Study in Australia?</h2> -->                            
                            <ul class="menu">
                                <li><i class="fas fa-check"></i><strong>Hostels / Dormitories –</strong>  Many institutions offer residence/accommodation on the campus. Some campuses have shared facilities, such as shared rooms or dormitories divided by gender. In some cases,  a mess facility or meal plan is included in the cost of accommodation. Hostels usually cost between 300 to 500 CAD per month. per month.</li>
                                <li><i class="fas fa-check"></i><strong>Rental Housing – Low-cost</strong> – Rental housing is also a popular option for students in Canada. Many universities offer an off-campus housing service that provides a list of affordable houses near the campus. The expenditure of living in rented accommodation is between300 to 500 CAD per month for shared apartments and between 400 to 1200 CAD per month for a private apartment.</li>
                                <li><i class="fas fa-check"></i> <strong>Homestay</strong> – Homestays are arranged by institutions who match families with students and the students are hosted by the families in their home while they attend school. Generally, you may spend anything between 500 to 800 CAD per month for a homestay.</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

            <div class="section-title">
                <h2>Health <span> Insurance </span></h2>
                <p>In Canada, all students must have medical insurance. The coverage you get under your medical insurance depends on the Canadian province
you live in. The coverage also varies according to the length of your stay.</p>
            </div>
        </div>
            <!-- end of cost -->
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
        </div>
        <?php include('inc/js.php'); ?>
    </body>
</html>    