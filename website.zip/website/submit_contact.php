<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") 
{
        // Get the form fields and remove whitespace.
        $name = strip_tags(trim($_POST["name"]));
                $name = str_replace(array("\r","\n"),array(" "," "),$name);
        $email = filter_var(trim($_POST["email"]), FILTER_SANITIZE_EMAIL);
        $phone = trim($_POST["phone"]);
        $country = trim($_POST["country"]);
        $message = trim($_POST["message"]);

        // Check that data was sent to the mailer.
        if ( empty($name) OR empty($country) OR empty($phone) OR empty($message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // Set a 400 (bad request) response code and exit.
            http_response_code(400);
            echo "Please complete the form and try again.";
            exit;
        }

        // Set the recipient email address.
        // FIXME: Update this to your desired email address.
        $recipient = "oecdubai@outlook.com";
        

        // Set the email subject.
        $subject = "OEC Inquiry Form";

        // Build the email content.
        $email_content .= "Hello OEC Team,\n\n$name contacts you from your OEC Website\n\nThe Candidate Details are mentioned below\nName : $name\n";
        $email_content .= "Email: $email\n";
        $email_content .= "Phone: $phone\n";
        $email_content .= "Country: $country\n";
        $email_content .= "Message: $message\n\n Regards,\nOVERSEAS EDUCATION CENTRE\n2nd Floor,Prestige Building,\nRace Course Circle,\nbeside Axis Bank,\nVadodara, Gujarat 390007";

        // Build the email headers.
        $email_headers = "From: $name <$email>";
        $email_headers .= 'Bcc: mr.jasmin.shukal@gmail.com' . "\r\n";

        // Send the email.
        if (mail($recipient, $subject, $email_content, $email_headers)) {
            // Set a 200 (okay) response code.
            $html = get_hrml('https://www.oecindia.com/',$name);
            $headers  = 'MIME-Version: 1.0' . "\r\n";
            $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
            $headers .= "From: admin <admin@oecdubai.com>";
            
            if(mail($email, 'Thank you for the Enquiry.', $html, $headers))
            {
            http_response_code(200);
            $array=array('msg'=>"send",'status'=>1,'data'=>"231.");
            echo json_encode($array);
            }
            // header('location:contactus.php');
        } else {
            // Set a 500 (internal server error) response code.
            http_response_code(500);
            $array=array('msg'=>"send",'status'=>1,'data'=>"231.");
            echo json_encode($array);
            echo "Oops! Something went wrong and we couldn't send your message.";
        }

    } else {
        // Not a POST request, set a 403 (forbidden) response code.
        http_response_code(403);
        $html = get_hrml('https://www.oecdubai.com/','oecdubai','jess_bhudev');
        echo $html;;
    }
    
    
    function get_hrml($url,$name)
    {
        $html;
        $html= <<<HTML

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta name="viewport" content="width=device-width; initial-scale=1.0; maximum-scale=1.0;" />
<style type="text/css">
	    body{width: 100%; background-color: #0d0b0c; margin:0; padding:0; -webkit-font-smoothing: antialiased;mso-margin-top-alt:0px; mso-margin-bottom-alt:0px; mso-padding-alt: 0px 0px 0px 0px;}
        p,h1,h2,h3,h4{margin-top:0;margin-bottom:0;padding-top:0;padding-bottom:0;}
        span.preheader{display: none; font-size: 1px;}
        html{width: 100%;}
        table{font-size: 12px;border: 0;}
		.menu-space{padding-right:25px;}
		a,a:hover { text-decoration:none; color:#FFF;}
@media only screen and (max-width:640px)
{
	body {width:auto!important;}
	table [class=main] {width:440px !important;}
	table [class=two-left] {width:420px !important; margin:0px auto;}
	table [class=full] {width:100% !important; margin:0px auto;}
	table [class=two-left-inner] {width:400px !important; margin:0px auto;}
	table [class=menu-icon] { display:none;}
	}
@media only screen and (max-width:479px)
{
	body {width:auto!important;}
	table [class=main]  {width:310px !important;}
	table [class=two-left] {width:300px !important; margin:0px auto;}
	table [class=full] {width:100% !important; margin:0px auto;}
	table [class=two-left-inner] {width:280px !important; margin:0px auto;}
	table [class=menu-icon] { display:none;}
}

</style>

</head>

<body yahoo="fix" leftmargin="0" topmargin="0" marginwidth="0" marginheight="0">

<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#0d0b0c" data-bgcolor="BodyBg" data-module="09-bignote" data-thumb="http://www.freetemplates.bz/design/thumbnails/bignote/09-1.png">
  <tr>
    <td align="center" valign="top"><table width="600" border="0" align="center" cellpadding="0" cellspacing="0" class="main">
  <tr>
    <td height="100" align="center" valign="top" style="font-size:100px; line-height:100px;">&nbsp;</td>
  </tr>
  <tr>
    <td height="330" align="center" valign="top" style="background:#322466; -moz-border-radius: 4px 4px 0px 0px; border-radius: 4px 4px 0px 0px;" data-bgcolor="theme-bg"><table width="510" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
      <tr>
        <td height="40" align="left" valign="top" style="font-size:40px; line-height:40px;">&nbsp;</td>
      </tr>
      <tr>
        <td align="left" valign="top">
        
        <table width="105" border="0" align="left" cellpadding="0" cellspacing="0" class="full">
          <tr>
            <td align="center" valign="top"><a href="#"><img editable="true" mc:edit="bm9-01" src="https://www.oecindia.com/assets/images/finalpic.png" height="50" style="background: aliceblue;" alt="" /></a></td>
          </tr>
        </table>
        
        <table border="0" align="right" cellpadding="0" cellspacing="0" class="full">
  <tr>
    <td height="8" align="center" valign="top" style="font-size:8px; line-height:8px;">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#FFF; font-weight:bold;" mc:edit="bm9-02"><multiline>Hello! $name </multiline></td>
  </tr>
            </table>
        
        </td>
      </tr>
      <tr>
        <td height="50" align="left" valign="top" style="font-size:50px; line-height:50px;">&nbsp;</td>
      </tr>
      <tr>
        <td align="left" valign="top"><table width="80%" border="0" align="center" cellpadding="0" cellspacing="0" class="two-left">
            
            <tr>
                <td align="center" valign="top"><table width="64" border="0" cellspacing="0" cellpadding="0">
                  <tr>
                    <td align="center" valign="top"><img editable="true" mc:edit="bm9-03" src="https://quindara.in/mail_icon.png" width="64" height="64" alt="" /></td>
                  </tr>
                  <tr>
                    <td align="center" valign="top">&nbsp;</td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td align="center" valign="top" style="font-family:Arial, Helvetica, sans-serif; font-size:18px; color:#FFF; font-weight:normal; line-height:32px;" mc:edit="bm9-04"><multiline>Thanks For Your</multiline></td>
              </tr>
              <tr>
                <td align="center" valign="top" style="font-family:'Open Sans', sans-serif, Verdana; font-size:44px; color:#FFF; font-weight:bold; text-transform:uppercase;" mc:edit="bm9-05"><multiline>enquiry</multiline></td>
              </tr>
                <tr>
                <td height="10" align="center" valign="top" style="font-size:10px; line-height:10px;">&nbsp;</td>
              </tr>
              <tr>
                <td align="center" valign="top" style="font-family:'Open Sans', sans-serif, Verdana; font-size:15px; color:#FFF; font-weight:normal; line-height:24px; padding:0px 25px;" mc:edit="bm9-06"><multiline>We thank you for the enquiry. Some one from the team shall get in touch with you soon.</multiline></td>
              </tr>
              <tr>
                <td height="40" align="center" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td align="center" valign="top"><table width="320" border="0" align="center" cellpadding="0" cellspacing="0">
                  <tr>
                    <td height="50" align="center" valign="middle" bgcolor="#d8262e" style="font-family:Arial, Helvetica, sans-serif; font-size:16px; color:#FFF; font-weight:bold; -moz-border-radius: 50px; border-radius: 50px;" data-bgcolor="button-bg" mc:edit="bm9-07"><multiline><a href="$url" style="text-decoration:none; color:#FFF;"> OVERSEAS EDUCATION CENTRE </a></multiline></td>
                  </tr>
                </table></td>
              </tr>
              <tr>
                <td height="80" align="center" valign="top">&nbsp;</td>
              </tr>
            </table></td>
      </tr>
      </table></td>
  </tr>

  <tr>
    <td height="100" align="center" valign="top" style="font-size:100px; line-height:100px;">&nbsp;</td>
  </tr>
    </table>
</td>
  </tr>
</table>
</body>
</html>
HTML;
        return $html;
    }