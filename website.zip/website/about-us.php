<!doctype html>
<html lang="en">
<head><?php include('inc/meta_css.php'); ?></head>
<body>
    <div class="main-container about-us-page">
        <?php include('inc/header.php'); ?>
        <div class="title-section dark-bg module grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-padding-y">
                        <div class="title-section-text">
                            <h1>About Us</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="why-chose-us module">
            <div class="section-title">
                <h2>Who <span> We are</span></h2>
                <p>Overseas Education Center (OEC) was established with the core objective of helping students in
                    achieving their dreams of overseas education. Since conception in 2003, we have worked to develop
                    our expertise for overseas education and visa formalities. Over the years we have also created a
                    robust network with leading institutions worldwide that gives us the ability to provide better
                    education services to our students.</p>
            </div>
            <div class="about-us module">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-img">
                                <img src="assets/images/help/about-img.jpg" alt="About">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-6 col-lg-6 col-padding-y">
                            <div class="about-text">
                                <p>Our team is highly qualified and has a wealth of experience. In the last 15 years,
                                    OEC
                                    has recruited over 10,000 students to universities, colleges and institutions around
                                    the
                                    world: including the United Kingdom, Australia, USA, Canada and New Zealand. Our
                                    team is trained to give expert advice and guide students to choose the right course,
                                    university and destination according to their needs and abilities.</p>
                                <p>OEC was founded by Mr Jagat Patel, a graduate of Webster University from the United
                                    Kingdom. He is a well-known personality in the education industry in the South Asia
                                    region. Before he founded OEC, Mr Jagat Patel spent many years working with the
                                    University of Bedfordshire Regional Representatives Office (South-West India). He
                                    has an unparalleled knowledge of overseas education and the challenges involved.
                                <p>Apart from his work at OEC, Mr Jagat Patel is also involved in managing the India
                                    office for Bath Spa University as the Regional Director. A sister concern of OEC
                                    manages the Regional setup for leading Australian and UK universities.</p>
                                <!--  <a href="about-us.html" class="btn btn-primary btn-padding btn-animated">About Us</a>
                                <a href="about-us.html" class="btn btn-secondary btn-padding btn-dark-animated">Why Chose Us</a> -->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!-- <div class="call-to-action">
            	<img class="call-to-action-img" src="assets/images/help/background-effect-2.jpg" alt="">
                <div class="container">
                    <div class="row no-gutters">
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/book-icon.png" alt="book Icon">
                                <h3><a href="#">Select A Course!</a></h3>
                                <p>There are many variations of passages videntur parum clari, fiant sollemnes in futurum.</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/light-bulb.png" alt="Light Bulb">
                                <h3><a href="#">Attend a Seminar</a></h3>
                                <p>There are many variations of passages videntur parum clari, fiant sollemnes in futurum.</p>
                            </div>
                        </div>
                        
                        <div class="col-sm-12 col-md-6 col-lg-4">
                            <div class="call-box">
                                <img src="assets/images/help/icons/hat-college.png" alt="Hat College">
                                <h3><a href="#">Build your Future</a></h3>
                                <p>There are many variations of passages videntur parum clari, fiant sollemnes in futurum.</p>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div> -->
            <div class="why-chose-us module">
                <div class="section-title">
                    <h2>Why Choose <span>OEC</span></h2>
                    <p>At OEC, we believe that education plays an important role in shaping our lives. A good education
                        can help a person build a better life for themselves and their loved ones. This is why at OEC we
                        have dedicated our efforts to help students to achieve admission into their dream universities
                        to get the best education they need to fulfil their dreams.</p>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-6 col-padding-y">
                            <div class="faq-wrap">
                                <div class="accordion" id="accordionExample">
                                    <div class="card animated" data-animation="slideInUp">
                                        <div class="card-header" id="headingOne">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link" type="button" data-toggle="collapse"
                                                    data-target="#collapseOne" aria-expanded="false"
                                                    aria-controls="collapseOne">Our Experience</button>
                                            </h2>
                                        </div>
                                        <div id="collapseOne" class="collapse show" aria-labelledby="headingOne"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>The OEC team has been in the education industry for 15 years. We
                                                    started in 2004 and
                                                    since then we have placed more than 10,000 students at foreign
                                                    universities across the
                                                    world. With OEC’s guidance students have been accepted in
                                                    universities in the United
                                                    Kingdom, Australia, USA, Canada and New Zealand.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp">
                                        <div class="card-header" id="headingTwo">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseTwo"
                                                    aria-expanded="false" aria-controls="collapseTwo">Our Team</button>
                                            </h2>
                                        </div>
                                        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>We take pride in our admissions team and counsellors who have been
                                                    trained to provide students with the right guidance for overseas
                                                    education. With thorough research, good etiquette and
                                                    an ability to understand a student’s aspirations; our counsellors
                                                    help you choose the
                                                    right course and the best university in the country most suitable.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp">
                                        <div class="card-header" id="headingThree">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseThree"
                                                    aria-expanded="true" aria-controls="collapseThree">Our
                                                    Staff</button>
                                            </h2>
                                        </div>
                                        <div id="collapseThree" class="collapse" aria-labelledby="headingThree"
                                            data-parent="#accordionExample">
                                            <div class="card-body">
                                                <p>We believe in a growth mindset, making sure that our admissions
                                                    teams,
                                                    counsellors and staff are well-trained and knowledgeable. Many of
                                                    our senior staff
                                                    members have trained abroad with our partner universities, with the
                                                    aim of providing
                                                    comprehensive guidance to students.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp">
                                        <div class="card-header" id="headingFour">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseFour"
                                                    aria-expanded="false" aria-controls="collapseFour">Our Aim </button>
                                            </h2>
                                        </div>
                                        <div id="collapseFour" class="collapse" aria-labelledby="headingFour"
                                            data-parent="#accordionExample">
                                            <div class="card-body">Our goal is to provide free counselling, free
                                                admissions (wherever possible) and free visa application assistance. We
                                                aim to help you achieve your dream of studying abroad and choosing the
                                                right career path.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card animated" data-animation="slideInUp">
                                        <div class="card-header" id="headingFive">
                                            <h2 class="mb-0">
                                                <button class="btn btn-link collapsed" type="button"
                                                    data-toggle="collapse" data-target="#collapseFive"
                                                    aria-expanded="false" aria-controls="collapseFive">Ethical Practices
                                                    & Transparency </button>
                                            </h2>
                                        </div>
                                        <div id="collapseFive" class="collapse" aria-labelledby="headingFive"
                                            data-parent="#accordionExample">
                                            <div class="card-body">Our goal is to provide clear and accurate
                                                information to students and universities. We provide free consultation
                                                and guidance to
                                                students; helping them choose the right university and courses.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class=" col-sm-12 col-md-12 col-lg-6 col-padding-y">
                            <div class="video-preview-one">
                                <!-- <a class="video-preview" href="../../../www.youtube.com/watch1ed0.php?v=lVXPCXRjXhg"> -->
                                <!--<div class="video-icon">
                                        <div class="play-icon">
                                            <i class="fas fa-play"></i>
                                        </div>
                                    </div> -->
                                <img src="assets/images/help/video-one.jpg" alt="video">
                                <!-- </a> -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('inc/request.php'); ?>
            <?php include('inc/footer.php'); ?>
            <?php include('inc/js.php'); ?>
</body>