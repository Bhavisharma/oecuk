<!doctype html>

<html lang="en">

    <head><?php include('inc/meta_css.php'); ?></head>
    <body>

        <div class="main-container faqs-page">

            <?php include('inc/header.php'); ?>

            <div class="title-section dark-bg grey-bg">

                <div class="container">

                    <div class="row">

                        <div class="col-sm-12 col-padding-y">

                            <div class="title-section-text">

                                <h1>Accommodation</h1>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

            <div class="appointment grey-bg grey-bg-color">

                <div class="container">

                    <div class="row">

                        

                        <div class="col-sm-12 col-md-8 col-lg-8 offset-lg-2 offset-md-2 col-padding-y">

                            <div class="section-title">

                           <!--  <h1>Admission</h1> -->

                            <h2>Our<span> Process</span></h2>

                            </div>



                            <p>You have a wide range of options to choose from when you are studying Abroad. You can stay in University/College On Campus Accommodation, Private rental properties, Bed-sits, Home-stays or Lodgings. It is up to you, what you prefer and your budget.

                            </p>



                            <h3>Please do visit the university / college accommodation websites for further information.</h3><p>Many Universities / Colleges have halls of residence or houses and flats that are designed for students and are located on campus or close to the university / college. You may live in a room either by yourself or share with another student. Some accommodation options have shared bathrooms. Meals may be included in the rent, or there will be shared kitchens if you prefer to self cater. When you choose your university / college check the website for what kind of accommodation they provide and the cost of the accommodation.</p>



                            <h3>Houses and Flats</h3><p>Sharing a house or flat with others is a great way of reducing your costs and getting to know new people. You can find out about shared accommodation in local papers, Shop windows, notice boards and through your university / college accommodation service.</p>



                            <h3>Home stays</h3><p>A home stay is when you stay in the home of a host family and it serves as a cultural learning experience as well as an excellent option if you prefer to stay in a family environment. You will have your own bedroom and meals are often had with the family. You will have to interact in English everyday, so it is a great opportunity to improve your English language skills. You will also learn a great deal about life and culture of that Country. Home stays can be organized privately or through your university / college.</p>

                        </div>

                    

                    </div>

                </div>

            </div>

            <?php include('inc/request.php'); ?>

            <?php include('inc/footer.php'); ?>

        </div>

        <?php include('inc/js.php'); ?>

    </body>

</html>    