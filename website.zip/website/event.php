<?php
include('db.php');
include('function.php');

?>
<!doctype html>
<html lang="en">
<head>
    
    <?php include('inc/meta_css.php'); ?>

    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script>
$(document).ready(function(){
  $("button").click(function(){
    $("section").toggle(1000);
  });
});
</script>
</head>
<body>
    <div class="main-container about-us-page">
        <?php include('inc/header.php'); ?>
        <div class="title-section dark-bg module grey-bg">
            <div class="container">
                <div class="row">
                    <div class="col-sm-12 col-padding-y">
                        <div class="title-section-text">
                            <h1>Event</h1>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <link rel="stylesheet" href="oecdubai.com\assets\css\style.css">
        <link rel="stylesheet" href="oecdubai.com\assets\css\material-design-iconic-font.min">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.12.1/css/all.min.css"
            integrity="sha256-mmgLkCYLUQbXn0B1SRqzHar6dCnv9oZFPEC1g1cwlkk=" crossorigin="anonymous" />
        <div class="row">
            <div class="col-12 text-center">
                <div class="section-title mb-4 pb-2">
                    <h4 class="title mb-4">Event &amp; News</h4>
                    <p class="text-muted para-desc mx-auto mb-0">Build responsive, mobile-first projects on the web with
                        the world's most popular front-end component library.</p>
                </div>
            </div>
            <!--end col-->
        </div>
        <!--end row-->
        
        <div class="event">
            <div class="container">
                   <?php
                   include('event-ui.php');
                   ?>
            </div>
        </div>
        <?php include('inc/request.php'); ?>
        <?php include('inc/footer.php'); ?>
        <?php include('inc/js.php'); ?>
</body>
</html>