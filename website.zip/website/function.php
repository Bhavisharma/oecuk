<?php

include('db.php');

function get_cat_list($type)
{
    echo $type;
    return 1;
}

function get_from_table($table_name)
{
    global $conn;
    $sql = "SELECT * FROM ".$table_name;
    return $conn->query($sql);
}

function get_list($table)
{
    $array=array();
    $result=get_from_table($table);
    if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) 
        {
            array_push($array,$row);
        }
    }
    return $array;
}

function get_row_detail($table,$where)
{
    global $conn;

    $sql = "SELECT * FROM ".$table." where ".$where;
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    return $row;
}

function get_list_with_whare($table,$where)
{
    $array=array();
    global $conn;
    $sql = "SELECT * FROM ".$table." where ".$where;
    
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {

        while($row = $result->fetch_assoc()) 
        {
            array_push($array,$row);
        }
    }
    return $array;
}



?>