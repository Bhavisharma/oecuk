<!doctype html>

<html lang="en">

<?php
    $mysqli = new mysqli("localhost","oecinutd_crmuser","FphuaS#n=-KU","oecinutd_crm");
    if ($mysqli -> connect_errno) {
      echo "Failed to connect to MySQL: " . $mysqli -> connect_error;
      exit();
    }
    $sql="SELECT * FROM `counter` WHERE `page`='faqs' AND `date`='".date('Y-m-d')."'";
    $result=$mysqli->query($sql);
    $row=$result->fetch_array(MYSQLI_ASSOC);
    if(count($row)>0)
    {
        $update = "UPDATE `counter` SET `count`=".($row['count']+1)." WHERE `page`='faqs'";
        $mysqli->query($update);
    }
    else
    {
        $insert = "INSERT INTO `counter` (`count`,`page`,`date`) VALUES (1,'faqs','".date('Y-m-d')."')";
        $mysqli->query($insert);
    }
?>
<head>

    <!-- important for compatibility charset -->

    <meta charset="utf-8" />

    <meta http-equiv="x-ua-compatible" content="ie=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0" />

    

    <title>Education Buddy Website Template</title>

    

    <meta name="author" content="Webful Creations">

    <meta name="keywords" content="">

    <meta name="description" content="">

    

    <!-- FavIcon for Website /-->

    <link rel="shortcut icon" type="image/x-icon" href="assets/images/favicon.png">

    

    <!-- important for responsiveness remove to make your site non responsive. -->

    <meta name="viewport" content="width=device-width, initial-scale=1">

    

    <!-- Theme Styles CSS File -->

    <link rel="stylesheet" type="text/css" href="style.css" media="all" />

</head>



<body>

    

    <div class="main-container faqs-page">

    	

    	<div class="top-bar">

        	<div class="container">

            	<div class="row">

                	

                    <div class="col-sm-12 col-md-12 col-lg-8">

                    	<div class="left-side">

                        	<ul class="menu">

                            	<li><i class="fas fa-map-marker-alt"></i> 6th Avenue, Field NY, 54000 USA</li>

                                <li><a href="index-2.html"> <i class="fas fa-envelope"></i>broxton@support.com</a></li>

                            </ul>

                        </div><!-- Left Side /-->

                    </div><!-- Columns /-->

                    

                    <div class="col-sm-12 col-md-12 col-lg-4 text-right">

                    	<div class="right-side">

                            <ul class="menu">

                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>

                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>

                                <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>

                                <li><a href="#"><i class="fas fa-user"></i>Sign Up</a></li>

                                <li><a href="#"><i class="fas fa-sign-in-alt"></i>Login</a></li>

                            </ul>

                        </div>

                    </div><!-- Columns /-->

                    

                </div><!-- Row /-->

            </div><!-- Container /-->

        </div>

        <!-- Top Bar /-->

        

        <div class="header">

        	<div class="container">

            	<div class="row">

                	

                    <div class=" col-sm-12 col-lg-4 col-md-4">

                    	<div class="logo">

                        	<a href="index-2.html">

                            	<img src="assets/images/logo.png" alt="Logo">

                            </a>

                        </div>

                    </div><!-- columns /-->

                    

                    <div class=" col-sm-12 col-lg-8 col-md-8">

                        <div class="info-container">

                        	

                            <div class="icon-box">

                                <div class="icon-side">

                                	<img src="assets/images/help/icons/tablet.png" alt="icon">

                                </div><!-- Icon Side /-->

                                <div class="info-side">

                                    <p><strong>0123 - 456 - 7890</strong><br>

                                    Book an Appointment

                                    </p>

                                </div><!-- Info Side /-->

                            </div>

                        	

                            <div class="icon-box">

                                <div class="icon-side">

                                	<img src="assets/images/help/icons/pointer.png" alt="icon">

                                </div><!-- Icon Side /-->

                                <div class="info-side">

                                    <p><strong>4th Avenue Bloom</strong><br>

                                    ST 4th, Sanfrans, FL, USA

                                    </p>

                                </div><!-- Info Side /-->

                            </div>

                            

                        </div>

                        <div class="clearfix"></div>

                    </div><!-- columns /-->

                    

                </div><!-- row /-->

            </div><!-- Container /-->

        </div>

        <!-- header /-->

		

        <div class="navigation">

            <div class="container">

                <div class="row">

                    

                    <div class="col-sm-12 col-md-12 col-lg-12">

                        <nav class="navbar navbar-expand-lg navbar-light">

                            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

                                <span class="icon-bar"></span>

                                <span class="icon-bar"></span>

                                <span class="icon-bar"></span>

                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                                <ul class="navbar-nav">

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="index-2.html" >Home</a>

                                        <div class="dropdown-menu">

                                            <a class="dropdown-item" href="index-2.html">Home</a>

                                            <a class="dropdown-item" href="header-v2.html">Home Version 2</a>

                                            <a class="dropdown-item" href="sticky-navigation.html">Sticky navigation</a>

                                            <a class="dropdown-item" href="animation-page.html">Aanimation Page</a>

                                            <a class="dropdown-item" href="boxed-layout.html">Boxed Layout</a>

                                        </div>

                                    </li>

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="about-us.html">About Us</a>

                                        <div class="dropdown-menu">

                                            <a class="dropdown-item" href="about-us.html">About Us</a>

                                            <a class="dropdown-item" href="portfolio.html">Portfolio</a>

                                            <a class="dropdown-item" href="all-events.html">All Events</a>

                                            <a class="dropdown-item" href="testimonials.html">Testimonials</a>

                                            <a class="dropdown-item" href="faqs.html">FAQ's</a>

                                            <a class="dropdown-item" href="pricing-table.html">Pricing Table</a>

                                            <a class="dropdown-item" href="locations.html">Locations</a>

                                            <a class="dropdown-item" href="404-error-page.html">404 Error Page</a>

                                        </div>

                                    </li>

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="services.html">Services</a>

                                        <div class="dropdown-menu">

                                            <a class="dropdown-item" href="services.html">Services</a>

                                            <a class="dropdown-item" href="single-services.html">Single Services</a>

                                        </div>

                                    </li>

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="our-staff.html">Our Staff</a>

                                        <div class="dropdown-menu">

                                            <a class="dropdown-item" href="our-staff.html">Our Staff</a>

                                            <a class="dropdown-item" href="single-teacher.html">Single Teacher</a>

                                        </div>

                                    </li>

                                    <li class="nav-item">

                                        <a class="nav-link" href="appointment.html">Appointment</a>

                                    </li>

                                    <li class="nav-item dropdown">

                                        <a class="nav-link dropdown-toggle" href="blog.html">Blog</a>

                                        <div class="dropdown-menu">

                                            <a class="dropdown-item" href="blog.html">Blog</a>

                                            <a class="dropdown-item" href="single-post-page.html">Single Post Page</a>

                                        </div>

                                    </li>

                                    <li class="nav-item">

                                        <a class="nav-link" href="contact-us.html">Contact us</a>

                                    </li>

                                </ul>

                            </div>

                        </nav><!-- Navbar /-->

                    </div><!-- columns/-->

                    

                </div><!-- Row /-->

            </div><!-- Container /-->

        </div>

        <!-- Navigation /-->

        

        <div class="title-section dark-bg module grey-bg">

            <div class="container">

                <div class="row">

                    

                    <div class="col-sm-12 col-padding-y">

                        <div class="title-section-text">

                        	<h2>faqs</h2>

                        	<h1>Contact Your Consultant</h1>

                        </div>

                    </div><!-- Top Columns /-->

                    

                </div>

            </div><!-- Grid Container /-->

        </div>

        <!-- Title Section /-->

                

        <div class="why-chose-us grey-bg">

            <div class="section-title">

            	<h2>Why Chose <span>Edu Buddy</span></h2>

                <p>We have some great teachers and trainers in our staff who have professional experience along high education. Which gives you peace of mind.</p>

            </div><!-- Section Title /-->

            <div class="container">

            	<div class="row">

                	

                    <div class="col-sm-12 col-md-12 col-lg-12 col-padding-y">

                    	<div class="faq-wrap">

                        	<p>We always try to achieve some success in our life. Education is very important part in life of every individual which help us to groom our skills and find new ways to enhance the benefits and groom ourselves.</p>

                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore. Things needs to be done.</p>

                            <div class="accordion" id="accordionExample">

                                <div class="card animated" data-animation="slideInUp" data-animation-delay="400">

                                    <div class="card-header" id="headingOne">

                                        <h2 class="mb-0">

                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">Lorem ipsum dolor sit amet consectetur</button>

                                        </h2>

                                    </div>

                                    <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">

                                        <div class="card-body">

                                            Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur authority in sendo. With some awesome educational campuses.

                                        </div>

                                    </div>

                                </div><!-- Card /-->

                                <div class="card animated" data-animation="slideInUp" data-animation-delay="500">

                                    <div class="card-header" id="headingTwo">

                                        <h2 class="mb-0">

                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">Lorem ipsum dolor sit amet consectetur</button>

                                        </h2>

                                    </div>

                                    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">

                                        <div class="card-body">

                                            Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur authority in sendo. With some awesome educational campuses.

                                        </div>

                                    </div>

                                </div><!-- Card /-->

                                <div class="card animated" data-animation="slideInUp" data-animation-delay="700">

                                    <div class="card-header" id="headingThree">

                                        <h2 class="mb-0">

                                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">How can you become a professional php developer?</button>

                                        </h2>

                                    </div>

                                    <div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">

                                        <div class="card-body">

                                            Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur authority in sendo. With some awesome educational campuses.

                                        </div>

                                    </div>

                                </div><!-- Card /-->

                                <div class="card animated" data-animation="slideInUp" data-animation-delay="700">

                                    <div class="card-header" id="headingFour">

                                        <h2 class="mb-0">

                                            <button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="false" aria-controls="collapseFour">I have broken power supply can it be repaired</button>

                                        </h2>

                                    </div>

                                    <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordionExample">

                                        <div class="card-body">

                                            Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur authority in sendo. With some awesome educational campuses.

                                        </div>

                                    </div>

                                </div><!-- Card /-->

                            </div><!-- Accordion /-->

                        </div>

                    </div><!-- Columns /-->

                    

                </div><!-- Row /-->

            </div><!-- Container -->

        </div>

        <!-- Why Chose Us /-->

        

        <div class="request-appointment">

        	<div class="container">

            	<div class="row">

                	

                    <div class="col-sm-12 col-md-8 col-lg-9 col-padding-y">

                    	<div class="appointment-text">

                        	<h2>Get A Free Business Consultation!</h2>

                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing  elit, sed do eiusmod.</p>

                        </div><!-- Appointment Text /-->

                    </div><!-- Columns /-->

                    

                    <div class="col-sm-12 col-md-4 col-lg-3 col-padding-y">

                    	<div class="appointment-btn">

                        	<a href="appointment.html" class="btn btn-secondary btn-padding btn-dark-animated">Get Appointment</a>

                        </div><!-- Appointment Btn /-->

                    </div><!-- Columns /-->

                    

                </div><!-- Row /-->

            </div><!-- Container /-->

        </div>

        <!-- Request Appointment /-->

        

        <div class="footer dark-bg grey-bg">

        	

        	<div class="footer-top">

            	<div class="container">

                	<div class="row">

                    	

                    	<div class="col-sm-12 col-md-12 col-lg-12">

                            <div class="footer-top-text footer-border">

                            	<h2>Get In Touch</h2>

                                <p>Write us an email!</p>

                                <div class="row">

                                	

                                    <div class="col-sm-12 col-md-8 col-lg-8">

                                        <div class="form-group">

                                        	<input type="email" class="form-control" id="exampleInputEmail2" placeholder="E-mail address">

                                        </div>

                                    </div>

                                    

                                    <div class="col-sm-12 col-md-4 col-lg-4">

                                        <div class="footer-top-btn">

                                        	<button type="submit" class="btn btn-light">Get Started</button>

                                        </div>

                                    </div>

                                    

                                </div>

                            </div>

                        </div><!-- columns /-->

                    	

                    </div><!-- Row /-->

                </div><!-- Container /-->

            </div><!-- Footer Top /-->

        	

            <div class="footer-bottom">

            	<div class="container">

                	<div class="row">

                    	

                        <div class="col-lg-5 col-md-7 col-sm-12">

                            <div class="footer-box Courses">

                            	<ul class="links  col-padding-y">

                                    <li><h6>Popular Courses</h6></li>

                                    <li><a href="#">Web Application Dev</a></li>

                                    <li><a href="#">Graphic Designing</a></li>

                                    <li><a href="#">Mobile App Development</a></li>

                                    <li><a href="#">NET with ASP Course</a></li>

                                    <li><a href="#">Project Management</a></li>

                                    <li><a href="#">English Language Course</a></li>

                                </ul>

                                <ul class="links  col-padding-y">

                                    <li><h6>Quick Menu</h6></li>

                                    <li><a href="#">About us</a></li>

                                    <li><a href="#">Our Faculty</a></li>

                                    <li><a href="#">Featured Coursess</a></li>

                                    <li><a href="#">Campsu Life</a></li>

                                    <li><a href="#">Testimonials</a></li>

                                    <li><a href="#">Our News</a></li>

                                </ul>

                            </div><!-- Footer Box /-->

                        </div><!-- Columns /-->

                        

                        <div class="col-lg-3 col-md-5 col-sm-12 col-padding-y">

                            <div class="footer-box Privacy">

                            	<ul class="links">

                                    <li><h6>Privacy & Links</h6></li>

                                    <li><a href="#">Q & A</a></li>

                                    <li><a href="#">Privacy Politcy</a></li>

                                    <li><a href="#">Terms & Condition</a></li>

                                    <li><a href="#">Admission </a></li>

                                </ul>

                            </div><!-- Footer Box /-->

                        </div><!-- Columns /-->

                        

                        <div class="col-lg-4 col-md-6 col-sm-12 col-padding-y">

                            <div class="footer-box follow-us">

                            	<h6>Locate Us</h6>

                                <div class="social-icons">

                                    <ul class="menu">

                                        <li><a href="#"><i class="fab fa-twitter"></i></a></li>

                                        <li><a href="#"><i class="fab fa-facebook"></i></a></li>

                                        <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>

                                        <li><a href="#"><i class="fab fa-dribbble"></i></a></li>

                                        <li><a href="#"><i class="fab fa-behance"></i></a></li>

                                        

                                    </ul>

                                </div>

                            	<div class="subscribe-us">

                                	<h6>Subscribe Us</h6>

                                    <ul class="menu">

                                        <li>

                                        	<input type="email" class="form-control" id="exampleInputEmail1" placeholder="E-mail address">

                                        </li>

                                        <li>

                                        	<button type="submit" class="btn btn-light"><i class="fas fa-chevron-right"></i></button>

                                        </li>

                                    </ul>

                                </div>

                            </div><!-- Footer Box /-->

                        </div><!-- Columns /-->

                        

                    </div><!-- Row /-->

                </div><!-- Container /-->

            </div><!-- Footer Bottom /-->

            

            <div class="footer-Copyright">

            	<div class="container">

                	<div class="row">

                    	

                        <div class="col-lg-12 col-md-12 col-sm-12">

                        	<div class="copyrightinfo">© 2019 <a href="https://www.webfulcreations.com/" target="_blank">Webful Creations</a>. All Rights Reserved.</div>

                        </div>

                        

                    </div><!-- Row /-->

                </div><!-- Container /-->

            </div><!-- Footer Bottom /-->

            

        </div>

        <!-- Footer /-->

        

    </div>

    <!-- Main Container /-->

    

	<!-- Move to Top Icon 

    	 Remove to Not Display /-->

    <a href="#" id="top" title="Go to Top">

    	<i class="far fa-caret-square-up"></i>

    </a>

    

    <!-- Page Preloader

    	 Delete to Remove Preloader /-->

    <div class="preloader">

        <div class="spinner animated infinite fadeIn">

            <div class="preloader-img"></div>

        </div>

	</div><!-- Preloader /-->

        

    <!-- Including Jquery so All js Can run -->

    <script src="assets/js/jquery.js"></script>

    

    <!-- Including bootstrap JS so bootstrap function can work. -->

    <script src="assets/js/bootstrap.min.js"></script>

    

    <!-- Carousel JS -->

    <script src="assets/js/owl.carousel.min.js"></script>

    

    <!--  animation.css on scroll Jquery Appear JS -->

    <script src="assets/js/jquery.appear.js"></script>

    

    <!-- Magnific Popup is a responsive lightbox -->

    <script src="assets/js/jquery.magnific-popup.min.js"></script>

       

   <!-- Webful JS -->

    <script src="assets/js/template.js"></script>

    

</body>



<!-- Mirrored from www.webfulcreations.com/html-templates/education-buddy/faqs.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Oct 2020 06:25:06 GMT -->

</html>    