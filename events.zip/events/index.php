<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome To OEC </title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="assets/css/bootstrap.min.css">
	<link rel="stylesheet" href="assets/css/animate.min.css">
	<link rel="stylesheet" href="assets/css/fontawesome-all.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<link rel="stylesheet" type="text/css" href="assets/css/colors/switch.css">
</head>

<body>
	<div class="clearfix"></div>

	<div class="wrapper clearfix">
		<!-- <div class="wizard-part-title">
			<h3> Upgrade your Account</h3>
		</div> -->
		<!--multisteps-form-->
		<div class="multisteps-form">
			<!--progress bar-->
			<!-- <div class="row">
				<div class="col-12 col-lg-12 ml-auto mr-auto mb-5 mt-5">
					<div class="multisteps-form__progress">
						<button class="multisteps-form__progress-btn js-active">Application data</button>
						<button class="multisteps-form__progress-btn">Tax residency</button>
						<button class="multisteps-form__progress-btn">Indentity card</button>
						<button class="multisteps-form__progress-btn">Investability </button>
						<button class="multisteps-form__progress-btn">Review </button>
					</div>
				</div>
			</div> -->
			<!--form panels-->
			<div class="row">
				<div class="col-12 col-lg-12 m-auto">
					<form class="multisteps-form__form clearfix" action="mail.php" method="post" id="wizard">
						
						<!--single form panel-->
						<div class="multisteps-form__panel js-active" data-animation="slideVert">
							<div class="inner pb-100">
								<!-- <div class="wizard-topper">
									<div class="wizard-progress">
										<span>1 of 5 Completed</span>
										<div class="progress">
											<div class="progress-bar">
											</div>
										</div>
									</div>
								</div> -->
								<div class="wizard-content-item text-center">
									<h2>STUDY IN THE UK</h2>
									<p>Submit your details or email us and we'll get back to you.<br/>(Spot admissions for May/September) </p>
								</div>
								<div class="wizard-content-form">
									<div class="wizard-form-field">
										<div class="wizard-form-input position-relative form-group has-float-label">
											<input type="text" name="name" class="form-control" placeholder="First and Last Name*" required="">
											<label>First and Last Name</label>
										</div>
										<div class="wizard-form-input position-relative form-group has-float-label">
											<input type="email" class="form-control" name="email" placeholder="Email Address*" required="">
											<label>Email Address</label>
										</div>
										<div class="row">
											<div class="col-md-6">
												<div class="wizard-form-input position-relative form-group has-float-label">
													<input type="text" class="form-control" name="phone" placeholder="Phone*" required="">
													<label>Phone</label>
												</div>
											</div>
											<div class="col-md-6">
												<div class="wizard-form-input position-relative form-group has-float-label">
													<input type="text" class="form-control" name="course" placeholder="(Bachelores/Post Graduate)*" required="">
													<label>COURSE INTRESTED </label>
												</div>
											</div>
										</div>
										<div class="row">
											<div class="col-md-4">
												<div class="wizard-form-input position-relative form-group has-float-label mt-0 n-select-option">
													<select id="intake" name="intake" class="form-control" required="">
														<option value="">Select Intake*</option>
														<option value="September 2021">September 2021</option>
														<option value="May 2021">May 2021</option>
													</select>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="wizard-footer">
									<div class="wizard-imgbg">
										<img src="assets/img/v2.png" alt="">
									</div>
									<div class="actions">
										<ul>
											<li><button type="submit" id="submit-form" title="submit" name="submit">SUMBIT <i class="fa fa-arrow-right"></i></button></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</form>
				</div>
			</div>
		</div>

	</div>
	<script src="assets/js/jquery-3.3.1.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/switch.js"></script>
	<script src="assets/js/main.js"></script>
	<script>
		$("#files").change(function() {
			filename = this.files[0].name
			console.log(filename);
		});
	</script>
</body>

</html>