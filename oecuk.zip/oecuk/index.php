<?php ?>
<!doctype html>
<html lang="en">
<head>
    <!-- Google Tag Manager -->
            <script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
            new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
            j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
            'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
            })(window,document,'script','dataLayer','GTM-TK7HKTW');</script>
     <!-- End Google Tag Manager -->

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>OEC UK</title>
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">

    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">

    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">

    <!--====== Animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.css">

    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

	<script
		src="https://code.jquery.com/jquery-3.4.1.js"
		integrity="sha256-WpOohJOqMqqyKL9FccASB9O0KwACQJpFTUBLTYOVvVU="
		crossorigin="anonymous"></script>
	<script>
		function SubForm (){
			$.ajax({
				url:"https://api.apispreadsheets.com/data/H8C440VgCnFpRryW/",
				type:"post",
				data:$("#my_captcha_form").serializeArray(),
				success: function(){
					alert("Form Data Submitted :)")
				},
				error: function(){
					alert("There was an error :(")
				}
			});
		}
	</script>
</head>
<body>
    <!-- Google Tag Manager (noscript) -->
        <noscript><iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TK7HKTW"
        height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
    <!-- End Google Tag Manager (noscript) -->

    <!--====== PRELOADER PART START ======-->

    <div class="preloader">
        <div class="loader">
            <div class="ytp-spinner">
                <div class="ytp-spinner-container">
                    <div class="ytp-spinner-rotator">
                        <div class="ytp-spinner-left">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                        <div class="ytp-spinner-right">
                            <div class="ytp-spinner-circle"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--====== PRELOADER PART ENDS ======-->
    <!--====== NAVBAR PART START ======-->
    <section class="header-area">
        <div class="navbar-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="col-lg-5">
                            <nav class="navbar navbar-expand-lg">
                                <a class="navbar-brand" href="#">
                                    <img src="assets/images/oec-logo.png" alt="OEC-Logo" class="img-logo">
                                </a>
                                <!-- <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarEight" aria-controls="navbarEight" aria-expanded="false" aria-label="Toggle navigation">
                                    <span class="toggler-icon"></span>
                                    <span class="toggler-icon"></span>
                                    <span class="toggler-icon"></span>
                                </button> -->
                                <!-- <div class="collapse navbar-collapse sub-menu-bar" id="navbarEight">
                                    <ul class="navbar-nav ml-auto">
                                        <li class="nav-item active">
                                            <a class="page-scroll" href="#home">HOME</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="#about">ABOUT</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="#portfolio">PORTFOLIO</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="#pricing">PRICING</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="#testimonial">CLIENTS</a>
                                        </li>
                                        <li class="nav-item">
                                            <a class="page-scroll" href="#contact">CONTACT</a>
                                        </li>
                                    </ul>
                                </div> -->

                                <!-- <div class="navbar-btn d-none mt-15 d-lg-inline-block">
                                    <a class="menu-bar" href="#side-menu-right"><i class="lni-menu"></i></a>
                                </div> -->
                            </nav> <!-- navbar -->
                        </div>
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- navbar area -->
        <div id="home" class="slider-area">
            <div class="bd-example">
                <div id="carouselOne" class="carousel slide" data-ride="carousel">
                    <ol class="carousel-indicators">
                        <li data-target="#carouselOne" data-slide-to="0" class="active"></li>
                        <li data-target="#carouselOne" data-slide-to="1"></li>
                        <li data-target="#carouselOne" data-slide-to="2"></li>
                    </ol>
                    <div class="carousel-inner">
                        <div class="carousel-item bg_cover active" style="background-image: url(assets/images/uk1.jpg)">
                            <div class="carousel-caption">
                                <div class="container">
                                    <div class="row justify-content-center">
                                        <div class="col-xl-6 col-lg-7 col-sm-10">
                                            <!-- <h2 class="carousel-title">Refreshing Design & Easy to Customize</h2>
                                            <ul class="carousel-btn rounded-buttons">
                                                <li><a class="main-btn rounded-three" href="#">GET STARTED</a></li>
                                                <li><a class="main-btn rounded-one" href="#">DOWNLOAD</a></li>
                                            </ul> -->
                                        </div>
                                    </div> <!-- row -->
                                </div> <!-- container -->
                            </div> <!-- carousel caption -->
                        </div> <!-- carousel-item -->
                        <div class="carousel-item bg_cover" style="background-image: url(assets/images/uk2.jpg)">
                            <div class="carousel-caption">
                                <div class="container">
                                    <div class="row justify-content-center">
                                        <div class="col-xl-6 col-lg-7 col-sm-10">
                                            <!-- <h2 class="carousel-title">Based on Latest Bootstrap & HTML5</h2>
                                            <ul class="carousel-btn rounded-buttons">
                                                <li><a class="main-btn rounded-three" href="#">GET STARTED</a></li>
                                                <li><a class="main-btn rounded-one" href="#">DOWNLOAD</a></li>
                                            </ul> -->
                                        </div>
                                    </div> <!-- row -->
                                </div> <!-- container -->
                            </div> <!-- carousel caption -->
                        </div> <!-- carousel-item -->
                    </div> <!-- carousel-inner -->
                    <a class="carousel-control-prev" href="#carouselOne" role="button" data-slide="prev">
                        <i class="lni-arrow-left-circle" style="color: #302766;"></i>
                    </a>
                    <a class="carousel-control-next" href="#carouselOne" role="button" data-slide="next">
                        <i class="lni-arrow-right-circle" style="color: #302766;"></i>
                    </a>
                </div> <!-- carousel -->
            </div> <!-- bd-example -->
        </div>
    </section>
    <!--====== NAVBAR PART ENDS ======-->
    <!--====== SAIDEBAR PART START ======-->
    <div class="sidebar-right">
        <div class="sidebar-close">
            <a class="close" href="#close"><i class="lni-close"></i></a>
        </div>
        <div class="sidebar-content">
            <div class="sidebar-logo text-center">
                <a href="#"><img src="assets/images/logo-alt.png" alt="Logo"></a>
            </div> <!-- logo -->
            <div class="sidebar-menu">
                <ul>
                    <li><a href="#">ABOUT</a></li>
                    <li><a href="#">SERVICES</a></li>
                    <li><a href="#">RESOURCES</a></li>
                    <li><a href="#">CONTACT</a></li>
                </ul>
            </div> <!-- menu -->
            <div class="sidebar-social d-flex align-items-center justify-content-center">
                <span>FOLLOW US</span>
                <ul>
                    <li><a href="#"><i class="lni-twitter-original"></i></a></li>
                    <li><a href="#"><i class="lni-facebook-filled"></i></a></li>
                </ul>
            </div> <!-- sidebar social -->
        </div> <!-- content -->
    </div>
    <div class="overlay-right"></div>
    <!--====== SAIDEBAR PART ENDS ======-->
    <!--====== ABOUT PART START ======-->
      <section id="contact" class="contact-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center pb-20">
                        <h3 class="title">Get Free Counseling</h3>
                        <!-- <p class="text">Stop wasting time and money designing and managing a website that doesn’t get results. Happiness guaranteed!</p> -->
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="center">
                    <div class="col-lg-12">
                        <div class="contact-form form-style-one mt-35 wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.5s">
                            <form id="my_captcha_form" action="contact.php" method="post">
                                <div class="form-input mt-15">
                                    <label>Name</label>
                                    <div class="input-items default">
                                        <input type="text" placeholder="Name" name="name"  required>
                                        <i class="lni-user"></i>
                                    </div>
                                </div> <!-- form input -->
                                <div class="form-input mt-15">
                                    <label>Email</label>
                                    <div class="input-items default">
                                        <input type="email" placeholder="Email" name="email" required>
                                        <i class="lni-envelope"></i>
                                    </div>
                                </div> <!-- form input -->
                                <div class="form-input mt-15">
                                    <label>Phone</label>
                                    <div class="input-items default">
                                        <input type="text" placeholder="Phone" name="phone" maxlength="12" required>
                                        <i class="lni-mobile"></i>
                                    </div>
                                </div> <!-- form input -->
                                <div class="form-input mt-15">
                                    <label>City</label>
                                    <div class="input-items default">
                                        <input type="text" placeholder="City" name="city"  required>
                                        <i class="lni-money-location"></i>
                                    </div>
                                </div> <!-- form input -->
                                <div class="form-input mt-15">
                                    <label>Enquiry For </label>
                                    <div class="input-items default">
                                        <select name="enquiry" class="enquiry" required="">
                                            <option value="select">Select Enquiry For</option>
                                            <option value="bachelors">Bachelors (UG)</option>
                                            <option value="masters">Masters (PG)</option>
                                        </select>
                                        <!-- <i class="lni-book"></i> -->
                                    </div>
                                </div> <!-- form input -->
                                <div class="form-input mt-15">
                                    <label>Message</label>
                                    <div class="input-items default">
                                        <textarea placeholder="Please mention your Course and Year of Intake"  name="message"  required></textarea>
                                        <i class="lni-pencil-alt"></i>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                            <div class="form-input mt-15">
                                            <div class="g-recaptcha" data-sitekey="6LfwJmQfAAAAACqvSHyWl570OjvrBANSjUZ8Sm7P"> </div>
                                                </div>
                                    </div>
                                    <div class="col-md-6">
                                            <div class="form-input rounded-buttons mt-20 text-center">
                                            <button type="submit" onclick='SubForm()' class="main-btn rounded-three" name="submit" value="Submit">Submit</button>
                                            </div>
                                    </div>   
                                </div>   
   

                              <!--   <p class="form-message"></p>
                                <div class="form-input rounded-buttons mt-20 text-center">
                                   <button type="submit" class="main-btn rounded-three" name="submit" value="Submit">Submit</button>
                                </div> -->  <!-- form input-->
                            </form>
                        </div> <!-- contact form -->
                    </div>
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    <section id="about" class="about-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xl-6 col-lg-8">
                    <div class="about-image text-center wow fadeInUp" data-wow-duration="1.5s" data-wow-offset="100">
                        <img src="assets/images/UK.gif" alt="services" width="100px">
                    </div>
                    <div class="section-title text-center mt-30 pb-40">
                        <h4 class="title wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="0.6s">Why United Kingdom?</h4>
                        <p class="text wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1s">Course duration in the United Kingdom is shorter than other study destinations around the world.
                        </p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-6">
                    <div class="single-about d-sm-flex mt-30 wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.2s">
                        <div class="about-icon">
                            <!-- <img src="assets/images/icon-1.png" alt="Icon"> -->
                        </div>
                        <div class="about-content media-body box">
                            <h4 class="about-title">IELTS Waiver</h4>
                            <!-- <p class="text">Poorly designed presentations are a thing of the past. Create beautiful and high-quality content that is aligned.</p> -->
                        </div>
                    </div> <!-- single about -->
                </div>
                <div class="col-lg-6">
                    <div class="single-about d-sm-flex mt-30 wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.4s">
                        <div class="about-icon">
                            <!-- <img src="assets/images/icon-2.png" alt="Icon"> -->
                        </div>
                        <div class="about-content media-body box">
                            <h4 class="about-title">2 Year of PSW</h4>
                            <!-- <p class="text">Poorly designed presentations are a thing of the past. Create beautiful and high-quality content that is aligned.</p> -->
                        </div>
                    </div> <!-- single about -->
                </div>
                <div class="col-lg-6">
                    <div class="single-about d-sm-flex mt-30 wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.6s">
                        <div class="about-icon">
                            <!-- <img src="assets/images/icon-3.png" alt="Icon"> -->
                        </div>
                        <div class="about-content media-body box">
                            <h4 class="about-title">Dependent/Spouse Visa Available</h4>
                            <!-- <p class="text">Poorly designed presentations are a thing of the past. Create beautiful and high-quality content that is aligned.</p> -->
                        </div>
                    </div> <!-- single about -->
                </div>
                <div class="col-lg-6">
                    <div class="single-about d-sm-flex mt-30 wow fadeInUp" data-wow-duration="1.5s" data-wow-delay="1.8s">
                        <div class="about-icon">
                            <!-- <img src="assets/images/icon-4.png" alt="Icon"> -->
                        </div>
                        <div class="about-content media-body box">
                            <h4 class="about-title">40+ Universities to choose from in United Kingdom </h4>
                            <!-- <p class="text">Poorly designed presentations are a thing of the past. Create beautiful and high-quality content that is aligned.</p> -->
                        </div>
                    </div> <!-- single about -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
  
    <!--====== ABOUT PART ENDS ======-->
    <!--====== PRINICNG STYLE EIGHT START ======-->
    <section id="pricing" class="pricing-area">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-6">
                    <div class="section-title text-center pb-20">
                        <h3 class="title">Why OEC </h3>
                        <!-- <p class="text">Stop wasting time and money designing and managing a website that doesn’t get results. Happiness guaranteed!</p> -->
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row justify-content-center">                
                <div class="col-lg-8 col-md-8 col-sm-10">
                    <div class="pricing-style-one mt-40 wow fadeIn" data-wow-duration="1.5s" data-wow-delay="0.2s">
                        <!-- <div class="pricing-icon text-center">
                            <img src="assets/images/wman.svg" alt="">
                        </div>
                        <div class="pricing-header text-center">
                            <h5 class="sub-title">Basic</h5>
                            <p class="month"><span class="price">$ 199</span>/month</p>
                        </div> -->
                        <div class="pricing-list">
                            <ul>
                                <li><i class="lni-check-mark-circle"></i> Pioneers in World Education since 20 years </li>
                                <li><i class="lni-check-mark-circle"></i>   More than 15,000 students placed at the best universities across the world</li>
                                <li><i class="lni-check-mark-circle"></i>   Free Application and Admission  Assistance</li>
                                <li><i class="lni-check-mark-circle"></i>  Offices in Baroda / Hyderabad/ Mumbai/ Pune / Sri-lanka/ Dubai</li>
                                <li><i class="lni-check-mark-circle"></i> Affiliated with more than 500 universities worldwide </li>
                                <li><i class="lni-check-mark-circle"></i> Dedicated Team of about 30 Experts with years of experience and Industry knowledge</li>
                            </ul>
                        </div>
                       <!-- <div class="pricing-btn rounded-buttons text-center">
                            <a class="main-btn rounded-three" href="https://www.oecdubai.com/" target="_blank">GET STARTED</a>
                        </div>-->
                    </div> <!-- pricing style one -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
    </section>
    <!--====== PRINICNG STYLE EIGHT ENDS ======-->
    <!--====== CONTACT TWO PART START ======-->
    <!--====== CONTACT TWO PART ENDS ======-->
    <!--====== FOOTER FOUR PART START ======-->
    <footer id="footer" class="footer-area">
        <div class="footer-copyright">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-12">
                        <div class="copyright text-center text-lg-left mt-10">
                            <p class="text" style="text-align:center;">© 2022 OECIndia |  All Rights Reserved.
                               <!--  <a rel="nofollow" href="https://www.anantsoftcomputing.com/">Anant Soft Computing</a></p> -->
                        </div> <!--  copyright -->
                    </div>
                   <!-- <div class="col-lg-2">
                         <div class="footer-logo text-center mt-10">
                            <a href="index.html"><img src="assets/images/logo-2.svg" alt="Logo"></a>
                        </div>  -->
                        <!-- footer logo 
                    </div>-->
                 <!--   <div class="col-lg-5">
                        <ul class="social text-center text-lg-right mt-10">
                            <li><a href="https://www.facebook.com/oecbaroda/" target="_blank"><i class="lni-facebook-filled"></i></a></li>
                            <li><a href="https://www.twitter.com/oec_india" target="_blank"><i class="lni-twitter-original"></i></a></li>
                            <li><a href="https://www.instagram.com/oecindia/" target="_blank"><i class="lni-instagram-original"></i></a></li>
                             <li><a href="#"><i class="lni-linkedin-original"></i></a></li> 
                        </ul> 
                    </div>-->
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer copyright -->
    </footer>

    <!--====== FOOTER FOUR PART ENDS ======-->
    
    <!--====== BACK TOP TOP PART START ======-->

    <a href="#" class="back-to-top"><i class="lni-chevron-up"></i></a>

    <!--====== BACK TOP TOP PART ENDS ======-->  

    <!--====== PART START ======-->
    <!--====== PART ENDS ======-->
    <!--====== jquery js ======-->
    <script src="assets/js/vendor/modernizr-3.6.0.min.js"></script>
    <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>

    <!--====== Bootstrap js ======-->
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/popper.min.js"></script>

    <!--====== Slick js ======-->
    <script src="assets/js/slick.min.js"></script>

    <!--====== Isotope js ======-->
    <script src="assets/js/isotope.pkgd.min.js"></script>

    <!--====== Images Loaded js ======-->
    <script src="assets/js/imagesloaded.pkgd.min.js"></script>

    <!--====== Magnific Popup js ======-->
    <script src="assets/js/jquery.magnific-popup.min.js"></script>

    <!--====== Scrolling js ======-->
    <script src="assets/js/scrolling-nav.js"></script>
    <script src="assets/js/jquery.easing.min.js"></script>

    <!--====== wow js ======-->
    <script src="assets/js/wow.min.js"></script>

    <!--====== Main js ======-->
    <script src="assets/js/main.js"></script>
    
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>

    <script>

    document.getElementById("my_captcha_form").addEventListener("submit",function(evt)
      {
      
      var response = grecaptcha.getResponse();
      if(response.length == 0) 
      { 
        //reCaptcha not verified
        alert("please verify you are human!"); 
        evt.preventDefault();
        return false;
      }
      //captcha verified
      //do the rest of your validations here
      
    });
    </script>
</body>

</html>
